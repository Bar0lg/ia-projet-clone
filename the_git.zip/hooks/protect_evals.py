#!/usr/bin/env python3
"""Pre-tool hook: keep the coding agent out of the eval set, the tests and the secrets.

A rule written in `AGENTS.md` ("never edit evals/") is a *request* the model may ignore; this
script is the *control* that enforces it (Book Ch. 10 sec. 10.5, Ch. 12 sec. 12.8). It is
deliberately tool-independent and pure standard library:

  * As a **Claude Code `PreToolUse` hook** it reads the event JSON on stdin
    (`{"tool_name": ..., "tool_input": {"file_path": ...}}` for Edit/Write,
    `{"tool_input": {"command": ...}}` for Bash) -- see `.claude/settings.json`.
  * As a **manual check** it takes paths or a command on the command line:
        python hooks/protect_evals.py evals/cases/manifest.json      -> exit 2 (blocked)
        python hooks/protect_evals.py src/mr_reviewer/cli.py          -> exit 0 (allowed)
        python hooks/protect_evals.py --command "rm evals/cases/x"    -> exit 2 (blocked)
  * Other agents (Codex, Cursor...) can call it the same way from their own hook mechanism
    (`docs/HARNESS.md`).

Decision: exit code 2 + a one-line reason on stderr blocks the call; exit 0 lets it through.
What is blocked:
  * any Edit/Write whose path is under `evals/` or `tests/` (the labelled cases, the manifests
    and the unit tests are READ-ONLY for the agent: a `clean` or `trap` case is never "fixed");
  * any tool touching a `.env` file (read or write: the agent must not see secrets);
  * a shell command that names one of those paths together with a write-ish verb
    (`>`, `>>`, `rm`, `mv`, `cp ... evals/`, `sed -i`, `tee`, `truncate`, `git checkout --`).
Reading `evals/` or `tests/` (cat, pytest, grep) is allowed: the agent needs them to work.

Test it in both directions before trusting it: `uv run pytest tests/test_protect_evals.py`.
"""
from __future__ import annotations

import json
import re
import sys

PROTECTED_DIRS = ("evals/", "tests/")
SECRET_FILES = (".env",)
WRITE_VERBS = re.compile(
    r"(?:^|[\s;&|(])(?:rm|mv|cp|tee|truncate|sed\s+-i\S*|git\s+checkout\s+--|git\s+restore)\b"
    r"|>{1,2}\s*\S"
)


def _norm(path: str) -> str:
    """Normalise a path for matching: forward slashes, no leading ./ or absolute prefix noise."""
    p = path.strip().strip("'\"").replace("\\", "/")
    while p.startswith("./"):
        p = p[2:]
    return p


def _is_protected_path(path: str) -> bool:
    p = _norm(path)
    return any(f"/{d}" in f"/{p}" or p.startswith(d) for d in PROTECTED_DIRS)


def _is_secret_path(path: str) -> bool:
    p = _norm(path)
    name = p.rsplit("/", 1)[-1]
    # .env, .env.local, .env.production...; but NOT .env.example (it holds no secret)
    return any(name == s or (name.startswith(s + ".") and not name.endswith(".example"))
               for s in SECRET_FILES)


def check_path(path: str, writing: bool) -> str | None:
    """Return a reason to block, or None if the access is allowed."""
    if _is_secret_path(path):
        return f"blocked: {path} holds secrets; the agent must not read or write it"
    if writing and _is_protected_path(path):
        return (f"blocked: {path} is under a read-only directory (evals/, tests/): "
                "cases, labels and unit tests are never edited by the agent")
    return None


def check_command(command: str) -> str | None:
    """Block a shell command that writes to, or reads, protected files."""
    cmd = command.replace("\\", "/")
    tokens = re.findall(r"[\w./-]+", cmd)
    if any(_is_secret_path(t) for t in tokens):
        return "blocked: the command references a .env file (secrets)"
    touches_protected = any(_is_protected_path(t) for t in tokens)
    if touches_protected and WRITE_VERBS.search(cmd):
        return ("blocked: the command writes under evals/ or tests/ (read-only for the agent); "
                "running or reading them is fine, changing them is not")
    return None


def decide_event(event: dict) -> str | None:
    tool = str(event.get("tool_name", ""))
    tool_input = event.get("tool_input") or {}
    if "command" in tool_input:
        return check_command(str(tool_input["command"]))
    path = tool_input.get("file_path") or tool_input.get("path") or tool_input.get("notebook_path")
    if path:
        writing = tool.lower() not in ("read", "glob", "grep")
        return check_path(str(path), writing=writing)
    return None


def main(argv: list[str]) -> int:
    reason: str | None
    if argv:
        if argv[0] == "--command":
            reason = check_command(" ".join(argv[1:]))
        else:
            reasons = [check_path(a, writing=True) for a in argv]
            reason = next((r for r in reasons if r), None)
    else:
        raw = sys.stdin.read()
        try:
            event = json.loads(raw) if raw.strip() else {}
        except json.JSONDecodeError:
            return 0  # not an event we understand: never block by accident
        reason = decide_event(event)
    if reason:
        print(reason, file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
