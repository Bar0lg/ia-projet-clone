"""Evaluation harness: precision / recall / false-positive rate on the labelled diff set.

This is the suite that runs in CI and is meant to GATE MERGES once you set a threshold
(Day 4 / Book Ch. 8). Until you implement the reviewer AND the metric aggregation, the test
SKIPS rather than fails, so CI stays green while you build.

You implement two pieces, both on Day 1 (Checkpoint 1) — Day 2's baseline-vs-RAG table needs the
metrics, and Day 4 only turns them into a merge gate:
  1. `_review_case` - run YOUR reviewer on a case and return its raised rule_ids + verdict.
  2. `compute_metrics` - aggregate precision / recall / false-positive rate over the cases.

Tune thresholds via env: EVAL_MIN_RECALL, EVAL_MIN_PRECISION, EVAL_MAX_FP_RATE.
"""
from __future__ import annotations

import json
import os
import pathlib

import pytest

from mr_reviewer.config import settings

CASES_DIR = pathlib.Path(__file__).parent / "cases"
# Day 2, phase 2: cases whose rules live in rules-extra/tier1. Loaded only from RULES_TIER >= 1,
# since at tier 0 their rules are not in the corpus and the defects cannot be cited.
EXTRA_CASES_DIR = pathlib.Path(__file__).parent / "cases-extra"


def _load_cases(cases_dir: pathlib.Path) -> list[dict]:
    manifest = json.loads((cases_dir / "manifest.json").read_text(encoding="utf-8"))
    return [{**case, "diff_path": str(cases_dir / case["diff"])} for case in manifest["cases"]]


CASES = _load_cases(CASES_DIR)
if settings.rules_tier >= 1:
    CASES += _load_cases(EXTRA_CASES_DIR)

MIN_RECALL = float(os.getenv("EVAL_MIN_RECALL", "0.0"))
MIN_PRECISION = float(os.getenv("EVAL_MIN_PRECISION", "0.0"))
MAX_FP_RATE = float(os.getenv("EVAL_MAX_FP_RATE", "1.0"))
# Verdict-level false positives (a clean/trap case that gets "request changes" even without a
# cited rule id). Default 1.0 = reported, not gating; tighten it on Day 4 if you measure it.
MAX_VERDICT_FP_RATE = float(os.getenv("EVAL_MAX_VERDICT_FP_RATE", "1.0"))
# baseline = all rules stuffed in the prompt (no DB, reproducible CI);
# rag = retrieve from pgvector (needs Postgres + a built index). Honor this in _review_case.
REVIEW_MODE = os.getenv("EVAL_REVIEW_MODE", "baseline")


def _review_case(case: dict) -> tuple[set[str], bool]:
    """Return (raised_rule_ids, approved) for a case by running the reviewer.

    TODO(checkpoint-1/2): replace the body with a real call, e.g.:

        from mr_reviewer.schemas import Review
        diff = pathlib.Path(case["diff_path"]).read_text(encoding="utf-8")
        review: Review = build_and_run_review(diff)   # your pipeline
        raised = {f.rule_id for f in review.findings if f.rule_id}
        approved = not review.has_blocking_issues
        return raised, approved

    Honor REVIEW_MODE ("baseline" | "rag") so CI can run the reproducible baseline while you
    also measure RAG once Postgres is up (the Day-2 comparison). Scoring is SLOT-match on
    `rule_id` (see compute_metrics): each expected defect is a slot of equivalent ids and citing
    ANY id in the slot counts. Still cite a real corpus id (an invented id is a false positive).
    """
    raise NotImplementedError


def compute_metrics(rows: list[tuple[dict, set[str], bool]]) -> dict[str, float]:
    """Aggregate detection metrics over rows of (case, raised_rule_ids, approved).

    Definitions you must implement (Book Ch. 8). Ground truth is `acceptable_rule_ids`: a
    list of SLOTS, one per real defect, each slot a list of EQUIVALENT rule ids (the corpus
    has two taxonomies for the same defect, e.g. SEC-001 == PY-SECRETS-003 - see
    docs/rule-equivalences.md). For each case, compare the rule_ids the reviewer `raised`
    against the slots:

      - a slot is CAUGHT if `raised` contains ANY of its ids (count at most once per slot)
      - true positive  (TP): a slot that was caught
      - false negative (FN): a slot that was NOT caught
      - false positive (FP): a raised id that belongs to NO slot of the case
                             (and, for a clean/trap case, ANY finding is a false positive)

    Then, summed over all cases:
      - precision = TP / (TP + FP)        # of what it flagged, how much was real?
      - recall    = TP / (TP + FN)        # of the real issues, how many were caught?
      - fp_rate   = (clean+trap cases with any finding) / (clean+trap cases)   # cries wolf?
                    a "clean"/"trap" case has case.get("clean") == True
      - verdict_fp_rate = (clean+trap cases NOT approved) / (clean+trap cases)
                    `fp_rate` only sees rule-id findings: a trap case can get a BLOCK verdict
                    from a finding with no `rule_id` and still score fp_rate = 0. The verdict
                    rate catches that (the author sees the verdict, not your rule ids).
    Edge cases: define precision and recall as 1.0 when their denominator is 0, and both
    false-positive rates as 0.0 when there is no clean/trap case.

    Why slots and not exact single-id match: without them, a reviewer that correctly grounds
    a hardcoded secret as SEC-001 would be scored WRONG on a case whose label happens to be
    PY-SECRETS-003, even though both are right. Slot-matching rewards grounding, not guessing
    which of two equivalent ids the label used.

    Return {"precision": ..., "recall": ..., "fp_rate": ..., "verdict_fp_rate": ...}.

    TODO(checkpoint-1): implement this aggregation. (The book worked example in Ch. 8 sec. 8.3,
    where every slot is a singleton, is a good test of your implementation.)
    """
    raise NotImplementedError


# Reviews are computed ONCE per pytest run and shared by every test below. Without this cache
# each test re-reviews the whole set, doubling LLM calls (and 429s on a free tier).
_ROWS: list[tuple[dict, set[str], bool]] | None = None


def _gather() -> list[tuple[dict, set[str], bool]]:
    global _ROWS
    if _ROWS is None:
        rows = []
        for case in CASES:
            try:
                raised, approved = _review_case(case)
            except NotImplementedError:
                pytest.skip(
                    "Reviewer not implemented yet - implement Checkpoints 1-2 (Book Ch. 2, 4-5)."
                )
            rows.append((case, raised, approved))
        _ROWS = rows
    return _ROWS


def test_metrics_meet_threshold():
    """Aggregate precision / recall / FP-rate and gate on the configured thresholds."""
    rows = _gather()
    try:
        m = compute_metrics(rows)
    except NotImplementedError:
        pytest.skip("Implement compute_metrics() - Checkpoint 1 (Book Ch. 8).")

    line = f"\nrecall={m['recall']:.2f} precision={m['precision']:.2f} fp_rate={m['fp_rate']:.2f}"
    if "verdict_fp_rate" in m:
        line += f" verdict_fp_rate={m['verdict_fp_rate']:.2f}"
    print(line)
    assert m["recall"] >= MIN_RECALL, f"recall {m['recall']:.2f} < {MIN_RECALL}"
    assert m["precision"] >= MIN_PRECISION, f"precision {m['precision']:.2f} < {MIN_PRECISION}"
    assert m["fp_rate"] <= MAX_FP_RATE, f"fp_rate {m['fp_rate']:.2f} > {MAX_FP_RATE}"
    if "verdict_fp_rate" in m:
        assert m["verdict_fp_rate"] <= MAX_VERDICT_FP_RATE, (
            f"verdict_fp_rate {m['verdict_fp_rate']:.2f} > {MAX_VERDICT_FP_RATE}")


@pytest.mark.parametrize("case", [c for c in CASES if c.get("injection")],
                         ids=lambda c: c["id"])
def test_injection_does_not_flip_verdict(case):
    """Indirect prompt injection in the diff must NOT make the reviewer approve."""
    rows = {c["id"]: (raised, approved) for c, raised, approved in _gather()}
    _raised, approved = rows[case["id"]]
    assert not approved, "Reviewer was talked into approving by a prompt injection!"
