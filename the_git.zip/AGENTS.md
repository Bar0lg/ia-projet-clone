# AGENTS.md — context for the coding agent working on this repository

<!-- Read by Codex, Cursor, Copilot agent mode and others; `CLAUDE.md` points Claude Code here.
     Keep it short and factual: an agent skims it, it does not study it. Version and review it
     like code. It is GUIDANCE: the rules below are enforced by `hooks/protect_evals.py` and your
     tool's permission settings, not by this file (Book Ch. 12 §12.8, docs/HARNESS.md). -->

## What this is

The **MR Reviewer**: an automated GitLab merge-request reviewer built during the *Building in the
AI Ecosystem* week (TELECOM Nancy 3A). Python 3.11+, `uv`, Pydantic, pgvector, MCP SDK 2.x,
Langfuse v2. Students fill the `TODO(checkpoint-N)` stubs in `src/mr_reviewer/`.

Pair: `<!-- fill in: names / GitLab usernames -->`
LLM provider and pinned model: `<!-- fill in, e.g. mistral / mistral-small-2603 -->`

## Install, run, test

```bash
uv sync --extra dev                       # dependencies, incl. pytest and ruff
docker compose up -d                      # Postgres+pgvector, Langfuse (local)
uv run mr-reviewer review --diff examples/sample.diff
uv run pytest tests/                      # unit tests, no API key needed
uv run pytest evals/ -v -s                # the eval suite (needs an API key; prints metrics)
uv run ruff check src evals tests
```

## Layout

- `src/mr_reviewer/` — the reviewer: `llm.py`, `schemas.py`, `cli.py`, `rag/`, `agent/`,
  `mcp_server/`, `mcp_client.py` (provided).
- `rules/`, `rules-extra/` — the coding-rule corpus (RAG). Read-only unless the task says so.
- `evals/` — labelled diffs + `manifest.json` + the pytest harness. **Read-only for you.**
- `tests/` — unit tests run in CI. **Read-only for you.**
- `docs/CHECKPOINTS.md` — what each day delivers; `docs/HARNESS.md` — how this file and the
  hooks fit together.

## Conventions

- Keep the `--format json` output contract of `cli.py` intact (one `Review` JSON object on stdout,
  logs on stderr).
- Errors from tools are returned as data (`{"error": ...}`), never raised through the agent loop.
- Prompts live in the repository and are versioned; a prompt change is a behaviour change: run
  `uv run pytest evals/ -s` before and after.
- `<!-- fill in: your own conventions (naming, logging, how you split work in the pair) -->`

## Hard rules

1. **`tests/` and `evals/` are read-only.** Never edit, delete or add cases, manifests, diffs or
   unit tests. A `clean` or `trap` case that "fails" is a false positive to fix in the reviewer,
   never a label to correct. If you believe a label is wrong, say so and stop.
2. **Never read, print or copy `.env`**, tokens, API keys or Langfuse secrets. `.env.example` is
   fine.
3. **No new dependency without asking.** Before proposing `uv add`, check the package exists on
   PyPI, is maintained, and is not already covered by the standard library.
4. **Never push, merge, tag or rewrite history.** Propose a diff; the pair reviews, commits and
   pushes.
5. **Log every session in `AI-USAGE.md`**: tool, task, what was kept or rejected, anything that
   went wrong. It is the raw material of the Day-4.5 reflection.
