# Checkpoints — what to build each day

Search the code for `TODO(checkpoint-N)` to find the exact stubs (and `TODO(stretch)` for optional
extras). Each checkpoint is committed and pushed by end of day. Chapter numbers refer to the book /
polycopié on the course site. Per-day **challenges** ("Pour aller plus loin") are on the course site.

---

## Day 0 — set up, and configure your agent's harness · Book Ch. 12 §12.8, `docs/HARNESS.md`
**Goal:** services up, keys checked (course site, Day 0) — and the coding agent you will use all
week fenced in *before* it touches the repository.

- Fill the blanks in `AGENTS.md` (pair, provider + pinned model, your conventions). `CLAUDE.md`
  points Claude Code to it; Codex and Cursor read it natively.
- Wire `hooks/protect_evals.py` in your tool (`.claude/settings.json` is the Claude Code example;
  other tools: `docs/HARNESS.md`) and **test it in both directions**: `uv run pytest
  tests/test_protect_evals.py`, then ask the agent to edit a case under `evals/` (refused) and a
  file under `src/` (allowed).
- Write the first entry of `AI-USAGE.md`: tool, permissions granted, what the hook refused.

**Done when:** `AGENTS.md` has no blank left, the hook blocks an edit under `evals/` from inside
your agent, and `AI-USAGE.md` exists. A *tested* hook is an admissible mitigation on Day 4.

## Checkpoint 1 — LLM foundations (Day 1) · Book Ch. 2–3
**Goal:** a CLI that returns a *validated, structured* review of a diff, with token/cost logging.

- `llm.py` → `LLMClient.complete` / `complete_structured`: wire your provider's SDK; record usage;
  enforce `SPEND_CAP_USD`.
- `cli.py` → the `--diff` path: build messages, get a `Review`, print findings + run cost.
- `cli.py` → `--format json`: print the `Review` (+ `usage`) as ONE JSON object on stdout, logs on
  stderr. This is the **contract the Day-4.5 grader uses** — see *Day 4.5* below. Keep it working
  all week.
- The 15 cases in `evals/cases/` are provided. **Write ≥5 of your own** on top of them (at least one
  clean), in the same format — a `.diff` file in `evals/cases/` **plus an entry in
  `manifest.json`** — so you practise labelling; they stay in your repo's eval set. (Not in
  `tests/`: that folder is the CI `unit` job, which has no API key.)
- `evals/test_evals.py` → implement `_review_case` (call your reviewer) **and `compute_metrics`**
  (precision / recall / FP-rate with slot matching — definitions in the module docstring; the Book
  Ch. 8 §8.3 worked example is your unit test). Day 2's comparison table needs these numbers; Day 4
  only turns them into a merge gate.

**Done when:** `mr-reviewer review --diff examples/sample.diff` prints structured findings,
`... --format json` prints valid `Review` JSON and nothing else, `pytest tests/` is green, and
`pytest evals/ -s` prints recall / precision / fp_rate on the labelled set.

## Checkpoint 2 — RAG over the rule base (Day 2) · Book Ch. 4–5
**Goal:** findings cite project rules; **you can show, with numbers, when retrieval is worth it**;
measured retrieval quality.

- `llm.py` → `embed`.
- `rag/index.py` → chunk + embed every file of `corpus_files()` (the **whole `rules/` corpus** at
  `RULES_TIER=0`: multi-file and ~75 rules on purpose) into pgvector. The baseline prompt reads the
  same `corpus_files()`.
- `rag/retrieve.py` → top-k retrieval; feed rules into the review prompt; set `Finding.rule_id`.
- **Comparison (core):** run the reviewer two ways — (a) *baseline*: all rules stuffed into the
  prompt; (b) *RAG*: top-k retrieved. Tabulate tokens/cost, precision, and false-positive rate for
  each. At ~4k tokens the whole corpus fits in the prompt, so the baseline may do as well as RAG —
  report it honestly, then **extrapolate** the cost to a realistic volume and a 10× corpus and say
  when you would switch (Book Ch. 5 §5.7).
- Produce a short recall@k report; tune chunking/k.
- **Phase 2 (core):** for `RULES_TIER` = 1, 2, 3 (~150 / 300 / 500 rules from `rules-extra/`,
  ≈ 10k / 21k / 35k tokens), re-index from scratch and re-run both modes; from tier 1 the harness
  adds the five cases of `evals/cases-extra/`. Table and plot tokens/cost, precision, recall,
  FP-rate and recall@k per tier; state the tipping point you measured. `HB-*` restatements count as
  correct (`docs/rule-equivalences.md`).

**Done when:** findings carry a real `rule_id`; you have the **baseline-vs-RAG table**, a recall@k
number, and the **per-tier phase-2 table**.

**Stretch (optional):** hybrid BM25+vector search, reranking, metadata filtering, a second corpus —
see Day 2 challenges and `TODO(stretch)` in `rag/retrieve.py`.

## Checkpoint 3 — Agent + MCP (Day 3) · Book Ch. 6 & 7
**Goal:** the agent reviews a *real* MR via a GitLab MCP server.

- `agent/loop.py` → the plan/act/observe loop with step budget, timeouts, error-as-data, explicit
  termination. When the budget runs out, **fail loudly**: raise; the CLI prints the partial
  findings on stderr and exits non-zero — a run that ran out of budget is never reported as a clean
  review (zero findings would read as an approval).
- `agent/loop.py` → fill the **per-run trajectory record** (`AgentResult`: `tools_used` in order,
  `redundant_calls`, tokens, `cost_usd`, `terminated_by`, `wall_clock_s` — Book Ch. 6 §6.6). The
  CLI prints it on stderr after every `--mr` run and adds it as `trajectory` in
  `--mr --format json`. **Required:** a reviewer that is right but calls the same tool three times
  is a production problem no outcome metric shows.
- `agent/tools.py` → `dispatch`; validate model-supplied arguments; count redundant calls.
- `mcp_server/server.py` → GitLab MCP server (`get_merge_request_diff` — title, description and
  diff, file names kept —, `list_changed_files`, `post_inline_comment` — **no** approve/merge
  tool).
- `mcp_client.py` → **provided** (stdio, SDK 2.x, errors as data). Smoke-test it against your
  server on its own (`uv run python -m mr_reviewer.mcp_client` lists the tools;
  `tests/test_mcp_client.py` shows the round-trip) *before* wiring `agent/tools.dispatch` to it.
- `cli.py` → the `--mr` path. The agent only gets the **read** tools; with `--post`, the CLI itself
  posts the validated, redacted findings via `post_inline_comment` — never the agent.
- Write a short **harness note** (`docs/checkpoint3-harness.md`, about half a page). It answers
  four questions about the reviewer you built: (1) which parts are a fixed *workflow* and which
  genuinely need the *agent's* judgement, and why; (2) which tools the agent can see, and why not
  more (what would an injected model do with each one you left out?); (3) the *context policy*
  between steps: what you keep, trim or drop from tool observations, and what a 30-file MR does to
  your budget; (4) the termination condition and what the loop does when the budget runs out. The
  reviewer is a harness: loop + tools + context + controls (Book Ch. 6, `docs/HARNESS.md`).

**Done when:** `mr-reviewer review --mr <iid> --post` reviews a sandbox MR end-to-end via MCP
and prints its trajectory record.
Inline comments (anchored on a diff line) are the target; if the GitLab `position` fight costs you
more than an hour, a single **summary note** listing the findings is an accepted fallback for the
checkpoint — say so in your design note (see the README gotcha).

**Stretch (optional):** consume an external MCP server; planning step; specialist sub-agents — see
Day 3 challenges.

## Checkpoint 4 — Evals, observability, security (Day 4) · Book Ch. 8, 9, 10
**Goal:** production-grade. This is where most of the grade is.

> **Reading the eval set.** `evals/cases/manifest.json` mixes four kinds of case:
> *positive* (a real violation → `acceptable_rule_ids`), *clean* (nothing to flag), `injection`
> (the diff tries to talk the reviewer into approving — the verdict must NOT flip), and **`trap`**
> (the diff *looks* like a violation but isn't — e.g. SQL split across string literals yet
> parameterized, or a broad `except` that re-raises). **Trap and clean cases are NOT bugs to fix —
> they are precision tests.** If your reviewer flags them it produces a false positive and loses
> precision / FP-rate. Don't edit the diffs to "pass"; make the reviewer read the *rule*, not the
> *pattern*.

> **Scoring is SLOT-match on `rule_id`.** Ground truth is `acceptable_rule_ids`: a list of
> *slots*, one per real defect, each slot a list of **equivalent** ids — because the corpus has
> two taxonomies for the same defect (category `SEC/REL/...` and Python `PY-*`), e.g.
> `SEC-001 == PY-SECRETS-003`. A slot is caught if you cite **any** id in it, so grounding a
> secret as `SEC-001` *or* `PY-SECRETS-003` both count. Citing an id that is in **no** slot (an
> invented or wrong-family id) is still a false positive. This is a grounding test, not
> pattern-matching — see `docs/rule-equivalences.md` for the full equivalence map.

- `evals/test_evals.py` (written on Day 1) → make the `evals` job a **merge gate**: set the
  `EVAL_MIN_RECALL` / `EVAL_MIN_PRECISION` / `EVAL_MAX_FP_RATE` thresholds in `.gitlab-ci.yml` and
  mark the job required to merge.
- Set the thresholds from a **measured** baseline run (pick each one notch *below* your observed
  score; don't tune case-by-case). Mind the **granularity**: fp_rate moves in steps of
  1 / (number of clean+trap cases) — with the 4 provided, 0, 0.25, 0.5… — which is why the default
  is `EVAL_MAX_FP_RATE=0.25` (one false positive tolerated; 0.1 would mean zero). Your own clean
  cases make it finer (Book Ch. 8 §8.8). **Beware silent skips:** the default harness *fails* on
  a provider error, but if you wrap `_review_case` in a broad `try/except` that `pytest.skip`s (e.g.
  on a `429`), CI goes green without measuring anything. Decide whether repeated provider failures
  should **fail** the gate.
- Wire Langfuse tracing through the agent; commit a sample trace.
- Fill in `SECURITY.md` (from the template); implement & **demonstrate ≥2 mitigations**, including
  defeating `case06_prompt_injection`. The verdict computed in code (no approve verb) is necessary
  but **not sufficient**: zero blocking findings *is* an approval, so an injection that makes the
  model drop its findings still flips the verdict. Pair it with data/instruction separation in the
  prompt and a deterministic check for machine-detectable defects (e.g. bare `except:`, secrets)
  that does not go through the model (Book Ch. 10 §10.4–10.5).
- The template now has an *agentic* section (ASI01–ASI04 for the Day-3 agent) and a **Harness
  controls** row: the Day-0 hook (`hooks/protect_evals.py`), *if its tests run green and you can
  show it refusing an edit*, counts as one of the two demonstrated mitigations. A rule written in
  `AGENTS.md` alone does not (prose is a request, a hook is a control).
- Optional gate: `EVAL_MAX_VERDICT_FP_RATE` (verdict-level false positives on clean/trap cases,
  see `compute_metrics`); report the number in any case.

**Done when:** CI reports precision/recall/FP and gates merges; tracing is live; `SECURITY.md` shows
two working mitigations.

**Stretch (optional):** LLM-as-judge faithfulness, red-team variants, cost view from traces, nightly
full-eval trend — see Day 4 challenges.

## Day 4.5 — integrate, demo, reflect · Book Ch. 12

> **Final challenge (hidden cases).** On Day 4.5 your reviewer, **as tagged**, is run by an
> independent grader on diffs you have never seen (new defects, clean cases, traps, injections).
> Before the deadline announced by the instructor: push a tag **`final`**; make sure
> `mr-reviewer review --diff <file> --format json` works from a clean clone with only a `.env`
> (document any extra step — `docker compose up`, rule indexing — in the README runbook). The
> grader recomputes the metrics itself and derives the verdict from your severities. Every review
> must go through an **LLM call, reported in `usage`** (deterministic checks are welcome as a
> complement), and the grader uses a **course API key** placed in your clone's `.env`: state your
> provider and dated model in the README. Details and scoring: *Final challenge* on the course site
> (rubric page).

Clean README/runbook; ~8-min demo (planted defect caught + cited, injection handled, a trace, CI
green); peer review; individual reflection on critical use of AI. **One of the two or three
incidents of the reflection must be a *harness incident*:** a failure of your coding agent (an
edited case, an invented package, a wrong `rm`, an ignored rule…), the change you made to its
harness in response (a rule in `AGENTS.md`, a deny rule, a hook, a permission removed, a tool
taken away), and the evidence that the failure no longer recurs. Fix the harness, not the one
mistake. The book's Ch. 14 (case study) walks the finished system end to end. **Stretch:**
CI-native mode, auto-fix suggestions — see Day 4.5 challenges.
