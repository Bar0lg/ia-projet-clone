# Rule equivalences (why the eval uses `acceptable_rule_ids` slots)

The rule corpus in `rules/` deliberately keeps two overlapping taxonomies:

- a **category** family — `SEC-*`, `REL-*`, `PERF-*`, `API-*`, `LOG-*`, `TEST-*`, `TYPE-*`,
  `STYLE-*`, `NAME-*`, `DOC-*`;
- a **Python-specific** family — `PY-NAMING-001`, `PY-ERRORS-002`, `PY-SECRETS-003`,
  `PY-LOGGING-004`, `PY-SQL-005`, `PY-RESOURCES-006`, `PY-TYPING-007`, `PY-TESTS-008`,
  `PY-MUTABLE-009`, `PY-CONCURRENCY-010`.

For several defects the two families say the **same thing** under different ids. A reviewer
that correctly retrieves and grounds a finding may cite either id — both are right. So the
eval set (`evals/cases/manifest.json`) labels each defect with a **slot**: a list of
equivalent ids in `acceptable_rule_ids`. A slot is *caught* when the reviewer cites **any**
id in it. Scoring is slot-match, not exact single-id match.

## Equivalence clusters (any id in a row is interchangeable)

| Defect | Equivalent rule ids |
|---|---|
| Secret hardcoded in source | `SEC-001` · `PY-SECRETS-003` |
| Non-parameterized SQL / injection | `SEC-002` · `PY-SQL-005` |
| Bare / overly broad `except` (incl. silent swallow) | `REL-001` · `REL-002` · `PY-ERRORS-002` |
| Mutable default argument | `REL-005` · `PY-MUTABLE-009` |
| `print()` instead of logging | `LOG-001` · `PY-LOGGING-004` |
| Resource not closed / no context manager | `REL-004` · `PY-RESOURCES-006` |
| Shared mutable state without synchronization | `REL-009` · `PY-CONCURRENCY-010` |
| Public function not typed | `TYPE-001` · `PY-TYPING-007` |
| Behaviour change without tests | `TEST-001` · `PY-TESTS-008` |
| Non-descriptive / non-conventional names | `NAME-001` · `PY-NAMING-001` |
| Secret / sensitive data written to a log | `SEC-008` · `PY-LOGGING-004` (its second sentence also forbids logging secrets) |

`PY-LOGGING-004` belongs to two clusters (a `print()` → with `LOG-001`; a secret in a log → with
`SEC-008`): label each defect with the slot that matches *that* defect.

## NOT equivalent (common confusions — keep these distinct)

- **`REL-010` (don't block the event loop)** ≠ `REL-009` / `PY-CONCURRENCY-010` (shared mutable
  state). A blocking `time.sleep()` in a coroutine is `REL-010` only.
- **`SEC-011` (verify TLS)** ≠ `SEC-001` (secrets). A diff that both disables TLS *and* hardcodes
  a token has **two** slots (see `case11`).
- **`SEC-003` (`shell=True`)**, **`REL-006` (timeout)**, **`PERF-001` (N+1)** have no PY-* twin in
  `rules/` — but each gains an `HB-*` twin from tier 2 (below).

## Phase 2 (Day 2): the extended corpus in `rules-extra/`

Tiers 2 and 3 import a *corporate handbook* whose `HB-*` rules restate project rules in other
words — a third taxonomy, as happens when a team merges standards. Each `HB-*` id joins the
cluster of the rule it restates, in every slot of `evals/cases*/manifest.json` and of the
final-challenge grader:

| `HB-*` rule (tier) | Joins the cluster of |
|---|---|
| `HB-SEC-01` (2) | `SEC-001` · `PY-SECRETS-003` |
| `HB-SEC-02` (2) | `SEC-002` · `PY-SQL-005` |
| `HB-ERR-01` (2) | `REL-001` · `REL-002` · `PY-ERRORS-002` |
| `HB-NET-01` (2) | `REL-006` |
| `HB-LOG-01` (2) | `LOG-001` · `PY-LOGGING-004` (the `print()` cluster) |
| `HB-SHELL-01` (2) | `SEC-003` |
| `HB-TLS-01` (2) | `SEC-011` |
| `HB-PERF-01` (2) | `PERF-001` |
| `HB-ASYNC-01` (2) | `REL-010` |
| `HB-DEF-01` (2) | `REL-005` · `PY-MUTABLE-009` |
| `HB-RES-01` (3) | `REL-004` · `PY-RESOURCES-006` |
| `HB-TYPE-01` (3) | `TYPE-001` · `PY-TYPING-007` |
| `HB-TEST-01` (3) | `TEST-001` · `PY-TESTS-008` |
| `HB-LOG-02` (3) | `SEC-008` · `PY-LOGGING-004` (the secret-in-a-log cluster) |
| `HB-CONC-01` (3) | `REL-009` · `PY-CONCURRENCY-010` |
| `HB-NAME-01` (3) | `NAME-001` · `PY-NAMING-001` |
| `HB-TIME-01` (3) | `PY-TIME-011` (tier 1) |
| `HB-MONEY-01` (3) | `PY-MONEY-012` (tier 1) |
| `HB-IO-01` (3) | `PY-IO-013` (tier 1) |
| `HB-ITER-01` (3) | `PY-ITER-014` (tier 1) |

Every other rule of `rules-extra/` is **not** equivalent to anything: new Python topics, and
rules for other stacks (JavaScript, SQL migrations, Docker, CI, Go, Terraform, front end,
Kubernetes, Java) that apply to no eval diff. Some of those are deliberate *near neighbours*
(Java's `BigDecimal` for money, SQL `timestamptz`, Go's `time.UTC`…): citing one on a Python diff
is a false positive, which is exactly the noise the phase-2 comparison measures.

## For the instructor

If you prefer a single-taxonomy corpus, you can instead **de-duplicate** `rules/` (keep one
canonical rule per cluster, turn the rest into cross-references) and collapse each slot to a
singleton. The slot mechanism was chosen because it fixes the scoring fairness without
touching the corpus or the RAG dynamics. The same slot schema is used by the final-challenge
grader (`mr-reviewer-bench`), so the two stay consistent.
