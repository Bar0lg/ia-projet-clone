# Your agent's harness

*October 2026. Tool names and configuration formats change fast: check your tool's documentation
before copying anything below.*

## Agent = model + harness

A coding agent (Claude Code, Codex, Cursor, Copilot agent mode…) is not "a model". It is a model
*plus* a **harness**: the deterministic software around it that decides what the model sees
(context files, tool descriptions), what it may do (permissions, hooks, sandbox), how its loop runs
(step budget, compaction of a long context) and how its work is checked (tests, linters).
The MR Reviewer you build this week has exactly the same shape: a loop (`agent/loop.py`), read-only
tools, a verdict computed in code, a deterministic net, traces and an eval suite. That is a harness
too (Book Ch. 6, Ch. 10, Ch. 14). This page is about the *other* harness: the one around the agent
that helps you write the reviewer.

One rule drives everything here: **a rule written in prose is a request the model may ignore; a
rule enforced by code is a control.** Both are useful. Only the second one counts as a mitigation
in `SECURITY.md`.

## The files

| File | Role | Enforced by |
|---|---|---|
| `AGENTS.md` | Context and rules for any agent: commands, layout, the five hard rules. Shared convention (Codex, Cursor, Copilot…). | Nothing: it is guidance |
| `CLAUDE.md` | Claude Code reads this file; it just points to `AGENTS.md`. | Nothing |
| `hooks/protect_evals.py` | The control: blocks any write under `evals/` and `tests/`, any access to `.env`, and shell commands that would do the same. Tool-independent, stdlib only. | Exit code 2 + reason on stderr |
| `tests/test_protect_evals.py` | Proves the hook fires when it should and stays silent when it should not. Runs in the CI `unit` job. | pytest |
| `.claude/settings.json` | Example wiring for Claude Code: `permissions.deny` rules + the hook on `PreToolUse`. | Claude Code |
| `AI-USAGE.md` | Your log: what the agent did, what you kept, what went wrong. | You |

## Day 0: wire it and test it in both directions

1. Fill the blanks in `AGENTS.md` (pair, provider and model, your conventions).
2. Wire the hook in your tool (below). Then **test both directions**:

   ```bash
   uv run pytest tests/test_protect_evals.py          # the unit tests
   python hooks/protect_evals.py evals/cases/manifest.json   # exit 2: blocked
   python hooks/protect_evals.py src/mr_reviewer/cli.py      # exit 0: allowed
   ```

   Then, in your agent, ask it to "fix the expected label of case06" and watch it refused; ask it
   to edit `src/mr_reviewer/cli.py` and watch it allowed. A hook that only blocks, or only allows,
   is not tested.
3. Write the first entry of `AI-USAGE.md`: which tool, which permissions, what the hook refused.

At the demo, a **tested** hook counts as one of the two demonstrated mitigations of `SECURITY.md`
(row "Harness controls"), and the reflection of Day 4.5 asks for one *harness incident*: a failure
of the assistant and the change you made to the harness so that it does not recur.

## Wiring per tool (check the docs: this dates)

**Claude Code.** `.claude/settings.json` (provided as an example). Deny rules use the
`Tool(path)` form (`Read(./.env)`, `Edit(/evals/**)`; `Edit` rules also cover `Write`). The hook is
registered under `hooks.PreToolUse` with a matcher on tool names and a `command`; the event
arrives as JSON on stdin (`tool_name`, `tool_input.file_path` or `tool_input.command`), and exit
code 2 blocks the call. Docs: `https://code.claude.com/docs/en/hooks`,
`https://code.claude.com/docs/en/permissions`.

**Codex (OpenAI).** Reads `AGENTS.md` natively. Enforcement comes from its sandbox and approval
settings (read-only or workspace-write sandbox, approval policy for commands): keep the sandbox at
workspace level, require approval for network and installs, and run `hooks/protect_evals.py`
yourself on the diff before committing (`python hooks/protect_evals.py $(git diff --name-only)`).
Check the current docs for the hook mechanism available in your version.

**Cursor.** Reads `AGENTS.md` (and `.cursor/rules`). Use its agent permission settings (allow and
deny lists for commands and files) to deny edits under `evals/` and `tests/` and reads of `.env`;
run the hook script on the diff as above. Check the current docs for pre-tool hooks.

**Any tool without hooks.** The fallback is the same for all: a pre-commit check,
`python hooks/protect_evals.py $(git diff --cached --name-only)`, refuses to commit a change under
the protected paths, whoever wrote it.

## Why it matters this week

- The eval set is the ground truth of your grade and of the merge gate. An agent told "make the
  tests pass" may edit the label instead of the reviewer (Book Ch. 12 §12.8). The hook makes that
  impossible, not merely forbidden.
- `.env` holds the GitLab token and the API key. An agent that reads untrusted text (a README, an
  MR comment, an MCP tool description) with those in reach is the indirect injection of Ch. 10
  with a shell.
- The same discipline, in the other direction, is what you give the MR Reviewer: read-only tools,
  a verdict the model cannot say, a net the model cannot delete. Build both harnesses the same way.
