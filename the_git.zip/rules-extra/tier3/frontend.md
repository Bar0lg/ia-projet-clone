# Front-end rules — HTML, CSS, accessibility and React

Conventions for the web front end: its markup, its style sheets and its React components. One rule
per `##` section.

---

## FE-001 — Meaningful alternative text
Every `<img>` has an `alt` attribute: a short description for informative images and `alt=""` for
decorative ones. A missing `alt`, or a file name or the word "image" used as alt text, is a finding.

## FE-002 — Use native interactive elements
Actions use `<button>` and navigation uses `<a href>`. A `<div>` or `<span>` with an `onClick`
handler is a finding, because it cannot receive keyboard focus and is not announced as a control by
screen readers.

## FE-003 — Every form control has a label
Inputs, selects and text areas have a visible `<label>` bound with `for` or by wrapping the control;
`aria-label` is a fallback for icon-only controls. A placeholder used as the only label is a
finding.

## FE-004 — Keep a visible focus indicator
Interactive elements show a clearly visible focus style. `outline: none` or `outline: 0` without an
equivalent `:focus-visible` replacement is a finding, since keyboard users lose track of where they
are.

## FE-005 — Meet WCAG AA contrast
Text has a contrast ratio of at least 4.5:1 against its background, and 3:1 for large text and
component boundaries. A new colour pairing below these ratios, including grey helper text that
carries content, is a finding.

## FE-006 — Don't rely on colour alone
Status, errors and required fields are conveyed by text or an icon as well as by colour. A form
error shown only by turning a border red, or a chart whose series differ only by hue, is a finding.

## FE-007 — Logical heading structure
Each page has one `<h1>`, and headings descend without skipping levels. Choosing a heading element
for its font size, or styling a `<div>` to look like a heading, is a finding; size headings with CSS
instead.

## FE-008 — Declare the document language
The `<html>` element carries a `lang` attribute matching the content, and passages in another
language carry their own `lang`. A page without `lang` makes screen readers use the wrong
pronunciation and is a finding.

## FE-009 — Keep ARIA states in sync
ARIA attributes reflect the real state: a disclosure button updates `aria-expanded`, a tab sets
`aria-selected`, and `aria-controls` points to an existing id. Static ARIA values that never follow
the UI, or invalid roles, are a finding.

## FE-010 — Accessible modal dialogs
Modals use `<dialog>` with `showModal()`, or an equivalent that traps focus, closes on Escape and
returns focus to the trigger when closed. A modal that lets the Tab key reach the page behind it is
a finding.

## FE-011 — Respect reduced-motion preferences
Non-essential animations, parallax and auto-playing transitions are disabled or reduced inside
`@media (prefers-reduced-motion: reduce)`. A new animation longer than a brief state transition
without this guard is a finding.

## FE-012 — Mark up page landmarks
Pages use `<header>`, `<nav>`, `<main>` and `<footer>` landmarks, with exactly one `<main>`, and
start with a "skip to content" link that targets it. A page built only from generic `<div>`
containers, or with several `<main>` elements, is a finding.

## FE-013 — Tables for tabular data only
Tabular data uses `<table>` with a `<caption>` and `<th scope="col">` or `scope="row"` headers,
while page layout uses CSS grid or flexbox. A data grid built from `<div>` elements without table
roles, or a table used for layout, is a finding.

## FE-014 — Touch targets are large enough
Buttons, links and other controls offer a target of at least 24 by 24 CSS pixels, 44 by 44 on
touch-first layouts, or enough spacing from neighbouring targets. Tiny icon buttons packed edge to
edge are a finding.

## FE-015 — No positive `tabindex`
Focus order follows document order: `tabindex="0"` makes a custom widget focusable and
`tabindex="-1"` allows programmatic focus. Any positive `tabindex` value, or a focusable control
inside content marked `aria-hidden="true"`, is a finding.

## FE-016 — Derive values instead of syncing state
Values computable from props or other state are calculated during render, with `useMemo` if
expensive, not copied into `useState` and kept in sync by an effect. An effect whose only job is to
set derived state is a finding.

## FE-017 — Help browsers fill in forms
Fields for personal data and credentials carry the matching `autocomplete` token (`email`, `name`,
`street-address`, `current-password`, `one-time-code`) and a suitable `type` and `inputmode`. A
sign-in or checkout field without `autocomplete`, or with `autocomplete="off"` on a password, is a
finding.

## FE-018 — Abort stale requests
Data fetching in an effect passes an `AbortController` signal and aborts it in the cleanup, or uses
a data-fetching library that does so. A fetch whose late response can overwrite newer state after
the component changed or unmounted is a finding.

## FE-019 — Follow the rules of hooks
Hooks are called at the top level of a component or custom hook, never inside conditions, loops or
nested functions, and custom hooks are named `useSomething`. A conditionally called hook is a
finding.

## FE-020 — No `!important` in component styles
`!important` is reserved for utility classes and documented overrides of third-party CSS. Using it
in component styles to win a specificity battle is a finding; fix the selector or use a cascade
layer instead.

## FE-021 — Size text in relative units
Font sizes use `rem` or `em` and line heights are unitless, so that browser font settings and zoom
apply. Setting body text in fixed `px`, or adding `user-scalable=no` to the viewport meta tag, is a
finding.

## FE-022 — Use design tokens for colours and spacing
Colours, spacing and radii come from CSS custom properties or the theme, for example
`var(--color-danger)`. A raw hex value or an ad hoc pixel spacing in a component style sheet is a
finding when an equivalent token exists.

## FE-023 — Layouts work at small widths
Pages include `<meta name="viewport" content="width=device-width, initial-scale=1">` and layouts
reflow at a width of 320 CSS pixels without horizontal scrolling. A fixed-width container that
overflows on a phone is a finding.

## FE-024 — Reserve space for images and embeds
Images, videos and iframes declare `width` and `height` or an `aspect-ratio`, so the layout does not
shift when they load, and offscreen images use `loading="lazy"`. Media without reserved dimensions
is a finding.

## FE-025 — No inline scripts or event-handler attributes
Markup contains no inline `<script>` blocks and no `onclick=` style attributes, so that the Content
Security Policy can forbid `unsafe-inline`. Adding inline JavaScript to a page template is a
finding; load a bundled module instead.

## FE-026 — Safe links to new tabs
Links with `target="_blank"` to other origins carry `rel="noopener noreferrer"` and say, visually or
in accessible text, that they open a new tab. A cross-origin `target="_blank"` link without `rel` is
a finding.

## FE-027 — Format money from integer minor units
Prices travel through the front end as integer minor units (cents) plus an ISO currency code, and
are displayed with `Intl.NumberFormat(locale, { style: "currency", currency })`. Adding fractional
JavaScript numbers, or concatenating a currency symbol by hand, is a finding.

## FE-028 — Exchange instants as ISO 8601 and display them with a zone
Dates sent to or received from the API are ISO 8601 strings with an offset (`2026-03-01T09:00:00Z`)
and are displayed with `Intl.DateTimeFormat` and an explicit `timeZone`. Parsing locale-formatted
date strings with `new Date(...)` is a finding.

## FE-029 — Import only what you use
Large libraries are imported per function (`lodash/debounce`) or through tree-shakeable named
imports, and heavy routes are code-split with `React.lazy`. Importing a whole utility or icon
library for a single helper is a finding.

## FE-030 — Announce form errors
Validation messages are linked to their field with `aria-describedby`, the field sets
`aria-invalid="true"`, and a summary is announced through an `aria-live` region or focused on
submit. Errors shown only visually are a finding.
