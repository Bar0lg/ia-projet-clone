# Corporate engineering handbook — imported rules (part 2)

Second batch imported from the company-wide engineering handbook. As in part 1, each `HB-*` rule
that restates a project rule is treated as equivalent to it by the eval set (see
`docs/rule-equivalences.md`). One rule per `##` section.

---

## HB-TIME-01 — Datetimes carry their timezone
Timestamps that are stored, compared or exchanged must be timezone-aware and normalised to UTC. A
naive `datetime.now()` or `datetime.utcnow()` value leaving the function is a finding.

## HB-MONEY-01 — Exact arithmetic for currency
Amounts of money use an exact decimal type or integer minor units, never binary floating point.
Totals, prices or taxes computed with `float` are a finding.

## HB-IO-01 — Name the encoding of every text file
Opening a file in text mode without an explicit `encoding` argument depends on the machine's locale
and is a finding; state `encoding="utf-8"` unless a different encoding is required.

## HB-ITER-01 — Don't modify what you iterate
Do not insert into or delete from a collection while looping over it; iterate over a copy or build
a new collection instead.

## HB-RES-01 — Scope resources with `with`
Files, sockets, locks and connections are acquired in a `with` block (or an equivalent context
manager) so they are released on every path, including errors.

## HB-TYPE-01 — Annotate public interfaces
Every public function and method declares the types of its parameters and its return value.
An untyped public signature is a finding.

## HB-TEST-01 — No behaviour change without a test
A change that alters observable behaviour ships with a test that would fail without it. A behaviour
change with no new or updated test is a finding.

## HB-LOG-02 — Keep secrets out of logs
Log lines, exception messages and traces never contain credentials, tokens, session identifiers or
personal data; log an identifier or a redacted form instead.

## HB-CONC-01 — Synchronise shared mutable state
State shared between threads or tasks is protected by a lock, confined to one owner, or replaced by
an immutable value. Unsynchronised read-modify-write on shared state is a finding.

## HB-NAME-01 — Names say what things are
Variables, functions and classes have descriptive names that follow the language's conventions;
single letters (outside short loops), abbreviations and misleading names are findings.
