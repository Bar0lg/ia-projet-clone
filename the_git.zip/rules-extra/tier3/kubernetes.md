# Kubernetes manifest and Helm rules

Conventions for the Kubernetes manifests and Helm charts that deploy our services. One rule per `##`
section.

---

## K8S-001 — Pin container images
Images are referenced by an immutable version tag or, preferably, by a `@sha256:` digest. `:latest`,
a missing tag, or a mutable tag such as `:stable` in a Deployment, StatefulSet, Job or CronJob is a
finding.

## K8S-002 — Set resource requests and limits
Every container declares CPU and memory `requests` and a memory `limit`. A container without
requests cannot be scheduled sensibly, and one without a memory limit can starve its node; either
omission is a finding.

## K8S-003 — Separate liveness and readiness probes
Long-running containers define a readiness probe that reflects the ability to serve and a liveness
probe that checks only the process itself. A liveness probe that calls a database or downstream
service, turning its outage into restart loops, is a finding.

## K8S-004 — Run as a non-root user
The pod or container `securityContext` sets `runAsNonRoot: true` and a non-zero `runAsUser`. A
workload that runs as root, including one whose image needs root only to bind a low port, is a
finding.

## K8S-005 — Read-only root filesystem
Containers set `readOnlyRootFilesystem: true` and mount an `emptyDir` for any path that genuinely
needs writing, such as a scratch or cache directory. A writable root filesystem without a stated
reason is a finding.

## K8S-006 — Drop privileges and capabilities
Containers set `allowPrivilegeEscalation: false` and `capabilities: { drop: ["ALL"] }`, adding back
only named capabilities with a comment. Missing either setting, or adding `SYS_ADMIN` or `NET_ADMIN`
to an application, is a finding.

## K8S-007 — No privileged or host-level access
Application pods never set `privileged: true`, `hostNetwork`, `hostPID` or `hostIPC`, and never
mount `hostPath` volumes. Any of these outside a reviewed node-level DaemonSet is a finding.

## K8S-008 — Keep sensitive values in Secrets
Passwords, tokens and connection strings reach pods through `Secret` references or an
external-secrets operator, never as literal `env` values or ConfigMap entries in a manifest. A
credential written into a manifest or a Helm values file is a finding.

## K8S-009 — Dedicated service accounts
Each workload runs under its own `ServiceAccount`, and pods that do not call the Kubernetes API set
`automountServiceAccountToken: false`. A workload running under the namespace's `default` service
account is a finding.

## K8S-010 — Minimal RBAC
Roles grant specific verbs on specific resources in one namespace. Wildcard `verbs` or `resources`,
a `ClusterRole` where a namespaced `Role` suffices, or any application binding to `cluster-admin` is
a finding.

## K8S-011 — Default-deny network policies
Every application namespace has a default-deny `NetworkPolicy` for ingress, and for egress where the
CNI supports it, plus explicit policies for the traffic each workload needs. A new namespace or
service without network policies is a finding.

## K8S-012 — Disruption budgets for replicated workloads
Deployments and StatefulSets with more than one replica have a `PodDisruptionBudget` with
`minAvailable` or `maxUnavailable`. Without one, a node drain can evict every replica at once; a
production workload missing it is a finding.

## K8S-013 — Spread replicas across failure domains
Production workloads run at least two replicas with `topologySpreadConstraints` or pod anti-affinity
across nodes and zones. A configuration that lets all replicas land on the same node is a finding.

## K8S-014 — Use the recommended labels
Resources carry the `app.kubernetes.io/name`, `instance`, `version`, `component` and `managed-by`
labels, and selectors use a stable subset of them. A selector on a label that changes between
releases, such as `version`, is a finding.

## K8S-015 — Set the namespace explicitly
Manifests set `metadata.namespace`, Helm templates use `{{ .Release.Namespace }}`, and nothing is
deployed into `default`. A namespaced resource whose target namespace depends on the operator's
current kubectl context is a finding.

## K8S-016 — Configure the rollout strategy
Deployments use `RollingUpdate` with explicit `maxUnavailable` and `maxSurge`; `Recreate` is used
only with a comment explaining why two versions cannot run side by side. An implicit strategy on a
production Deployment is a finding.

## K8S-017 — Terminate gracefully
Pods serving traffic stop accepting new requests on SIGTERM, through a `preStop` hook or application
logic, and `terminationGracePeriodSeconds` exceeds their longest in-flight request. A server that
exits immediately and drops connections is a finding.

## K8S-018 — Roll pods when configuration changes
Deployments that mount a ConfigMap or Secret roll automatically when it changes, for example through
a `checksum/config` pod annotation in the Helm template. A configuration change that only takes
effect after a manual restart is a finding.

## K8S-019 — Environment specifics belong in values or overlays
Helm templates and base manifests contain no environment-specific hostnames, replica counts or
sizes; these come from `values-<env>.yaml` files or Kustomize overlays. Manifests copied and edited
per environment are a finding.

## K8S-020 — Fail on missing Helm values
Mandatory values are read with `required`, as in `{{ required "image.tag is required"
.Values.image.tag }}`, and string values are rendered with `quote`. A template that silently renders
an empty or unquoted value is a finding.

## K8S-021 — Bump the chart version
Every change to a chart increments `version` in `Chart.yaml` following SemVer, and `appVersion`
tracks the deployed image. A template or default-values change without a chart version bump is a
finding.

## K8S-022 — Share names and labels through helpers
Resource names and common labels come from named templates in `_helpers.tpl`, inserted with
`include` piped through `nindent` rather than with `template`. Label blocks repeated by hand in each
template are a finding.

## K8S-023 — Bound Jobs and CronJobs
Jobs set `backoffLimit` and `activeDeadlineSeconds`; CronJobs also set `concurrencyPolicy`,
`startingDeadlineSeconds` and history limits. A Job that can restart indefinitely, or a CronJob
whose runs can pile up, is a finding.

## K8S-024 — Make time zones explicit
CronJobs set `spec.timeZone`, for example `Etc/UTC` or `Europe/Paris`, instead of inheriting the
controller's zone, and containers that render local times set the `TZ` environment variable. A
schedule or container whose time zone is implicit is a finding.

## K8S-025 — Autoscaling needs requests and bounds
A `HorizontalPodAutoscaler` targets a workload whose containers declare the requests it measures
against, sets `minReplicas` to at least two in production and a deliberate `maxReplicas`. An HPA on
containers without requests is a finding.

## K8S-026 — Declare ingress class and TLS
Ingress resources set `ingressClassName` and a `tls` section referencing a certificate managed by
cert-manager or the platform. A public Ingress serving plain HTTP, or relying on a deprecated class
annotation, is a finding.

## K8S-027 — Use a startup probe for slow starts
Containers that take long to initialise use a `startupProbe` instead of a large
`initialDelaySeconds` on the liveness probe. Inflating the liveness delay, which slows detection of
real hangs for the whole life of the pod, is a finding.

## K8S-028 — Persist stateful data deliberately
Stateful workloads use a StatefulSet with `volumeClaimTemplates` and a StorageClass whose
`reclaimPolicy` is `Retain` for production data. Durable data kept in an `emptyDir`, or in one claim
shared by all replicas of a Deployment, is a finding.

## K8S-029 — Apply the runtime default seccomp profile
Pods set `securityContext.seccompProfile.type: RuntimeDefault` or a reviewed `Localhost` profile.
`Unconfined`, or no seccomp profile at all in a namespace that does not enforce the restricted Pod
Security Standard, is a finding.

## K8S-030 — Pull from the approved registry
Images come from the organisation's approved registry, with `imagePullSecrets` where needed, and
`imagePullPolicy` is set explicitly (`IfNotPresent` for pinned tags). A production workload pulling
directly from a public registry is a finding.
