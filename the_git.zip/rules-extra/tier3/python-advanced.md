# Advanced Python rules (tier 3)

Specialised conventions for the data-science, web-framework, task-queue, database and native-code
parts of the codebase. One rule per `##` section.

---

## PY-PANDAS-096 — Assign through `.loc`, never by chained indexing
Write to a DataFrame with a single `.loc[row_mask, "col"] = value`. Chained assignment such as
`df[df.age > 18]["flag"] = 1` may modify a temporary copy and raise `SettingWithCopyWarning`; it is
a finding.

## PY-PANDAS-097 — No `inplace=True` in pandas calls
Pandas operations such as `drop`, `fillna`, `rename` or `reset_index` are written as reassignments
(`df = df.dropna()`), never with `inplace=True`. The flag saves no memory, breaks method chaining
and is being deprecated; each use is a finding.

## PY-PANDAS-098 — Declare dtypes when loading data into pandas
`pd.read_csv`, `pd.read_excel` and `pd.read_sql` calls on production data pass `dtype=` (and
`usecols=` where relevant) for identifier, code and category columns. Letting pandas infer turns zip
codes into integers and ids into floats; an undeclared load is a finding.

## PY-PANDAS-099 — Vectorise instead of iterating over rows
Column computations use vectorised pandas or NumPy expressions, `np.where` or `merge`, not
`df.iterrows()`, `itertuples()` loops or `apply(axis=1)` over a large frame. A row-wise loop where a
vectorised equivalent exists is a finding.

## PY-PANDAS-100 — Validate merge cardinality
Every `pd.merge` or `DataFrame.join` on business keys passes `validate=` (`"one_to_one"`,
`"many_to_one"`) so that duplicate keys raise instead of silently multiplying rows. A merge on keys
whose uniqueness is assumed but not validated is a finding.

## PY-PANDAS-101 — Detect missing values with `isna`
Test for missing values with `pd.isna`, `Series.isna()` or `np.isnan`, never with `== np.nan` or `==
None` on a column or array, which is always false for NaN. Such a comparison in a filter or mask is
a finding.

## PY-NUMPY-102 — Make broadcasting explicit
When combining arrays of different shapes, reshape deliberately (`x[:, np.newaxis]`) and assert the
expected shape. Arithmetic between an `(n,)` and an `(n, 1)` array silently yields an `(n, n)`
matrix; an unchecked shape mix in new array code is a finding.

## PY-RNG-103 — Pass a seeded NumPy Generator explicitly
Analysis and simulation code draws random numbers from a `np.random.default_rng(seed)` Generator
passed in as a parameter, not from `np.random.seed()` and the legacy global functions. Hidden global
random state makes notebooks and pipelines irreproducible and is a finding.

## PY-NUMPY-104 — Choose integer dtypes that cannot overflow
NumPy fixed-width integers wrap around silently: adding two `uint8` image arrays or summing counts
in `int32` overflows without error. Cast to a wider dtype (`astype(np.int64)`) before accumulating;
arithmetic that can exceed a narrow dtype's range is a finding.

## PY-NOTEBOOK-105 — Commit notebooks with outputs stripped
Jupyter notebooks are committed without cell outputs or execution counts, enforced by `nbstripout`
or a pre-commit hook. Outputs bloat diffs, can embed data extracts and make review impossible; a
`.ipynb` file added with outputs is a finding.

## PY-NOTEBOOK-106 — Notebooks run top to bottom in a fresh kernel
A committed notebook must execute from a restarted kernel in cell order, as CI does with `jupyter
nbconvert --execute`. A cell that depends on a name defined only in a later cell, a deleted cell or
an interactive session is a finding.

## PY-NOTEBOOK-107 — Shared logic lives in modules, not notebooks
Functions used by more than one notebook belong in an importable package module, not copied between
notebooks or pulled in with `%run other.ipynb`. Helper cells duplicated across notebooks, or a
notebook importing another notebook, are a finding.

## PY-PLOT-108 — Use the object-oriented Matplotlib API
Plotting functions in library code create or receive a `fig, ax` pair and call methods on `ax`,
instead of driving the global `plt` state machine (`plt.plot`, `plt.gca`). Library code that draws
into the implicit current figure is a finding.

## PY-PLOT-109 — Generate report figures reproducibly
Scripts that produce report figures select a non-interactive backend, set `figsize` and `dpi`
explicitly, label axes with their units and write files with `savefig` rather than `plt.show()`. A
committed chart image that no script regenerates is a finding.

## PY-UNITS-110 — One shared `pint` unit registry
Physical quantities are built from a single application-wide `pint.UnitRegistry` imported from one
module. Creating another `UnitRegistry()` elsewhere makes quantities incompatible and raises on
comparison; any second registry instance is a finding.

## PY-UNITS-111 — Keep units attached until the boundary
Inside computations, keep `pint` quantities with their units and strip them only at an output
boundary with an explicit target unit (`q.m_as("kPa")`). Reading `.magnitude` mid-computation, or
mixing bare numbers with quantities, is a finding.

## PY-SKLEARN-112 — Fit preprocessing on training data only
Scalers, encoders, imputers and feature selectors are fitted inside a scikit-learn `Pipeline` on the
training split only. Calling `fit` or `fit_transform` on the full dataset before `train_test_split`
or cross-validation leaks test information and is a finding.

## PY-TORCH-113 — Run inference in evaluation mode
PyTorch inference code calls `model.eval()` and wraps the forward pass in `torch.inference_mode()`
or `torch.no_grad()`. Predicting with dropout and batch-norm still in training mode, or building an
autograd graph while serving, is a finding.

## PY-TORCH-114 — Keep tensor code device-agnostic
Select the device once (`torch.device(...)` from configuration) and move models and tensors with
`.to(device)`. Hard-coded `.cuda()` calls, literal `"cuda:0"` strings, or CPU tensors mixed into GPU
computations are a finding.

## PY-GEO-115 — Declare and align coordinate reference systems
GeoPandas and Shapely data carry an explicit CRS, and layers are reprojected with `to_crs` to a
common, suitable projection before joins, distances or areas. Measuring distances in EPSG:4326
degrees, or overlaying frames with different CRS, is a finding.

## PY-SPARK-116 — Prefer built-in Spark functions to UDFs
PySpark transformations use `pyspark.sql.functions` expressions; a `udf` is acceptable only when no
built-in exists, and then preferably as a vectorised `pandas_udf`. A row-at-a-time UDF that
re-implements a built-in function is a finding.

## PY-NUMBA-117 — Numba kernels compile in nopython mode
Functions accelerated with Numba use `@njit` (or `@jit(nopython=True)`) and only supported types. A
decorator that allows object-mode fallback, or a kernel taking dicts or arbitrary objects so that it
silently runs at interpreter speed, is a finding.

## PY-SCIPY-118 — Check solver convergence before using results
Results of `scipy.optimize.minimize`, `least_squares`, `root` and similar solvers are used only
after checking `result.success`, reporting `result.message` otherwise. Reading `result.x` from a
solver that may not have converged is a finding.

## PY-IMAGE-119 — Apply EXIF orientation before processing photos
User photos opened with Pillow are passed through `ImageOps.exif_transpose()` before resizing,
cropping or thumbnailing. Ignoring the EXIF orientation tag produces sideways thumbnails; processing
a camera image without it is a finding.

## PY-IMAGE-120 — Convert OpenCV channel order explicitly
OpenCV loads images as BGR while Pillow, Matplotlib and most models expect RGB. Every hand-off
between them converts explicitly with `cv2.cvtColor(img, cv2.COLOR_BGR2RGB)`; passing a `cv2.imread`
array straight to an RGB consumer is a finding.

## PY-PARQUET-121 — Write Parquet files with an explicit schema
DataFrames written to Parquet for other consumers pass `index=False`, or name the index
deliberately, and an explicit `pyarrow` schema for typed columns. Relying on inferred column types,
which change as missing values appear, or leaking `__index_level_0__`, is a finding.

## PY-PDF-122 — Embed fonts that cover the text in generated PDFs
PDFs generated with ReportLab or WeasyPrint register and embed a TrueType font whose glyphs cover
every script the document may contain. Relying on the built-in base fonts such as Helvetica, which
render non-Latin names as empty boxes, is a finding.

## PY-SCRAPY-123 — Crawl third-party sites politely
Scrapy projects keep `ROBOTSTXT_OBEY = True`, enable `AUTOTHROTTLE_ENABLED` or a `DOWNLOAD_DELAY`,
cap `CONCURRENT_REQUESTS_PER_DOMAIN` and send an identifying `USER_AGENT` with a contact address.
Disabling robots.txt or throttling for a crawl of third-party sites is a finding.

## PY-DJANGO-124 — Declare uniqueness with `UniqueConstraint`
Multi-column uniqueness on Django models is declared in `Meta.constraints` with
`models.UniqueConstraint(fields=[...], name=...)`, which also supports conditions and expressions.
New uses of the legacy `unique_together` option are a finding.

## PY-DJANGO-125 — Pass `update_fields` to partial Django saves
When Django code changes a few fields of an existing model instance and then calls
`instance.save()`, it passes `update_fields=[...]`. A bare `save()` rewrites every column from a
possibly stale instance; such a call after a partial change is a finding.

## PY-DJANGO-126 — Trigger side effects after commit
Emails, outbound notifications and task enqueues that follow a database write inside
`transaction.atomic()` are registered with `transaction.on_commit()`. Triggering them directly
inside the transaction lets a worker see uncommitted or rolled-back data and is a finding.

## PY-DJANGO-127 — Read settings through `django.conf.settings`
Application code uses `from django.conf import settings` and never imports the project settings
module directly (`from myproject import settings`). A direct import bypasses
`DJANGO_SETTINGS_MODULE` and `override_settings`; each one is a finding.

## PY-DJANGO-128 — Reference the user model indirectly
Foreign keys to the user model use `settings.AUTH_USER_MODEL`, and code that needs the class calls
`get_user_model()`. Importing `django.contrib.auth.models.User` directly breaks projects with a
custom user model and is a finding.

## PY-DJANGO-129 — No `null=True` on string fields
`CharField`, `TextField`, `SlugField` and `EmailField` use `blank=True` with an empty-string default
instead of `null=True`. Allowing both `NULL` and `""` gives two meanings to "no value" and is a
finding, except on unique fields.

## PY-STREAMLIT-130 — Pick the right Streamlit cache
In Streamlit apps, serialisable data such as query results and DataFrames is cached with
`st.cache_data`, while unserialisable shared objects such as loaded models use `st.cache_resource`
and are never mutated. A model in `cache_data`, or code mutating a cached resource, is a finding.

## PY-DJANGO-131 — Build URLs from route names
Links and redirects are built with `reverse()`, `redirect("route-name")` or the `{% url %}` tag from
named URL patterns. A hard-coded path such as `"/orders/" + str(pk)` in a view or template is a
finding: it breaks silently when routes change.

## PY-DJANGO-132 — Keep business logic out of model signals
`post_save`, `pre_delete` and similar receivers are reserved for decoupled concerns such as cache
invalidation or search indexing. Domain logic such as stock updates or invoicing belongs in explicit
service functions; a receiver that changes other models' business state is a finding.

## PY-DJANGO-133 — Don't filter the default manager
A Django model's default manager returns every row; soft-delete or publication filters live in a
separately named manager such as `published`. Overriding `get_queryset` on the default manager hides
rows from the admin, dumps and related lookups, and is a finding.

## PY-FLASK-134 — Build Flask apps with an application factory
Flask applications are created by a `create_app(config)` factory that loads configuration and
registers blueprints and extensions. A single global `app = Flask(__name__)` configured where it is
declared prevents running several configurations side by side and is a finding.

## PY-FLASK-135 — Bind Flask extensions with `init_app`
Extensions such as `SQLAlchemy`, `Migrate` or `LoginManager` are instantiated unbound and attached
in the factory with `ext.init_app(app)`, and other modules use `current_app`. A blueprint or helper
module that imports the application object is a finding.

## PY-JINJA-136 — Undefined template variables fail loudly
Jinja2 environments that render emails, reports or configuration files use
`undefined=StrictUndefined`, so a misspelt or missing variable raises instead of rendering as an
empty string. A rendering `Environment` left with the default `Undefined` is a finding.

## PY-FASTAPI-137 — Provide request resources through `Depends`
FastAPI endpoints receive database sessions, the current user and per-request services through
`Depends`, using `yield` dependencies for setup and teardown. An endpoint that reaches for a
module-global session or settings object instead is a finding.

## PY-FASTAPI-138 — Use a lifespan handler for startup and shutdown
Application-wide objects such as model weights or shared pools are created and disposed in a
`lifespan` async context manager passed to `FastAPI(lifespan=...)`. New `@app.on_event("startup")`
or `"shutdown"` handlers are deprecated and a finding.

## PY-FASTAPI-139 — `BackgroundTasks` only for short, losable work
FastAPI `BackgroundTasks` run inside the web process after the response and vanish on restart. They
suit best-effort work such as cache warming; payments, emails or exports must go to a durable task
queue, otherwise it is a finding.

## PY-CELERY-140 — Pass identifiers, not objects, to Celery tasks
Celery tasks are invoked with small JSON-serialisable arguments, typically primary keys, and reload
state inside the task. Passing ORM instances, open files, DataFrames or large blobs to `.delay()` or
`.apply_async()` is a finding: the message becomes huge and stale.

## PY-CELERY-141 — Give Celery tasks stable explicit names
Every Celery task declares `name="billing.invoices.send"` (or similar) in its decorator. Relying on
the module path means moving or renaming a function strands messages already queued under the old
name; a new or moved task without an explicit name is a finding.

## PY-CELERY-142 — Never wait for a Celery task inside a task
A Celery task must not call `AsyncResult.get()` or `.delay(...).get()` on another task: this can
exhaust the worker pool and deadlock. Compose the work with `chain`, `group` or `chord` instead; a
synchronous wait inside a task is a finding.

## PY-CELERY-143 — Choose the Celery acknowledgement mode deliberately
Celery tasks whose loss would matter set `acks_late=True` together with
`task_reject_on_worker_lost`, so that a worker crash redelivers the message. Leaving the default
early acknowledgement on a task that must not be lost is a finding.

## PY-SQLA-144 — One SQLAlchemy session per unit of work
A SQLAlchemy session is obtained from a `sessionmaker` at the start of one request, task or job and
committed or rolled back at its end. A module-level session shared across requests, or one kept for
the whole life of the process, is a finding.

## PY-SQLA-145 — Use SQLAlchemy 2.0-style queries
New code builds queries with `select()` and runs them through `session.execute()` or
`session.scalars()`. The legacy `session.query(...)` API and `engine.execute()` are deprecated;
using them in new or modified code is a finding.

## PY-SQLA-146 — Declare SQLAlchemy models with `Mapped` columns
New declarative SQLAlchemy models use `Mapped[...]` annotations with `mapped_column()`, so that
nullability and column types are explicit and checked by tools. Legacy `Column(...)` class
attributes without a `Mapped` annotation in a new or modified model are a finding.

## PY-PLOT-147 — Use perceptually uniform, colour-blind-safe colormaps
Continuous data is drawn with perceptually uniform colormaps such as `viridis` or `cividis`, and
signed data with a diverging map centred on its midpoint. Using `jet`, `rainbow` or `hsv`, which
create false boundaries and fail for colour-blind readers, is a finding.

## PY-DATA-148 — Pin the data an analysis runs on
Pipelines and notebooks read their input datasets by an immutable version: a DVC-tracked revision, a
snapshot identifier or a dated, write-once object key. Reading from a mutable `latest/` location or
a shared spreadsheet whose contents change between runs is a finding.

## PY-HTTPCACHE-149 — Set caching headers on personalised responses
Views returning user-specific data send `Cache-Control: private, no-store` (or `private,
max-age=...` when safe), and shared cacheable responses set `public`, a `max-age` and `Vary`. A
personalised response without an explicit `Cache-Control` header is a finding.

## PY-HTTPCACHE-150 — Serve static assets under hashed names
Django and Flask static files are published with content-hashed names (`ManifestStaticFilesStorage`,
WhiteNoise's manifest storage, or a bundler manifest) so they can be cached for a year. A long
`max-age` on unhashed asset URLs, or short caching of hashed ones, is a finding.

## PY-ASYNCIO-151 — Structure fan-out with `asyncio.TaskGroup`
Concurrent subtasks that belong to one operation are started inside an `async with
asyncio.TaskGroup()` block, so that one failure cancels its siblings and the error surfaces. In new
code, a list of `create_task` calls joined by `gather` is a finding.

## PY-ASYNCIO-152 — Start the event loop once, at the entry point
Programs call `asyncio.run(main())` once in their entry point. Library code never calls
`asyncio.run`, `get_event_loop().run_until_complete` or `nest_asyncio.apply()`; starting an event
loop from inside a library function is a finding.

## PY-DASK-153 — Compute Dask collections once
Dask code builds the whole task graph lazily and materialises results with a single `dask.compute(a,
b)` or `persist()` call. Calling `.compute()` inside a loop, or repeatedly on collections that share
upstream work, recomputes the graph each time and is a finding.

## PY-JAX-154 — Functions under `jax.jit` stay pure
Functions compiled with `jax.jit` or transformed by `grad` and `vmap` do not mutate globals or
depend on values outside their arguments, because tracing runs them only once. Randomness flows
through explicit `jax.random` keys; an impure jitted function is a finding.

## PY-CTYPES-155 — Declare `argtypes` and `restype` for foreign functions
Every foreign function called through `ctypes` has `argtypes` and `restype` set before its first
call. The default `int` conversion truncates pointers and 64-bit values on some platforms; an
undeclared foreign function signature is a finding.

## PY-CTYPES-156 — Keep memory shared with C alive
Buffers, structures and `CFUNCTYPE` callbacks handed to a C library are kept referenced on the
Python side for as long as the library may use them. A callback or `create_string_buffer` result
held only in a temporary while C keeps the pointer is a finding.

## PY-CEXT-157 — Balance references in C extensions
C extension code follows CPython ownership rules: each new reference is released with `Py_DECREF` on
every path, borrowed references are never decremented, and a function returning `NULL` has set an
exception. Any unbalanced reference is a finding.

## PY-MPROC-158 — Choose the multiprocessing start method explicitly
Code that creates processes obtains a context with `multiprocessing.get_context("spawn")` or
`"forkserver"` and builds its pools and queues from it. Relying on the platform's default `fork` in
a program that already runs threads or holds open clients is a finding.

## PY-MPROC-159 — Process-pool workers are module-level functions
Callables submitted to `multiprocessing.Pool`, `ProcessPoolExecutor` or `Process(target=...)` are
functions defined at module top level, taking arguments that can be sent to a child process.
Lambdas, nested functions or bound methods of objects holding connections are a finding: they fail
under `spawn`.

## PY-IPC-160 — Share large arrays between processes without copying
Large NumPy arrays exchanged between processes use `multiprocessing.shared_memory`, memory-mapped
files or Arrow buffers, sending only names and shapes through the queue. Pushing multi-megabyte
arrays through `Queue.put` or `Pool.map` arguments is a finding.

## PY-MEMVIEW-161 — Slice large binary buffers with `memoryview`
Parsers that walk through large `bytes` or `bytearray` buffers slice a `memoryview` of them, which
shares memory, rather than the bytes object, which copies on every slice. Repeated
`data[offset:offset + n]` copies inside a parsing loop are a finding.

## PY-REDIS-162 — Iterate Redis keys with `SCAN`
Code that enumerates Redis keys uses `scan_iter(match=..., count=...)`, never the `KEYS pattern`
command, which blocks the server while it walks the whole keyspace. A `keys()` call or a `KEYS`
command in application code is a finding.

## PY-SQLITE-163 — Enable SQLite foreign keys on every connection
SQLite ignores foreign-key constraints unless each connection runs `PRAGMA foreign_keys = ON`. Code
that opens `sqlite3` connections, or a SQLAlchemy engine on SQLite, issues it on connect; a
connection factory without it is a finding.

## PY-IMAGE-164 — Convert image modes before saving
Before saving with Pillow, images are converted to a mode the target format supports, for example
`img.convert("RGB")` before JPEG, with any alpha channel flattened onto an explicit background.
Saving an `RGBA`, `P` or `LA` image as JPEG without conversion is a finding.

## PY-PROTOBUF-165 — Never hand-edit generated protobuf code
Files produced by `protoc` or `grpc_tools` (`*_pb2.py`, `*_pb2_grpc.py`) are regenerated from the
`.proto` sources, never edited by hand. A diff touching generated code without the matching `.proto`
change and regeneration is a finding.
