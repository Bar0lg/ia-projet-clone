# Terraform and infrastructure-as-code rules

Conventions for the Terraform modules and root configurations that describe our cloud
infrastructure. One rule per `##` section.

---

## TF-001 — Pin provider versions
Every provider appears in `required_providers` with a `source` and a pessimistic constraint such as
`version = "~> 5.40"`. A provider without a version constraint, or with only `>=`, lets `terraform
init` pull a new major version and is a finding.

## TF-002 — Constrain the Terraform version
Each root module declares `required_version` in its `terraform` block, matching the version used in
CI. A root module without it, or with a constraint that admits an untested major release, is a
finding.

## TF-003 — Remote state with locking
State lives in a remote backend with locking (S3 with a lock table or lockfile, GCS, Terraform
Cloud). A `*.tfstate` or `*.tfstate.backup` file committed to the repository, or a root module
running on local state, is a finding.

## TF-004 — Pin module sources
Registry modules pin `version`, and git sources pin `?ref=` to a tag or commit. A module sourced
from a branch such as `main`, or with no version at all, changes underneath you on the next `init`
and is a finding.

## TF-005 — Typed, documented variables
Every `variable` block declares a `type` and a `description`, and structured inputs use
`object({...})` rather than `any` or `map(any)`. An untyped or undocumented variable is a finding.

## TF-006 — Mark sensitive values
Variables and outputs carrying passwords, keys or connection strings set `sensitive = true`, so that
plans and CI logs redact them. Exposing such a value through an unmarked `output` is a finding.

## TF-007 — Validate constrained inputs
Variables with a restricted domain (environment names, CIDR blocks, instance sizes) carry a
`validation` block with a clear `error_message`. Accepting any string where only a few values are
meaningful is a finding.

## TF-008 — Prefer `for_each` to `count` for named collections
Collections of distinct resources (users, buckets, subnets) use `for_each` over a map or set, so
removing one item does not re-index and recreate the others. `count` over a list of names is a
finding; `count` stays fine for an on/off toggle.

## TF-009 — No hard-coded account-specific identifiers
AMI IDs, account numbers, availability zones and ARNs are looked up with data sources or passed in
as variables, not pasted as literals. A literal `ami-0abc...` or a twelve-digit account ID inside a
resource block is a finding.

## TF-010 — Tag through provider defaults
Mandatory tags (owner, environment, cost centre) are set once in the provider's `default_tags` and
extended per resource with `merge`. A taggable resource missing a mandatory tag, or repeating the
whole tag set by hand, is a finding.

## TF-011 — No world-open ingress
Security group and firewall rules do not allow `0.0.0.0/0` or `::/0` ingress, except on ports 80 and
443 of public load balancers. SSH, RDP or database ports open to the internet are a finding.

## TF-012 — Block public access to storage buckets
Every S3 bucket has an `aws_s3_bucket_public_access_block` with all four settings true (or the
equivalent on other clouds), unless it is a documented public website bucket. A bucket without one,
or with a public ACL, is a finding.

## TF-013 — Encrypt data at rest
Databases, volumes, buckets, queues and snapshots enable encryption at rest, with a customer-managed
KMS key where the data classification requires it. A storage resource whose encryption is disabled
or left implicit is a finding.

## TF-014 — No wildcard IAM policies
IAM policy documents, preferably built with `aws_iam_policy_document`, list specific actions and
resource ARNs. `"Action": "*"`, `"Resource": "*"` on write actions, or attaching
`AdministratorAccess` to a workload role is a finding.

## TF-015 — Protect stateful resources from destruction
Databases, buckets holding data and KMS keys set `lifecycle { prevent_destroy = true }` as well as
the provider's own deletion-protection flag. A stateful production resource without both is a
finding.

## TF-016 — Review the plan, not only the code
Merge requests that change infrastructure include the `terraform plan` summary. A plan that destroys
or replaces a stateful resource (`-/+`, "forces replacement") without an explicit note in the merge
request description is a finding.

## TF-017 — Refactor with `moved` blocks
Renaming a resource or moving it into a module is done with a `moved { from = ..., to = ... }`
block, not with a hand-run `terraform state mv` or a destroy-and-recreate. A rename without a
`moved` block is a finding.

## TF-018 — No provisioners for configuration
`local-exec` and `remote-exec` provisioners are not used to configure machines or call APIs; use
cloud-init `user_data`, images built with Packer, or a native resource. A new provisioner block
without a justifying comment is a finding.

## TF-019 — Avoid redundant `depends_on`
Dependencies are expressed through attribute references, which Terraform orders automatically. An
explicit `depends_on` that duplicates an existing reference, or one placed on a whole module without
naming the hidden dependency, is a finding.

## TF-020 — Standard module layout
Each module separates `main.tf`, `variables.tf`, `outputs.tf` and `versions.tf`, and has a README
listing its inputs and outputs. Variables or provider requirements scattered in other files, or a
module with no README, are a finding.

## TF-021 — Separate state per environment
Each environment (dev, staging, prod) has its own root module or backend key and therefore its own
state. One state file spanning several environments, or switching environment by editing variables
in place, is a finding.

## TF-022 — Format, validate and lint in CI
`terraform fmt -check`, `terraform validate` and `tflint` run in CI and must pass. A change that is
not `fmt`-clean, or one that disables a lint rule without an explanatory comment, is a finding.

## TF-023 — Commit the dependency lock file
The `.terraform.lock.hcl` file is committed and updated deliberately with `terraform init -upgrade`.
Listing it in `.gitignore`, or changing a provider constraint without the matching lock-file update,
is a finding.

## TF-024 — Don't look up what you manage
A `data` source must not read back an object created by a resource in the same configuration;
reference that resource's attributes instead. Such a self-lookup breaks the first apply and hides
the dependency, and is a finding.

## TF-025 — State the time zone of every schedule
Scheduled scaling actions, backup plans and maintenance windows declare their time zone explicitly
(`time_zone = "Europe/Paris"`) or document that the cron expression is in UTC. A schedule whose zone
is only implied by a provider default is a finding.

## TF-026 — Production databases keep backups and redundancy
Production database instances set a `backup_retention_period` of at least seven days,
`deletion_protection = true` and multi-AZ placement. Disabling or omitting any of these in a
production configuration is a finding.

## TF-027 — Turn on audit and access logs
Accounts enable CloudTrail, VPCs enable flow logs, and buckets and load balancers serving production
traffic send access logs to the central logging bucket. A new network or storage resource without
its access logging is a finding.

## TF-028 — Output only what consumers need
Module outputs expose specific attributes such as an ID, an ARN or an endpoint, not whole resource
objects. Outputting an entire resource leaks internals and widens the module's contract; it is a
finding.

## TF-029 — Justify `ignore_changes`
A `lifecycle { ignore_changes = [...] }` list names specific attributes and carries a comment saying
which other system manages them. `ignore_changes = all`, or an unexplained entry, hides drift and is
a finding.

## TF-030 — Consistent resource naming
Resource labels use `snake_case` without repeating the type (`aws_s3_bucket.logs`, not
`aws_s3_bucket.logs_bucket`), and cloud-side names are built from a shared `local.name_prefix`. Ad
hoc names that mix conventions are a finding.
