# Java rules

Conventions for the Java services, including their Spring and JPA code. One rule per `##` section.

---

## JAVA-001 — Use `java.time` for instants
Timestamps are `Instant`, or `OffsetDateTime` / `ZonedDateTime` with an explicit zone, obtained from
an injected `Clock`. New uses of `java.util.Date`, `Calendar`, `SimpleDateFormat`, or
`LocalDateTime.now()` for a stored event are a finding.

## JAVA-002 — `BigDecimal` for money, never `double`
Monetary amounts are `BigDecimal` (or `long` minor units) with an explicit scale and `RoundingMode`,
created with `new BigDecimal("19.99")` or `BigDecimal.valueOf`. Prices or totals held in `double` or
`float`, or compared with `equals` instead of `compareTo`, are a finding.

## JAVA-003 — Name the charset of every reader and writer
Text I/O states its charset: `Files.newBufferedReader(path, StandardCharsets.UTF_8)`, `new
String(bytes, UTF_8)`, `getBytes(UTF_8)`. `FileReader`, `FileWriter` or `InputStreamReader` without
a charset argument depend on the platform default and are a finding.

## JAVA-004 — No structural changes inside a for-each loop
Never call `remove` or `add` on a collection inside a for-each loop over that same collection: it
throws `ConcurrentModificationException` or skips elements. Use `removeIf`, an explicit
`Iterator.remove()`, or collect into a new list; anything else is a finding.

## JAVA-005 — Measure durations with a monotonic clock
Elapsed time is measured from `System.nanoTime()` differences, or a `Duration` built from them,
never by subtracting `System.currentTimeMillis()` or `Instant.now()` values, which jump when the
wall clock is adjusted. Wall-clock timing of a duration is a finding.

## JAVA-006 — Override `equals` and `hashCode` together
A class that overrides `equals` also overrides `hashCode` from the same fields, and neither depends
on state that changes while instances sit in hash-based collections. Overriding only one of the two
is a finding.

## JAVA-007 — Use `Optional` only as a return type
`Optional` is returned from methods that may have no result and is never used for fields, parameters
or collection elements. Calling `Optional.get()` without a presence check, instead of `orElseThrow`,
`map` or `orElse`, is a finding.

## JAVA-008 — Return empty collections, not `null`
Methods returning a `List`, `Set`, `Map` or array return an empty instance such as `List.of()` when
there is nothing to return. Returning `null` forces every caller to add a null check and is a
finding.

## JAVA-009 — Prefer records and immutable value types
Data carriers are `record`s or classes with `final` fields and no setters, and collections they
expose are unmodifiable (`List.copyOf`). A new mutable DTO with public setters where a record would
fit is a finding.

## JAVA-010 — Compare strings with `equals`
String contents are compared with `equals`, `equalsIgnoreCase` or `Objects.equals`, never with `==`
or `!=`, which compare references. Any `==` between two `String` expressions is a finding, even if
it happens to pass with interned literals.

## JAVA-011 — No side effects in stream pipelines
Lambdas passed to `map`, `filter` and `sorted` are pure, and results are gathered with `collect` or
`toList()`, not by adding to an external collection from `forEach` or `peek`. A stream that mutates
outside state is a finding.

## JAVA-012 — Restore the interrupt flag
Code that catches `InterruptedException` either propagates it or calls
`Thread.currentThread().interrupt()` before continuing. Catching it and carrying on, or wrapping it
without restoring the flag, breaks cancellation and is a finding.

## JAVA-013 — Use executors, not raw threads
Background work is submitted to an `ExecutorService`, a virtual-thread executor where appropriate,
that is shut down when the application stops. A `new Thread(...).start()` in application code, or an
executor that is never shut down, is a finding.

## JAVA-014 — Constructor injection in Spring
Spring beans receive their dependencies through a single constructor assigning `final` fields. Field
injection with `@Autowired` on a field, or setter injection for a mandatory dependency, is a
finding.

## JAVA-015 — Put `@Transactional` where the proxy can see it
`@Transactional` goes on public methods of Spring beans that are called from another bean.
Annotating a private method, or calling a transactional method through `this` within the same class,
silently runs without a transaction and is a finding.

## JAVA-016 — Lazy JPA associations by default
`@ManyToOne` and `@OneToOne` associations declare `fetch = FetchType.LAZY` explicitly, and the data
a use case needs is loaded with a fetch join or an entity graph. An eager association added to an
entity is a finding.

## JAVA-017 — No Lombok `@Data` on JPA entities
JPA entities do not use Lombok `@Data`, or `@EqualsAndHashCode` and `@ToString` over all fields,
which touch lazy associations and break entity identity. Write identifier-based `equals` and
`hashCode` and a `toString` limited to scalar fields.

## JAVA-018 — Typed configuration properties
Configuration is bound to validated `@ConfigurationProperties` records grouped by prefix, rather
than read through scattered `@Value("${...}")` strings. A new `@Value` for a setting that belongs to
an existing properties class is a finding.

## JAVA-019 — Exhaustive `switch` over enums and sealed types
Switches over an `enum` or a `sealed` hierarchy are switch expressions with arrow labels, so the
compiler checks exhaustiveness. A `default` branch that hides newly added constants, or a
fall-through `case` without `break`, is a finding.

## JAVA-020 — No raw generic types
Generic types are always parameterised (`List<Order>`, `Map<String, Integer>`). Raw `List` or
`Class` types and unchecked casts are a finding unless isolated in one method annotated
`@SuppressWarnings("unchecked")` with a justifying comment.

## JAVA-021 — Enforce null contracts at construction
Constructors and factory methods check mandatory arguments with `Objects.requireNonNull(arg,
"arg")`, and packages declare nullness with `@NullMarked` or `@Nullable` annotations. A public
constructor that silently stores `null` in a required field is a finding.

## JAVA-022 — No mutable static state
Classes keep no mutable `static` fields such as caches, counters or singletons with setters; shared
components are beans or explicitly passed objects. A non-final static field, or a `static final`
collection modified at runtime, is a finding.

## JAVA-023 — Enums instead of constant families
A closed set of values is an `enum`, with `EnumMap` or `EnumSet` for lookups, not a group of `int`
or `String` constants. A new family of `public static final int STATUS_...` constants is a finding.

## JAVA-024 — Build strings in loops with `StringBuilder`
String concatenation inside loops uses a `StringBuilder`, `String.join` or `Collectors.joining`.
Using `+=` on a `String` in a loop over a collection of unbounded size copies the text quadratically
and is a finding.

## JAVA-025 — Package-private by default
Classes and members start package-private and become `public` only when they are part of the
module's API; internal packages are not exported in `module-info.java`. A new `public` class used
only inside its own package is a finding.

## JAVA-026 — Don't expose JPA entities from controllers
REST controllers accept and return dedicated DTO records mapped from entities, never JPA entities
themselves. Serialising an entity leaks columns, triggers lazy loading while the response is
rendered, and is a finding.

## JAVA-027 — Use `var` only when the type is obvious
Local `var` is used when the type is evident from the right-hand side, as in `var orders = new
ArrayList<Order>()`. A `var` initialised from a method call whose return type is not obvious, or a
diamond that infers `Object`, is a finding.

## JAVA-028 — Always annotate overrides
Every method that overrides or implements a supertype method carries `@Override`. A missing
annotation lets a typo in the signature silently create an unrelated overload, and is a finding.

## JAVA-029 — Build comparators from combinators
Orderings are built with `Comparator.comparing(...)`, `thenComparing` and `reversed()`. A
hand-written `compare` that returns `a - b` on integers, which overflows for large or negative
values, is a finding.

## JAVA-030 — Use pattern matching for `instanceof`
Type tests bind a variable directly, as in `if (shape instanceof Circle circle)`, or use a
pattern-matching `switch`. An `instanceof` check followed by an explicit cast of the same expression
is a finding in new code.
