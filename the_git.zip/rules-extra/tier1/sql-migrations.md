# SQL schema migration rules (tier 1)

Conventions for database schema migrations and DDL changes, written for PostgreSQL unless stated.
One rule per `##` section.

---

## SQLM-001 — Applied migrations are immutable
Once a migration has been merged or applied to any shared environment, its file is never edited,
renamed or deleted; a further change goes into a new migration. A diff that modifies an existing
migration file is a finding.

## SQLM-002 — Every migration states how to roll back
Each migration provides a down step that restores the previous schema, or is explicitly marked
irreversible with a comment explaining why and how to recover. A new migration with an empty or
missing rollback and no such note is a finding.

## SQLM-003 — Add NOT NULL columns in steps
Adding a `NOT NULL` column to an existing populated table is done in steps: add it nullable or with
a constant default, backfill, then add the constraint. A single `ADD COLUMN ... NOT NULL` without a
default on an existing table is a finding.

## SQLM-004 — Build indexes on large tables without blocking writes
On PostgreSQL, indexes on existing large tables are created with `CREATE INDEX CONCURRENTLY` in a
migration that runs outside a transaction (and dropped with `DROP INDEX CONCURRENTLY`). A plain
`CREATE INDEX` on a busy production table is a finding, because it blocks writes.

## SQLM-005 — Expand, then contract
Renaming or removing a column that deployed code still reads is split across releases: add the new
structure, migrate code to it, drop the old one in a later release. A rename or drop in the same
change as the code switch is a finding.

## SQLM-006 — Keep data backfills separate and batched
Schema changes and data migrations live in separate migrations. A backfill that rewrites many rows
runs in bounded batches, each in its own transaction. A single `UPDATE` over an entire large table
inside a schema migration is a finding.

## SQLM-007 — Timestamps are `timestamptz` in UTC
Columns recording a point in time use `timestamp with time zone` (`timestamptz`) and the database
session runs in UTC. A new `timestamp without time zone`, `datetime` or text column used to store
instants is a finding; local wall-clock types are only for calendar values.

## SQLM-008 — Money columns are exact numerics
Monetary amounts are stored as `numeric(p, s)` with an explicit scale, or as an integer count of
minor units such as cents, together with a currency column. A money column declared `real`, `float`,
`double precision` or `money` is a finding.

## SQLM-009 — Foreign keys are declared and indexed
A column that references another table declares a `FOREIGN KEY` constraint with an explicit `ON
DELETE` behaviour, and the referencing column is indexed. A reference stored without a constraint,
or a foreign key column without an index, is a finding.

## SQLM-010 — Every table has a suitable primary key
Each new table declares a primary key. Surrogate keys on tables expected to grow use `bigint`
identity columns or UUIDs, not 32-bit `integer` or `serial`. A table without a primary key, or a new
`serial` key on a high-volume table, is a finding.

## SQLM-011 — Set a lock timeout in DDL migrations
Migrations that alter existing tables first set `lock_timeout` (and a `statement_timeout`), so that
a DDL statement waiting for a lock fails quickly instead of queueing all traffic behind it. An
`ALTER TABLE` on a production table without a lock timeout is a finding.

## SQLM-012 — Add constraints without long validation locks
On large existing tables, add `CHECK` and foreign key constraints as `NOT VALID`, then run `VALIDATE
CONSTRAINT` in a separate step, which takes a weaker lock. Adding such a constraint with full
validation in one statement on a large table is a finding.

## SQLM-013 — No volatile defaults when adding columns to large tables
On PostgreSQL, `ADD COLUMN` with a constant default is instant, but a volatile default such as
`gen_random_uuid()` or `clock_timestamp()` rewrites every row under an exclusive lock. Adding a
column with a volatile default to a large existing table is a finding; add it, then backfill.

## SQLM-014 — Name constraints and indexes explicitly
Indexes, unique constraints, foreign keys and check constraints are given explicit names following
the project convention (for example `ix_orders_customer_id`, `fk_orders_customer`). Relying on
database-generated names is a finding, because later migrations cannot reference them reliably.

## SQLM-015 — Destructive changes need a deprecation trail
`DROP TABLE`, `DROP COLUMN` and `TRUNCATE` in a migration require that the object was unused for at
least one release and that the MR states how the data is backed up or archived. A destructive
statement without that justification is a finding.

## SQLM-016 — Avoid table-rewriting type changes
Changing a column's type in a way that rewrites the table or invalidates its indexes (`integer` to
`bigint`) on a large table is done by adding a new column, backfilling and switching over. An
in-place `ALTER COLUMN ... TYPE` there is a finding.

## SQLM-017 — Enforce uniqueness in the database
A business rule that a value is unique (email, external reference, slug) is enforced by a `UNIQUE`
constraint or unique index, case-insensitive where the rule requires it. Uniqueness checked only by
a query in application code is a finding.

## SQLM-018 — Migrations do not import application code
A migration uses plain SQL or the migration tool's own schema operations, never the application's
current ORM models or services, which will change after the migration is written. Importing
application modules into a migration file is a finding.

## SQLM-019 — One logical change per migration
A migration file contains one coherent change with a descriptive name, such as adding a table with
its indexes. A migration that bundles unrelated tables or features, or is named generically
(`update`, `fix`), is a finding, because it cannot be reviewed or reverted independently.

## SQLM-020 — Migration history stays linear
Migrations form a single ordered history. A change that introduces a second head, two migrations
with the same revision or sequence number, or a migration whose parent is not the current latest
revision is a finding; rebase it onto the latest migration.
