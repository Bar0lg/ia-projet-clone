# JavaScript and TypeScript rules (tier 1)

Conventions for browser, Node.js and React code written in JavaScript or TypeScript. One rule per
`##` section.

---

## JS-001 — Strict equality only
Compare with `===` and `!==`. Loose `==` and `!=` apply type coercion (`"0" == false` is true) and
are a finding, except the idiom `x == null`, which deliberately matches both `null` and `undefined`.

## JS-002 — No `var`
Declare bindings with `const` by default and `let` only when the variable is reassigned. A new `var`
declaration is a finding: it is function-scoped, hoisted and shared across loop iterations, which
causes closure and shadowing bugs.

## JS-003 — No floating promises
Every promise is awaited, returned, or handled with `.catch()`. Calling an async function or a
promise-returning API and discarding the result is a finding, because its rejection becomes an
unhandled rejection and its completion is never ordered with the caller.

## JS-004 — No async callbacks in `forEach`
`Array.prototype.forEach` ignores the promises returned by an `async` callback, so the loop neither
waits nor propagates errors. An `async` function passed to `forEach` is a finding; use `for...of`
with `await`, or `Promise.all` over `map`.

## JS-005 — Check `response.ok` after `fetch`
`fetch` resolves normally on HTTP 4xx and 5xx responses; it rejects only on network failure. Reading
the body of a `fetch` response without checking `response.ok` or `response.status` first is a
finding.

## JS-006 — No `any` in TypeScript
Do not annotate values as `any` or cast through `as any`; use a precise type, a generic, or
`unknown` narrowed with a type guard. A new explicit `any` in TypeScript code is a finding because
it disables type checking for everything it touches.

## JS-007 — Justify non-null assertions
The non-null assertion operator `!` (`user!.id`) tells the compiler to trust that a value is present
without checking. A new `!` assertion without a preceding check or an explaining comment is a
finding; narrow the value with a condition or optional chaining instead.

## JS-008 — No `@ts-ignore`
Do not silence the TypeScript compiler with `// @ts-ignore` or `// @ts-nocheck`. When an error must
be suppressed, use `// @ts-expect-error` followed by the reason, so the comment fails once the error
disappears. A bare `@ts-ignore` is a finding.

## JS-009 — No raw HTML from untrusted data
Do not assign untrusted strings to `innerHTML`, `outerHTML` or `document.write`, nor pass them to
React's `dangerouslySetInnerHTML`, without sanitising them with a vetted library. Setting text
through `textContent` or JSX interpolation is safe; raw HTML from user data is a finding.

## JS-010 — No `eval` or string-compiled code
Do not call `eval`, `new Function(...)`, or `setTimeout`/`setInterval` with a string argument.
Compiling a string into code at runtime is a finding, both as an injection risk and because it
defeats the Content Security Policy and static analysis.

## JS-011 — Parse numbers explicitly
Call `parseInt` with an explicit radix (`parseInt(s, 10)`), and use `Number(s)` with an
`Number.isNaN` check when the whole string must be numeric. A `parseInt` without radix, or a parsed
number used without handling `NaN`, is a finding.

## JS-012 — Complete React hook dependency arrays
Every value from the component scope that a `useEffect`, `useMemo` or `useCallback` callback reads
appears in its dependency array. A missing dependency, or an `eslint-disable` of
`react-hooks/exhaustive-deps` without a comment explaining why, is a finding.

## JS-013 — Stable keys for rendered lists
Elements rendered from an array carry a `key` derived from a stable identifier of the item. Using
the array index or a random value as `key` for a list that can be reordered, filtered or inserted
into is a finding.

## JS-014 — Never mutate React state or props
Update React state by passing a new object or array to the setter (spread, `map`, `filter`).
Mutating state in place (`state.items.push(x)`, `obj.count++` followed by `setState(obj)`) or
assigning to `props` is a finding, because React skips the re-render.

## JS-015 — Use `??` for defaults when falsy values are valid
Provide defaults with the nullish coalescing operator `??`, which replaces only `null` and
`undefined`. Using `||` for a default where `0`, `""` or `false` are legitimate values (`limit ||
50`, `name || "anonymous"`) is a finding, because the valid value is silently replaced.

## JS-016 — Throw and reject with `Error` objects
Throw instances of `Error` or a subclass, and reject promises with them, so a stack trace and a
`name` are available. `throw "failed"`, `throw { code: 1 }` or `Promise.reject("timeout")` with a
plain string or object is a finding.

## JS-017 — No synchronous I/O in Node.js request paths
Server code that handles requests or messages uses the asynchronous `fs/promises`, `zlib` and
`crypto` APIs. Calling `readFileSync`, `writeFileSync`, `execSync` or other `*Sync` functions inside
a request handler is a finding, because it stalls every concurrent request.

## JS-018 — Clean up listeners, timers and subscriptions
Code that calls `addEventListener`, `setInterval`, `setTimeout` or subscribes to an observable also
removes it when the owner goes away, for example in the cleanup function returned by `useEffect`. A
subscription without a matching teardown is a finding.

## JS-019 — No `for...in` over arrays
Iterate arrays with `for...of`, `forEach` or index loops. `for...in` enumerates string keys,
including inherited enumerable properties, in no guaranteed numeric order; using it on an array or
array-like value is a finding.

## JS-020 — Validate external data instead of casting it
Data from `JSON.parse`, `fetch`, `localStorage` or message events has type `unknown` until checked.
Asserting its shape with `as SomeType` without runtime validation (a schema library or a type guard)
is a finding, because the compiler then trusts an unchecked value.
