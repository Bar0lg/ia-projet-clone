# Extended Python rules (tier 1)

Rules added after the first review season, as the team met new classes of defects. One rule per
`##` section.

---

## PY-TIME-011 — Timezone-aware datetimes only
Store, compare and serialise datetimes as timezone-aware values in UTC: use
`datetime.now(timezone.utc)`, never `datetime.now()` without a zone or the deprecated
`datetime.utcnow()`. A naive datetime that is persisted, compared or sent over the wire is a finding.

## PY-MONEY-012 — Never use float for money
Represent monetary amounts with `decimal.Decimal` (or integer minor units such as cents), and round
explicitly with a stated rounding mode. Computing prices, totals, taxes or balances with `float` is a
finding: binary floating point cannot represent most decimal amounts exactly.

## PY-IO-013 — Explicit text encoding
Every text-mode `open()`, `Path.read_text()` and `Path.write_text()` passes `encoding=` explicitly
(normally `"utf-8"`). Relying on the platform's locale encoding makes the same code read or write
different bytes on Windows and Linux, and is a finding.

## PY-ITER-014 — Don't mutate a collection while iterating over it
Never add or remove items of a list, dict or set inside a loop that iterates over that same
collection. Build a new collection (a comprehension) or iterate over a copy. Removing items during
iteration silently skips elements and is a finding.

## PY-IDENTITY-015 — Use `is` only for singletons
Use `is` and `is not` only to compare with `None`, `True`, `False`, `Ellipsis` or a dedicated
sentinel object. Comparing with `is` against a number, string, tuple or other literal relies on
interning, which is an implementation detail, and is a finding; use `==`.

## PY-EQHASH-016 — `__eq__` and `__hash__` stay consistent
A class that defines `__eq__` either defines a `__hash__` computed from the same immutable fields or
sets `__hash__ = None`. Hashing on fields that `__eq__` ignores, or on fields that can change after
insertion, breaks sets and dict keys and is a finding.

## PY-EQTYPE-017 — Comparison methods return `NotImplemented` for foreign types
Rich comparison methods such as `__eq__` and `__lt__` return `NotImplemented` when the other operand
has an unsupported type, so Python can try the reflected operation. Returning `False`, raising, or
reading attributes of the other operand without checking its type is a finding.

## PY-STARIMPORT-018 — No star imports
Do not write `from module import *` in application or library code; import the names you use
explicitly. A package that re-exports names lists them in `__all__`. A new star import is a finding
because it hides where names come from.

## PY-IMPORTTIME-019 — No work at import time
Importing a module must not open connections, send requests, read or write files, start threads or
reconfigure global state. Module-level constants and creating a module logger are fine; module-level
statements that perform I/O or start work when the module is imported are a finding.

## PY-CIRCULAR-020 — Break import cycles instead of hiding them
Two modules that import each other indicate a layering problem: move the shared code to a third
module or invert the dependency. Adding an `import` statement inside a function body only to dodge a
circular import is a finding.

## PY-EXIT-021 — Library code never exits the process
Only the program's entry point decides to stop the process. Calling `sys.exit()`, `exit()`, `quit()`
or `os._exit()` inside a library function, a class method or a request handler is a finding; raise a
specific exception and let the caller decide.

## PY-CLI-022 — Command-line tools report failure through the exit status
A command-line entry point finishes with exit status 0 only on success and with a non-zero status on
any failure. A `main()` whose failure path ends normally, so that the shell sees 0, is a finding
because scripts and CI jobs cannot detect the failure.

## PY-MAINGUARD-023 — Guard script entry points
A module that can be both imported and run as a script puts its top-level actions under `if __name__
== "__main__":` and calls a `main()` function from there. Script actions executing unguarded at
module level are a finding.

## PY-LRUCACHE-024 — No `lru_cache` on instance methods
Do not decorate instance methods with `functools.lru_cache` or `functools.cache`: the cache keeps a
reference to every `self` it has seen, so instances are never freed, and it is shared by all
instances. Use `functools.cached_property` or a per-instance dict; such a decorator is a finding.

## PY-COPY-025 — Shallow copies do not protect nested data
`dict.copy()`, `list.copy()`, slicing and `copy.copy()` copy only the outer container. Mutating a
nested list or dict reached through a shallow copy also changes the original and is a finding; use
`copy.deepcopy()` or rebuild the nested parts explicitly.

## PY-HASH-026 — Built-in `hash()` is not stable across processes
The value of `hash()` for `str` and `bytes` changes between interpreter runs because of hash
randomisation. Persisting it, sending it to another process, or using it for sharding, bucketing or
cache file names is a finding; use a `hashlib` digest instead.

## PY-OBJID-027 — `id()` is not a durable identifier
`id(obj)` is unique only while the object is alive and is reused once it is freed. Storing an `id()`
value in a database, a message or a long-lived mapping as if it identified the object is a finding;
use an explicit identifier field.

## PY-DEFAULTDICT-028 — Group values with `defaultdict` or `setdefault`
When grouping values into lists or sets keyed by some field, use `collections.defaultdict(list)` or
`groups.setdefault(key, []).append(value)`. The two-step pattern `if key not in groups: groups[key]
= []` followed by an append is a finding.

## PY-SORTKEY-029 — Sort with a key function
Sort with `key=` (an attribute, a tuple of fields, `operator.attrgetter`) and `reverse=True` rather
than with a comparison function wrapped in `functools.cmp_to_key` or a hand-written sorting loop. A
custom comparison or a manual sort where a key function would do is a finding.

## PY-PROPERTY-030 — Properties are cheap and free of side effects
A `@property` getter returns a value derived from the object's state without I/O, mutation or
expensive computation, and gives the same result when read twice. A getter that queries a database,
or modifies state is a finding; make it an explicit method.

## PY-CASEFOLD-031 — Case-insensitive comparison uses `casefold()`
Compare text case-insensitively with `a.casefold() == b.casefold()`, not with `lower()` or
`upper()`, which mishandle characters such as the German sharp s. Using `lower()` or `upper()` to
implement a case-insensitive match or to build a case-insensitive lookup key is a finding.

## PY-REGEX-032 — Regular expressions are raw strings
Write regular-expression patterns as raw string literals, for example `r"\d+\.\d+"`. A pattern
written as an ordinary string literal containing backslash escapes, which Python may reinterpret or
flag with an invalid-escape warning, is a finding.

## PY-ANYALL-033 — Pass generators to `any()` and `all()`
Call `any()` and `all()` on a generator expression, not on a list comprehension, so that evaluation
stops at the first decisive element. `any([...])` or `all([...])`, which builds a complete temporary
list before testing it, is a finding.

## PY-PROTOCOL-034 — Describe duck types with `typing.Protocol`
When a function accepts any object that offers certain methods, declare that expectation as a
`typing.Protocol` and annotate the parameter with it. Dispatching on capabilities through
`hasattr()` probes or `isinstance` chains over unrelated concrete classes is a finding.

## PY-LOOPELSE-035 — An `else` on a loop needs a `break`
The `else` clause of a `for` or `while` loop runs only when the loop ends without `break`. A loop
`else` on a loop that contains no `break` is a finding, because it always runs and misleads the
reader; move its code after the loop.

## PY-SENTINEL-036 — Use a sentinel when `None` is a valid value
When `None` is a meaningful argument or stored value, for example "clear this field", detect "not
provided" with a private module-level sentinel such as `_MISSING = object()`. Code that cannot tell
an omitted argument from an explicit `None` in that situation is a finding.

## PY-BOOLINT-037 — Remember that `bool` is an `int`
`bool` is a subclass of `int`, so `isinstance(True, int)` is true and `True + True == 2`. Type
dispatch with `isinstance(x, int)` that must treat flags differently but does not test for `bool`
first, or arithmetic performed on boolean flags, is a finding.

## PY-SUPER-038 — Overridden initialisers call `super()`
A subclass that overrides `__init__`, `__post_init__` or `__init_subclass__` calls the parent
implementation through `super()`, unless skipping it is deliberate and commented. Omitting the
parent call, or calling it through a hard-coded parent class name in a cooperative hierarchy, is a
finding.

## PY-ISINSTANCE-039 — Check types with `isinstance`
Test an object's type with `isinstance(obj, Cls)` or a tuple of classes, which respects subclasses.
Writing `type(obj) == Cls` or `type(obj) is Cls` is a finding unless an exact-type check is really
required and the reason is stated in a comment.

## PY-ABC-040 — Abstract interfaces use the `abc` module
Base classes meant to be subclassed declare their required methods with `abc.ABC` and
`@abstractmethod`, so an incomplete subclass fails at instantiation. Writing `raise NotImplemented`,
which raises a `TypeError` because it is a constant, is a finding; the exception is
`NotImplementedError`.

## PY-SETORDER-041 — Don't depend on set iteration order
The iteration order of a `set` or `frozenset` is arbitrary and, for strings, changes between runs.
Producing output, file contents, API responses or generated identifiers from a set's iteration order
without passing it through `sorted()` is a finding.

## PY-CLOSURE-042 — Bind loop variables captured by closures
A `lambda` or nested function created in a loop and called later sees the loop variable's final
value, not its value at creation. Storing such closures as callbacks or handlers without binding the
value through `functools.partial` or a keyword default is a finding.

## PY-INPLACE-043 — Don't use the result of an in-place method
`list.sort()`, `list.append()`, `list.reverse()`, `dict.update()` and `random.shuffle()` mutate
their receiver and return `None`. Assigning, returning or chaining their result, as in `items =
items.sort()`, is a finding; use `sorted()` or `reversed()` when a new value is needed.

## PY-TUPLE-044 — No accidental one-element tuples
A trailing comma after a single value creates a tuple, as in `retries = 3,` or `return name,`. Such
a trailing comma where a scalar is intended is a finding; when a one-element tuple is really wanted,
write it in parentheses as `(value,)`.

## PY-USERDICT-045 — Don't subclass `dict` or `list` to change their behaviour
Subclassing built-in `dict`, `list` or `str` and overriding `__getitem__` or `__setitem__` is
unreliable, because `get()`, `update()` and the constructor bypass the override. Such a subclass is
a finding; derive from `collections.UserDict`, `collections.UserList` or a `collections.abc` base.
