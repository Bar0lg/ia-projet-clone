# Container rules

Conventions for Dockerfiles, built images and Compose files used to package and run our services.
One rule per `##` section.

---

## DOCKER-001 — Pin base images to a version and digest
Every `FROM` names an explicit version tag and, for release images, an `@sha256:` digest. A `FROM`
with no tag, with `:latest`, or with a floating major tag such as `:stable` is a finding because
rebuilds silently change the base.

## DOCKER-002 — Prefer slim or distroless runtime bases
The final stage of an image uses a slim, minimal or distroless base that contains only what the
service needs at run time. A runtime stage built on a full distribution or an SDK image with
compilers and package managers is a finding.

## DOCKER-003 — Build in one stage, run from another
Compilers, build tools and source trees stay in a named build stage; the runtime stage copies only
the built artefacts with `COPY --from=build`. A single-stage Dockerfile that ships its toolchain in
the production image is a finding.

## DOCKER-004 — Run as a non-root user
The final stage declares a `USER` with a numeric, non-zero UID that owns only what it must write. An
image whose process runs as root, or that switches back to `USER root` after setup, is a finding.

## DOCKER-005 — Copy dependency manifests before the source
Copy the dependency manifest and lockfile, install dependencies, and only then copy the rest of the
source, so code changes reuse the cached dependency layer. A `COPY . .` placed before the dependency
installation step is a finding.

## DOCKER-006 — Install and clean up in the same layer
Package installation and cache removal happen in a single `RUN`, for example `apt-get update`,
`apt-get install` and removal of `/var/lib/apt/lists/*` chained together. An `apt-get update` in its
own `RUN`, or cleanup in a later layer, is a finding.

## DOCKER-007 — Install only the packages you asked for
Debian-based images install packages with `--no-install-recommends`, Alpine images with
`apk add --no-cache`. An `apt-get install` without `--no-install-recommends`, which pulls in
unrelated recommended packages, is a finding.

## DOCKER-008 — Maintain a `.dockerignore`
The build context excludes version-control metadata, local build output, editor files and
environment files through a `.dockerignore`. Adding a Dockerfile with `COPY . .` and no
`.dockerignore`, or removing entries from it, is a finding.

## DOCKER-009 — Use `COPY`, not `ADD`
Files are brought into the image with `COPY`. `ADD` also fetches URLs and unpacks archives
implicitly, so using it for plain files, or to download remote content without a checksum, is a
finding.

## DOCKER-010 — Exec form for `ENTRYPOINT` and `CMD`
`ENTRYPOINT` and `CMD` use the JSON exec form (`["server", "--port", "8080"]`) so the process is
PID 1 and receives `SIGTERM` directly. The shell form, which wraps the process in `/bin/sh -c` and
swallows signals, is a finding.

## DOCKER-011 — Reap child processes with an init
A container whose main process spawns children uses a minimal init (`tini`, `dumb-init`, or
`docker run --init`) as its entrypoint so zombies are reaped and signals forwarded. Running a
process supervisor or several services in one container is a finding.

## DOCKER-012 — Services declare a health check
Long-running service images declare a `HEALTHCHECK` (or the orchestrator's equivalent probe) that
exercises the service itself, not merely that the process exists. A new service image without any
health check, or one that only runs `true`, is a finding.

## DOCKER-013 — Use `WORKDIR`, not `cd`
Set the working directory with an absolute `WORKDIR` instruction. Changing directory with `cd`
inside `RUN` lines so that later steps depend on it, or a relative `WORKDIR`, is a finding.

## DOCKER-014 — No distribution upgrades in the Dockerfile
Do not run `apt-get upgrade`, `apt-get dist-upgrade` or `apk upgrade` while building. Security
updates come from rebuilding on a newer pinned base image; an upgrade step makes builds
unreproducible and is a finding.

## DOCKER-015 — Piped `RUN` commands fail on error
A `RUN` that pipes commands (for example `curl ... | tar -x`) is preceded by
`SHELL ["/bin/bash", "-o", "pipefail", "-c"]`, so a failure on the left of the pipe fails the
build. A piped `RUN` without `pipefail` is a finding.

## DOCKER-016 — Verify downloaded artefacts
Binaries and archives downloaded during the build are checked against a pinned checksum or
signature before use. Piping a remote installer straight into a shell (`curl ... | sh`), or
downloading without verification, is a finding.

## DOCKER-017 — Label images with OCI metadata
Images carry the standard `org.opencontainers.image.*` labels for source repository, revision and
version, set from build arguments by the pipeline. A release image with no source or revision label
is a finding.

## DOCKER-018 — Containers run in UTC
Runtime images set `TZ=UTC` and include the time-zone database (`tzdata`) when the service converts
times. Setting a local zone such as `Europe/Paris` in the image, or mounting the host's
`/etc/localtime`, is a finding.

## DOCKER-019 — Containers use a UTF-8 locale
Runtime images set `LANG=C.UTF-8` (and `LC_ALL` where tools require it), so every process reads and
writes text as UTF-8. An image that leaves the locale unset, falling back to `POSIX` ASCII, or sets
a legacy single-byte locale is a finding.

## DOCKER-020 — Set ownership when copying
Give files the right owner with `COPY --chown=app:app` or `--chmod`, not with a later
`RUN chown -R` that duplicates every file into a new layer. A `chmod -R 777` anywhere in a
Dockerfile is a finding.

## DOCKER-021 — No remote access or debugging tools in production images
Production images contain no SSH server, shell-based debugging toolkits or editors. Installing
`openssh-server`, `vim`, `strace` or similar in a runtime stage is a finding; use an ephemeral debug
container instead.

## DOCKER-022 — `ARG` for build inputs, `ENV` for runtime defaults
Values needed only while building are `ARG`s; values the running process reads are `ENV`s or come
from the orchestrator. Using `ARG` to configure runtime behaviour, or redeclaring after `FROM` an
`ARG` that was never declared before it, is a finding.

## DOCKER-023 — Writable paths are declared
The image runs with a read-only root filesystem; the process writes only to a declared `VOLUME`, a
mounted directory, or `/tmp`. A service that writes logs, caches or uploads elsewhere in the image
filesystem is a finding.

## DOCKER-024 — No state in the container layer
Data that must survive a restart lives in a named volume, a bind mount or an external store, never
in the container's writable layer. A database or upload directory without a volume in a Compose or
deployment file is a finding.

## DOCKER-025 — Compose services are not privileged
Compose and deployment files never set `privileged: true`, add broad capabilities such as
`SYS_ADMIN`, or use `network_mode: host` for application services. Each of these in a reviewed
file is a finding unless a documented exception names the reason.

## DOCKER-026 — Never mount the Docker socket
Mounting `/var/run/docker.sock` into a container gives it root control of the host. A volume entry
or `-v` flag exposing the Docker socket to an application container is a finding.

## DOCKER-027 — Services declare resource limits
Every service in Compose or deployment files declares memory and CPU limits (`mem_limit`,
`deploy.resources.limits` or Kubernetes `resources`). A new service with no memory limit, which can
starve its neighbours on the host, is a finding.

## DOCKER-028 — Wait for dependencies with health conditions
Start-up ordering uses `depends_on` with `condition: service_healthy` backed by health checks, or
retry logic in the service. A `sleep 10` in an entrypoint script to wait for a database, or a bare
`depends_on` list relied on for readiness, is a finding.

## DOCKER-029 — Builds do not fetch moving sources
A Dockerfile does not `git clone` a branch or download an unversioned `latest` archive. Fetch a
pinned tag or commit, or copy the source from the build context; a build whose output depends on
the day it runs is a finding.

## DOCKER-030 — One concern per image
An image packages one service with one entrypoint. Bundling the application, its database and a
reverse proxy in one image, or selecting the role through an environment variable in a shell
entrypoint, is a finding.
