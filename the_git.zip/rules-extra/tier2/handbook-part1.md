# Corporate engineering handbook — imported rules (part 1)

Imported verbatim from the company-wide engineering handbook, with its own identifiers. Several
restate project rules in different words: the eval set treats each `HB-*` rule as equivalent to the
project rule it restates (see `docs/rule-equivalences.md`). One rule per `##` section.

---

## HB-SEC-01 — Credentials never live in code
API keys, passwords, tokens and private keys must come from the environment or a secret manager.
Any credential committed to a repository, even in a test or a default value, is a finding.

## HB-SEC-02 — Bind query parameters
Database queries take user-supplied values as bound parameters, never by formatting or concatenating
them into the SQL text. A query string built with an f-string, `%` or `+` from input is a finding.

## HB-ERR-01 — Catch precisely, never silently
Catch the specific exceptions you can handle; a bare `except:`, an `except Exception` that does not
re-raise, or an empty handler that hides the error is a finding.

## HB-NET-01 — Bound every network wait
Every outbound network call (HTTP, database, message broker) sets an explicit timeout. A call that
can wait forever on a remote service is a finding.

## HB-LOG-01 — Diagnostics go through the logger
Application code reports diagnostics through the logging framework with a level, never through
`print()` or writes to stdout/stderr. A `print()` used for debugging or reporting is a finding.

## HB-SHELL-01 — No shell for external commands
Run external programs with an argument list and no shell. Passing a command string built from
variable input to a shell (`shell=True`, `os.system`) is a finding.

## HB-TLS-01 — Keep certificate verification on
Never disable TLS certificate or hostname verification in application code (`verify=False`,
unverified SSL contexts). Trust a private CA by configuring it, not by switching checks off.

## HB-PERF-01 — One query, not one per row
Fetch related data in a single query (join, `IN (...)`, bulk fetch) instead of querying the
database once per item of a loop. A query issued inside a per-row loop is a finding.

## HB-ASYNC-01 — Never block inside a coroutine
Inside `async def` code, do not call blocking functions such as `time.sleep`, synchronous HTTP
clients or blocking file I/O; await the async equivalent or offload to a thread.

## HB-DEF-01 — Default arguments are immutable
A function's default argument values must be immutable (`None`, numbers, strings, tuples). A list,
dict or set used as a default is shared between calls and is a finding.
