# Further Python rules (tier 2)

Python conventions on packaging, command-line tools, class design, protocols, internationalisation
and less common standard-library modules. One rule per `##` section.

---

## PY-PACKAGING-046 — Package metadata lives in `pyproject.toml`
Declare the name, version, dependencies and build backend in the `[project]` and `[build-system]`
tables of `pyproject.toml`. Adding a new `setup.py` that contains executable logic, or moving
metadata back into `setup.cfg`, is a finding.

## PY-PYVERSION-047 — Declare the supported Python range
The `[project]` table states `requires-python` (for example `">=3.11"`). A `pyproject.toml` without
it, or a change that lowers it below the oldest interpreter the CI matrix actually tests, is a
finding.

## PY-ENTRYPOINT-048 — Command-line tools are declared entry points
Expose every command through `[project.scripts]`, pointing at a `module:function`. Adding a wrapper
shell script, a `bin/` file with a shebang line, or instructions to run a module by its file path
instead of an entry point is a finding.

## PY-LOCKFILE-049 — Lockfile changes travel with manifest changes
When a diff edits dependencies in `pyproject.toml`, the regenerated lockfile (`uv.lock`,
`poetry.lock`, `requirements.lock`) is part of the same merge request. A manifest change without
its lockfile, or a lockfile edited by hand, is a finding.

## PY-DEVDEPS-050 — Development tools stay out of runtime dependencies
Test runners, linters, type checkers and formatters (`pytest`, `ruff`, `mypy`, `black`) belong in a
dependency group or a `dev` extra. Listing them in `[project.dependencies]`, so that every
installation pulls them in, is a finding.

## PY-EXTRAS-051 — Optional features use extras
A dependency needed by only one optional feature (a database driver, a plotting library, a cloud
SDK) is declared under `[project.optional-dependencies]`, and the feature names the extra to install
when it is missing. Adding it to the core dependencies is a finding.

## PY-ARTIFACTS-052 — No virtual environments or build output in the repository
Directories and files such as `.venv/`, `venv/`, `__pycache__/`, `*.pyc`, `build/`, `dist/` and
`*.egg-info/` are listed in `.gitignore`. A diff that adds any of them to version control is a
finding.

## PY-SYSPATH-053 — No `sys.path` manipulation to find modules
Code must not modify `sys.path` or depend on a hand-set `PYTHONPATH` to import sibling modules.
Install the project (an editable install during development) and use package imports; a
`sys.path.insert` or `sys.path.append` call in source is a finding.

## PY-PKGVERSION-054 — One source of truth for the package version
The version is declared once, in `pyproject.toml` or derived from VCS tags, and read at run time
with `importlib.metadata.version()`. A hard-coded `__version__` string that duplicates the metadata
and can drift from it is a finding.

## PY-PKGINIT-055 — Keep package `__init__.py` files thin
A package's `__init__.py` only re-exports the public names of its submodules and defines a few
package-level constants. Classes or business logic written directly in `__init__.py` are a finding;
move them into a named submodule.

## PY-METADATA-056 — Use `importlib.metadata`, not `pkg_resources`
Discover installed distributions, versions and plugin entry points with `importlib.metadata`
(`version()`, `entry_points(group=...)`). A new import of the deprecated `pkg_resources` module,
which is slow to import and tied to setuptools, is a finding.

## PY-DYNIMPORT-057 — Load modules by name with `importlib.import_module`
Plugins and back-ends selected by name are loaded with `importlib.import_module()`, from an explicit
allow-list or an entry-point group. Calling `__import__()` directly, or assembling an `import`
statement as a string for `exec()`, is a finding.

## PY-ARGV-058 — Parse arguments with a parser, not by indexing `sys.argv`
Command-line programs read their options with `argparse` or the project's chosen CLI library, which
provide `--help`, usage errors and type conversion. Reading options by indexing `sys.argv[1]` or
scanning `sys.argv` by hand is a finding.

## PY-CLIHELP-059 — Every command-line option has help text
Each `add_argument()` call on a user-facing command passes a `help=` string saying what the option
does and, where relevant, its default and units. A new option without help, or whose help only
repeats the option's name, is a finding.

## PY-ARGBOOL-060 — Never use `type=bool` for command-line flags
In `argparse`, `type=bool` turns any non-empty string, including `"false"` and `"0"`, into `True`.
Boolean switches use `action="store_true"`, `"store_false"` or `argparse.BooleanOptionalAction`;
an argument declared with `type=bool` is a finding.

## PY-KWONLY-061 — Boolean flags are keyword-only parameters
A `bool` parameter that switches a function's behaviour is declared after a bare `*`, so callers
must write `dry_run=True` rather than a bare `True` whose meaning is invisible at the call site. A
new or changed signature with a positional boolean flag is a finding.

## PY-KWARGS-062 — `**kwargs` is forwarded, never silently swallowed
A function that accepts `*args` or `**kwargs` passes them on, unchanged, to one documented callee.
Accepting `**kwargs` and ignoring them, or picking out a few keys and dropping the rest without an
error, is a finding: misspelt argument names then pass unnoticed.

## PY-GLOBAL-063 — No `global` statements to rebind module state
Functions do not use the `global` statement to reassign module-level variables as a side channel
between calls. Pass the value in, return it, or keep it on an object; a new `global` statement in
application code is a finding.

## PY-PRIVIMPORT-064 — Don't import another package's private names
A name with a leading underscore is internal to the module or package that defines it. Importing
`_helper` or `_REGISTRY` from a different package, outside that package's own tests, is a finding;
ask for the name to be made public instead.

## PY-PRIVATTR-065 — Don't reach into other objects' private attributes
Another object's underscore-prefixed attributes (`client._session`, `other._conn`) are read and
written only inside that object's own class. Accessing or patching them from outside, including from
a sibling class, is a finding; add a public method instead.

## PY-MANGLE-066 — Double-underscore attributes only to avoid subclass clashes
Name mangling (`self.__token`) exists to prevent accidental clashes in subclasses, not to enforce
privacy. Using double-underscore names as a privacy mechanism, or reaching them through
`obj._ClassName__attr`, is a finding; a single underscore marks an attribute as internal.

## PY-DUNDER-067 — Don't invent dunder names
Names of the form `__name__` are reserved for the language and its standard library. Defining new
double-underscore methods or attributes of your own, such as `__validate__` or `__registry__`, is a
finding; choose an ordinary or single-underscore name.

## PY-INHERIT-068 — Shallow hierarchies, composition for reuse
New class hierarchies stay at most three levels deep below their root class. Subclassing a concrete
class only to reuse one of its helper methods, or adding a fourth level to a hierarchy, is a
finding; hold a collaborator as an attribute instead.

## PY-ENUMERATE-069 — Iterate directly, with `enumerate` when the index matters
Loop over a sequence's items directly, and use `enumerate()` when the position is also needed. A
loop written as `for i in range(len(xs))` that only reads `xs[i]`, or a counter incremented by hand
beside a `for` loop, is a finding.

## PY-METACLASS-070 — Prefer `__init_subclass__` to custom metaclasses
Registration, checking or customisation of subclasses uses `__init_subclass__` or a class decorator.
Introducing a new metaclass for these purposes is a finding: metaclasses conflict when classes from
two libraries are combined and are hard to review.

## PY-BATCHED-071 — Chunk iterables with `itertools.batched`
On Python 3.12 and later, split an iterable into fixed-size chunks with `itertools.batched(items,
n)`. Hand-written chunking with `range(0, len(xs), n)` slices, or a chunking helper copied into the
project, is a finding: it fails on iterators and repeats a solved problem.

## PY-LISTDIR-072 — Directory listings are sorted before use
`os.listdir()`, `os.scandir()`, `glob.glob()` and `Path.iterdir()` return entries in an arbitrary,
filesystem-dependent order. Processing them where the order affects the result (output, numbering,
which entry wins) without passing them through `sorted()` is a finding.

## PY-OPERATOR-073 — Operator overloads keep their conventional meaning
An overloaded operator behaves like the operator readers know: `+` combines values, `<` orders
them, and neither mutates its operands nor performs I/O. Overloading `<<`, `|` or `+` to send
messages, register handlers or append to hidden state is a finding.

## PY-ITERPROTO-074 — Containers return a fresh iterator
A collection class's `__iter__` returns a new iterator on every call (often by being a generator),
so the object can be looped over more than once. Returning `self` from a container's `__iter__`, or
an iterator whose `__next__` never raises `StopIteration`, is a finding.

## PY-GETATTR-075 — `__getattr__` raises `AttributeError` for unknown names
A custom `__getattr__`, on a class or at module level, raises `AttributeError` for every name it
does not handle. Returning `None` or raising `KeyError` instead breaks `hasattr()`, `getattr()` with
a default and mocking libraries, and is a finding.

## PY-STATICNS-076 — No classes used as namespaces of static methods
A class whose members are only `@staticmethod` functions and constants, and which is never
instantiated, is a finding: a module already provides that namespace. Write module-level functions,
and keep classes for things that hold state or are substituted polymorphically.

## PY-CLASSMETHOD-077 — Alternative constructors are classmethods
Factory methods such as `from_row` or `from_dict` are `@classmethod`s that build the instance with
`cls(...)`. A `@staticmethod` or module function that hard-codes the class name, so that subclasses
get base-class instances back, is a finding.

## PY-SHUTIL-078 — Copy and move files with `shutil`
Copy files and directory trees with `shutil.copy2()` and `shutil.copytree()`, and move them with
`shutil.move()`. Using `os.rename()` for a move that may cross filesystems, or a hand-written
`os.walk()` loop to copy a tree, is a finding.

## PY-CONTEXTLIB-079 — `@contextmanager` generators yield inside `try`/`finally`
A generator decorated with `contextlib.contextmanager` yields exactly once, inside `try`/`finally`,
so its exit code also runs when the body of the `with` block raises. Teardown code placed after a
bare `yield`, or a generator that can yield twice, is a finding.

## PY-WRAPS-080 — Decorators preserve the wrapped function's metadata
The inner wrapper of every decorator is itself decorated with `functools.wraps(func)`, so the result
keeps the original `__name__`, `__doc__`, `__module__` and signature. A wrapper without
`functools.wraps` is a finding: it breaks introspection, debuggers and generated documentation.

## PY-TEXTWRAP-081 — Indented multi-line literals use `textwrap.dedent`
A triple-quoted string written inside indented code and shown to users (help text, e-mail bodies,
generated reports) is passed through `textwrap.dedent()` or `inspect.cleandoc()`. A literal whose
source indentation leaks into the output is a finding; docstrings are exempt.

## PY-MATCH-082 — `match` statements handle the remaining cases
A `match` statement that dispatches over a closed set of values or shapes ends with a `case _:` arm
that raises or handles the unexpected subject explicitly. A `match` that silently does nothing when
no arm matches is a finding.

## PY-RECURSION-083 — Don't raise the recursion limit
Calling `sys.setrecursionlimit()` to make deep recursion work is a finding: it trades a clear
`RecursionError` for a possible interpreter crash on stack overflow. Rewrite recursion over
unbounded input as a loop with an explicit stack.

## PY-PYDANTIC-084 — Pydantic models use one API generation
Models written for Pydantic v2 configure themselves with `model_config = ConfigDict(...)`, check
fields with `@field_validator` and serialise with `model_dump()`. Mixing v1 idioms (`class Config`,
`@validator`, `.dict()`, `parse_obj()`) into new code is a finding.

## PY-I18N-085 — User-facing strings go through `gettext`
In a localised application, text shown to end users (interface labels, e-mails, notifications) is
wrapped in the project's `gettext` function, usually `_()`. Building such sentences from
untranslated literals is a finding; log messages and developer diagnostics are not translated.

## PY-GETTEXT-086 — Translatable strings use named placeholders and `ngettext`
The argument of `_()` is a plain literal with named placeholders, filled in after translation. An
f-string or concatenation inside `_()` cannot be extracted for translators and is a finding, and
count-dependent messages use `ngettext`, never an `if n == 1` branch.

## PY-LOCALE-087 — Library code never calls `locale.setlocale`
`locale.setlocale()` changes process-wide state that affects every thread and every other library.
Calling it outside the application's start-up code is a finding, as is parsing machine-readable data
with locale-dependent functions such as `locale.atof()`.

## PY-GC-088 — Leave the garbage collector alone
Application code does not call `gc.disable()`, `gc.set_threshold()` or `gc.collect()`. Such a call
is a finding unless it sits in a documented start-up hook of a long-running service; reference
cycles that waste memory are broken in the code rather than collected by hand.

## PY-REFLAGS-089 — Pass regular-expression flags by keyword
Flags such as `re.IGNORECASE` are passed as `flags=`. In `re.sub()` and `re.split()` the fourth
positional parameter is `count` or `maxsplit`, so `re.sub(p, r, s, re.I)` silently caps the number
of substitutions instead of ignoring case; a positional flag is a finding.

## PY-FULLMATCH-090 — Whole-string pattern checks use `re.fullmatch`
To check that an entire string has a given format, use `re.fullmatch()`. `re.match()` anchors only
at the start, and `$` also matches before a trailing newline, so a format check written with
`match()`, or with `search()` and `$`, is a finding.

## PY-STRUCT-091 — Binary formats state their byte order
Every `struct` format string, and every `int.to_bytes()` or `int.from_bytes()` call, used for file
or network data states its byte order explicitly (`"<"`, `">"`, `"!"`, or `byteorder=`). A
native-order format, whose sizes and padding depend on the platform, is a finding.

## PY-HEAP-092 — Heap entries carry a tie-breaker
Items pushed onto a `heapq` heap as priority tuples include an insertion counter,
`(priority, count, payload)`, so equal priorities never compare payloads. Pushing
`(priority, payload)` tuples whose payloads are not orderable, which raises `TypeError` on a tie, is
a finding.

## PY-TOML-093 — Read TOML with the standard `tomllib`
On Python 3.11 and later, TOML documents are parsed with the standard `tomllib` module. Adding the
third-party `toml` or `tomli` package just for reading is a finding, as is producing TOML by string
formatting instead of a writer library such as `tomli-w`.

## PY-ATEXIT-094 — Don't rely on `atexit` for essential work
`atexit` handlers do not run when the process is killed by a signal, crashes, or calls `os._exit()`.
Registering handlers from library code, or using one to persist data, drain a work queue or commit a
transaction, is a finding; do that work explicitly.

## PY-SIGNAL-095 — Signal handlers only set a flag
A handler installed with `signal.signal()` runs between arbitrary bytecodes of the main thread, so
it only records the event, by setting a flag or an `Event`, and returns. A handler that performs
I/O or runs application logic is a finding.
