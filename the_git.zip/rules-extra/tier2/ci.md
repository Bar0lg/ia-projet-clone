# CI pipeline rules

Conventions for GitLab CI and GitHub Actions pipeline definitions that build, test and deploy our
projects. One rule per `##` section.

---

## CI-001 — Pin third-party actions to a commit SHA
In GitHub Actions, every `uses:` of an action outside the organisation references a full 40-character
commit SHA, with the release tag in a comment. A reference to a branch, `@main`, or a movable tag
such as `@v4` is a finding.

## CI-002 — Pin job images
Every `image:` (GitLab) or `container:` (GitHub Actions) names an explicit version tag, ideally
with a digest. A job image with no tag or with `:latest` is a finding because the job's toolchain
can change between two runs of the same commit.

## CI-003 — Declare least-privilege token permissions
GitHub workflows declare a top-level `permissions:` block that defaults to `contents: read`, and
jobs request extra scopes individually. A workflow with no `permissions:` key, or with
`permissions: write-all`, is a finding.

## CI-004 — Cache keys follow the lockfile
Dependency caches are keyed on a hash of the lockfile (`hashFiles(...)` or GitLab `cache:key:files`)
plus the toolchain version. A cache with a constant key, which keeps serving stale dependencies
after the lockfile changes, is a finding.

## CI-005 — Never check out untrusted code in `pull_request_target`
Workflows triggered by `pull_request_target` or `workflow_run` run with repository secrets. Checking
out or building the pull request's head commit in such a workflow is a finding; use the plain
`pull_request` trigger for untrusted code.

## CI-006 — Pipes in job scripts fail the job
Multi-line script steps run with `set -o pipefail` (and `set -e` where the shell does not already
set it), so `command | tee report.txt` fails when `command` fails. A piped script step whose exit
status only reflects the last command is a finding.

## CI-007 — Allowed failures are justified and tracked
`allow_failure: true` (GitLab) or `continue-on-error: true` (GitHub Actions) on a test, lint or
security job carries a comment linking the issue that will remove it. An unexplained allowed failure
is a finding.

## CI-008 — Artifacts expire
Every uploaded artifact sets a lifetime with `expire_in` (GitLab) or `retention-days` (GitHub
Actions), short for intermediate build output and longer only for releases. A new artifact without
an expiry is a finding.

## CI-009 — Superseded pipelines are cancelled
Branch pipelines cancel older runs of the same ref: GitLab jobs are `interruptible: true` and
GitHub workflows declare a `concurrency:` group with `cancel-in-progress: true`. Deploy jobs are the
exception and must never be interruptible.

## CI-010 — GitLab jobs use `rules:`, not `only`/`except`
Job selection in `.gitlab-ci.yml` uses `rules:` with explicit `if:` and `changes:` clauses. New or
modified jobs that use the deprecated `only:` or `except:` keywords, or mix them with `rules:`, are a
finding.

## CI-011 — Express job dependencies with `needs:`
Jobs that depend only on specific earlier jobs declare them with `needs:`, so the pipeline runs as a
graph instead of waiting for whole stages. A job fetching every earlier artifact when it
needs one, or a long pipeline without `needs:`, is a finding.

## CI-012 — Production deploys go through a protected environment
Jobs that deploy to production reference a protected `environment:` with required reviewers or a
manual gate, and run only from the default branch or release tags. A production deploy that runs
automatically from any branch is a finding.

## CI-013 — Build once, promote the same artifact
An image or package is built once per commit and the same digest is promoted through staging and
production. A pipeline that rebuilds the artifact separately for each environment is a finding,
because what was tested is not what ships.

## CI-014 — Reuse configuration instead of copying it
Repeated job definitions use `extends:`, `include:`, YAML anchors, reusable workflows or composite
actions. Pasting a near-identical job block a second time, so that the copies can drift apart, is a
finding.

## CI-015 — Pin tool versions installed in jobs
Tools installed during a job (`npm install -g`, `go install`, `curl` of a release binary) name an
exact version. Installing `@latest`, or a script that fetches whatever release is newest at run
time, is a finding.

## CI-016 — Pin the runner time zone
Jobs set `TZ: "UTC"` in the pipeline's global `variables:` or `env:`, so tests, generated reports
and timestamped artifact names do not depend on the runner host. A pipeline that leaves the time
zone to the runner, or sets a local zone, is a finding.

## CI-017 — No privileged Docker-in-Docker for image builds
Images are built with a rootless builder (Kaniko, Buildah, BuildKit rootless) or a dedicated build
service. A new job using the `docker:dind` service with a privileged runner just to build an image
is a finding.

## CI-018 — Path filters never skip required checks
`paths:`, `paths-ignore:` or `rules:changes:` may skip optional jobs, but a check that branch
protection requires must still report a status. A path filter that leaves a required check pending
forever, or skips tests for source changes, is a finding.

## CI-019 — Publish test reports
Test jobs upload machine-readable results with `artifacts:reports:junit` or a test-report action, so
failures appear in the merge request. A new test job whose only output is console text is a
finding.

## CI-020 — Lint pipeline definitions
Changes to pipeline files are checked by `actionlint` or the GitLab CI lint endpoint in the
pipeline itself. A pipeline change that disables this check, or a repository with workflows but no
pipeline lint job, is a finding.

## CI-021 — Set the clone depth deliberately
Jobs that need history (changelog generation, version from tags, diff-based checks) set
`fetch-depth: 0` or `GIT_DEPTH` explicitly; other jobs keep the shallow default. A job that derives
versions from tags on a shallow clone is a finding.

## CI-022 — Fork pipelines never run on self-hosted runners
Jobs triggered from forks or external merge requests run only on ephemeral hosted runners. A
workflow that sends fork pull requests to a persistent self-hosted runner, where they can tamper with
later jobs, is a finding.

## CI-023 — Manual inputs are typed and constrained
`workflow_dispatch` inputs and manual pipeline variables declare a type, a description and, for
closed sets, `options:`. A free-text input used to choose an environment or a release channel is a
finding.

## CI-024 — Scheduled jobs are selected explicitly
Jobs meant for scheduled pipelines are enabled with a rule on `$CI_PIPELINE_SOURCE == "schedule"`
or a separate `schedule:` workflow, and documented with their purpose. A nightly job that also runs
on every push, or a schedule without a description, is a finding.

## CI-025 — Pin included pipeline templates
GitLab `include: project:` entries and GitHub reusable workflows from other repositories reference
a tag or commit SHA through `ref:` or `@`. Including another project's template from its default
branch, so that a change there alters this pipeline silently, is a finding.
