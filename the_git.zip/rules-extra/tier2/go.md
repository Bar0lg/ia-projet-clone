# Go rules

Conventions for the Go services and command-line tools in our repositories. One rule per `##`
section.

---

## GO-001 — Code is `gofmt`-formatted with sorted imports
Every Go file is formatted by `gofmt` and has its imports grouped and ordered by `goimports`
(standard library first, then third-party). A diff containing unformatted code or hand-ordered
import blocks is a finding.

## GO-002 — Short, lower-case package names
Package names are short, lower-case single words without underscores or mixed caps, and do not
repeat in exported identifiers (`http.Server`, not `http.HTTPServer`). Packages named `util`,
`common` or `misc` are a finding.

## GO-003 — Error strings are lower-case and unpunctuated
Error messages created with `errors.New` or `fmt.Errorf` start with a lower-case letter and end
without punctuation, because they are usually wrapped into longer messages. A capitalised error
string or one ending in a full stop is a finding.

## GO-004 — Compare errors with `errors.Is` and `errors.As`
Test for a sentinel or typed error with `errors.Is` or `errors.As`, which see through wrapping.
Comparing with `==`, a type assertion on the error, or matching on `err.Error()` text is a finding.

## GO-005 — Libraries do not panic
Exported functions of library packages report failure by returning an `error`. Calling `panic` or
`log.Fatal` on a recoverable condition, such as bad input or an unavailable dependency, is a
finding; panics are reserved for programmer errors.

## GO-006 — Accept interfaces, return concrete types
Functions accept the narrowest interface they need and return concrete types, so callers can use the
full value. A constructor returning an interface that has only one implementation is a finding.

## GO-007 — Small interfaces defined by their consumer
Interfaces live in the package that uses them and contain only the methods that consumer calls. A
large interface declared next to its only implementation "for mocking" is a finding.

## GO-008 — `context.Context` is the first parameter, never a field
Functions that do cancellable work take `ctx context.Context` as their first parameter. Storing a
context in a struct field, passing `nil` instead of `context.TODO()`, or taking it as a later
parameter is a finding.

## GO-009 — No optional parameters in `context.Value`
`context.WithValue` carries only request-scoped data that crosses API boundaries, such as a trace
identifier, under an unexported key type. Passing function options, loggers or dependencies through
the context, or using a string key, is a finding.

## GO-010 — Short, consistent receiver names
Method receivers use a short name of one or two letters derived from the type (`s *Server`) and the
same name in every method of that type. Receivers named `self` or `this`, or named differently
across methods, are a finding.

## GO-011 — One receiver kind per type
All methods of a type use pointer receivers, or all use value receivers. A type that mixes them,
except for documented interface-satisfaction reasons, is a finding; types holding a mutex or large
arrays always use pointer receivers.

## GO-012 — Make the zero value useful
Design structs so that their zero value is ready to use where possible, and provide a `New...`
constructor only when invariants require it. A constructor that merely sets fields to their zero
values is a finding.

## GO-013 — Keep `init` functions trivial
`init()` functions only register values or compute package-level constants. An `init` that opens
files, reads the environment, contacts the network or can fail is a finding; do that work in an
explicit set-up function called from `main`.

## GO-014 — Test helpers call `t.Helper()`
Functions that take a `*testing.T` or `*testing.B` and report failures call `t.Helper()` first, so
failures point at the calling test line. A new test helper without `t.Helper()` is a finding.

## GO-015 — Preallocate slices of known length
When the final length or a good upper bound is known, create the slice with
`make([]T, 0, n)` before appending in a loop. Growing a slice from `nil` inside a loop over a
collection of known size is a finding.

## GO-016 — Build strings with `strings.Builder`
Strings assembled inside loops use a `strings.Builder` (or `bytes.Buffer`), not repeated `+=`
concatenation, which copies the whole string on every iteration. A `+=` on a string inside a loop
is a finding.

## GO-017 — Don't retain sub-slices that alias a large array
A sub-slice shares its backing array, so keeping `data[:4]` keeps all of `data` alive and lets
`append` overwrite the caller's elements. Returning or storing a sub-slice of a buffer you don't own,
without `slices.Clone` or a copy, is a finding.

## GO-018 — Never rely on map iteration order
Map iteration order is randomised. Code whose output, encoding or test expectations depend on the
order of a `range` over a map, without first sorting the keys with `slices.Sorted(maps.Keys(m))`,
is a finding.

## GO-019 — Initialise maps before writing
Writing to a nil map panics. A struct field or variable of map type that is written before being
created with `make` or a literal, including in a zero-value struct, is a finding.

## GO-020 — Use the comma-ok form for type assertions
A type assertion on an interface value that may hold another type uses `v, ok := x.(T)` and checks
`ok`. A single-value assertion `x.(T)` outside a type switch, which panics on mismatch, is a
finding.

## GO-021 — Durations are `time.Duration`
Parameters, fields and configuration values that represent a length of time have type
`time.Duration`. An `int` or `float64` named `timeoutSecs` or `delayMs`, multiplied into a duration
at the point of use, is a finding.

## GO-022 — Store and exchange times in UTC
`time.Time` values that are persisted, compared across services or serialised are converted with
`.UTC()` and formatted as RFC 3339. Storing `time.Now()` in local time, or formatting a timestamp
without its offset, is a finding.

## GO-023 — Measure elapsed time with `time.Since`
Elapsed time is computed with `time.Since(start)` or `t2.Sub(t1)` on values taken from `time.Now()`,
which use the monotonic clock. Subtracting `Unix()` or `UnixNano()` values, or comparing wall-clock
times after `.Round(0)` or `.UTC()`, is a finding.

## GO-024 — Never use `float64` for money
Monetary amounts are integers in minor units (`int64` cents) or a decimal type such as
`shopspring/decimal`, never `float64` or `float32`. Prices, totals or balances computed in floating
point, or parsed with `strconv.ParseFloat`, are a finding.

## GO-025 — Don't delete from a slice while ranging over it
Removing elements from a slice inside a `range` over that same slice skips or repeats elements. Use
`slices.DeleteFunc`, or build a filtered slice; deleting by index from the slice being ranged over
is a finding.

## GO-026 — Treat text as runes, not bytes
`len(s)` and `s[i]` count and index bytes, not characters. Truncating or reversing user-visible
text by byte index, which can split a UTF-8 sequence, is a finding; range over runes or use
`utf8.RuneCountInString`.

## GO-027 — Exported identifiers have doc comments
Every exported type, function, method and constant has a doc comment that starts with its name
(`// Client sends ...`). A new exported identifier without a comment, or with one that does not
begin with the identifier, is a finding.

## GO-028 — `go.mod` and `go.sum` stay tidy
Changes to imports come with the matching `go.mod` and `go.sum` updates produced by `go mod tidy`.
A diff where `go mod tidy` would change either file, or where `go.sum` is edited by hand, is a
finding.

## GO-029 — Non-public packages live under `internal/`
Packages that are implementation details of a module are placed under an `internal/` directory so
other modules cannot import them. A new helper package added at the module root and imported only
by this module is a finding.

## GO-030 — No naked returns in long functions
Named result parameters may document a short function, but a bare `return` in a function longer than
a few lines hides what is returned. A naked return in a function of more than about ten lines is a
finding.

## GO-031 — Consistent struct tags for serialised types
Structs that are encoded to JSON or other formats tag every exported field explicitly, in the
project's case convention, and use `omitempty` deliberately. Untagged exported fields in an API
type, or tags whose spelling differs between fields, are a finding.

## GO-032 — Generics only when two types need them
Introduce type parameters when at least two concrete types already share the code. A generic
function or type with a single instantiation, or a type parameter constrained to `any` that is only
passed through, is a finding.

## GO-033 — Don't embed types in exported structs by accident
Embedding a type in an exported struct promotes all its methods into the struct's public API.
Embedding a mutex, a client or a third-party type in an exported struct, rather than holding it in an
unexported named field, is a finding.

## GO-034 — Enumerated constants have their own type
Groups of related constants built with `iota` have a dedicated named type and a `String` method,
and start the useful values at one when zero should mean "unset". A bare untyped `iota` block used
as an enumeration is a finding.

## GO-035 — No `else` after a returning branch
When an `if` block ends with `return`, `break` or `continue`, the following code is not wrapped in
`else`; keep the main path unindented. An `else` branch following a block that always returns is a
finding.
