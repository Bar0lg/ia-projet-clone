"""Gemini client wrapper with token and cost logging."""
from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field
from functools import lru_cache

from google import genai
from google.genai import types
from pydantic import ValidationError

from .config import settings

log = logging.getLogger("mr_reviewer.llm")

# Approximate USD per 1K tokens. Update these rates for the configured Gemini model.
PRICE_PER_1K = {
    "input": 0.00015,
    "output": 0.0006,
}


@dataclass
class Usage:
    input_tokens: int = 0
    output_tokens: int = 0
    calls: int = 0

    @property
    def cost_usd(self) -> float:
        return (
            self.input_tokens / 1000 * PRICE_PER_1K["input"]
            + self.output_tokens / 1000 * PRICE_PER_1K["output"]
        )

    def add(self, input_tokens: int, output_tokens: int) -> None:
        self.input_tokens += input_tokens
        self.output_tokens += output_tokens
        self.calls += 1


@lru_cache(maxsize=4)
def _get_client(api_key: str | None) -> genai.Client:
    return genai.Client(api_key=api_key) if api_key else genai.Client()


def _client() -> genai.Client:
    api_key = settings.llm_api_key
    if not api_key or api_key == "changeme":
        api_key = None  # Let the SDK read GEMINI_API_KEY from the environment.
    return _get_client(api_key)


def _as_text(value: object) -> str:
    if isinstance(value, str):
        return value
    if value is None:
        return ""
    return json.dumps(value, ensure_ascii=False)


def _function_arguments(value: object) -> dict:
    if isinstance(value, dict):
        return value
    if isinstance(value, str):
        parsed = json.loads(value)
        if isinstance(parsed, dict):
            return parsed
    raise ValueError("Function-call arguments must be a JSON object.")


def _gemini_contents(messages: list[dict]) -> tuple[list[types.Content], str | None]:
    contents: list[types.Content] = []
    system_messages: list[str] = []
    tool_names: dict[str, str] = {}

    for message in messages:
        if isinstance(message, dict):
            for call in message.get("tool_calls", []):
                if isinstance(call, dict) and call.get("id"):
                    function = call.get("function", call)
                    if function.get("name"):
                        tool_names[call["id"]] = function["name"]

    for message in messages:
        if isinstance(message, str):
            system_messages.append(message)
            continue
        if not isinstance(message, dict):
            raise TypeError("Each message must be a string or a role/content dictionary.")

        role = message.get("role")
        if role == "system":
            system_messages.append(_as_text(message.get("content")))
            continue

        if role == "tool":
            name = message.get("name") or tool_names.get(message.get("tool_call_id"))
            if not name:
                raise ValueError("A tool response must include the tool name.")
            response_text = _as_text(message.get("content"))
            try:
                response = json.loads(response_text)
            except json.JSONDecodeError:
                response = {"result": response_text}
            if not isinstance(response, dict):
                response = {"result": response}

            contents.append(
                types.Content(
                    role="user",
                    parts=[
                        types.Part(
                            function_response=types.FunctionResponse(
                                name=name,
                                response=response,
                                id=message.get("tool_call_id"),
                            )
                        )
                    ],
                )
            )
            continue

        parts: list[types.Part] = []
        text = _as_text(message.get("content"))
        if text:
            parts.append(types.Part.from_text(text=text))

        for call in message.get("tool_calls", []):
            function = call.get("function", call)
            parts.append(
                types.Part(
                    function_call=types.FunctionCall(
                        name=function["name"],
                        args=_function_arguments(function.get("arguments", {})),
                        id=call.get("id"),
                    )
                )
            )

        if parts:
            contents.append(
                types.Content(
                    role="model" if role == "assistant" else "user",
                    parts=parts,
                )
            )

    system_instruction = "\n\n".join(item for item in system_messages if item) or None
    return contents, system_instruction


def _gemini_tools(tools: list[dict] | None) -> list[types.Tool] | None:
    if not tools:
        return None

    declarations = []
    for tool in tools:
        parameters = tool.get("parameters", tool.get("input_schema"))
        if not parameters:
            raise ValueError(f"Tool {tool.get('name', '<unnamed>')!r} has no parameter schema.")
        declarations.append(
            types.FunctionDeclaration(
                name=tool["name"],
                description=tool.get("description", ""),
                parameters=parameters,
            )
        )
    return [types.Tool(function_declarations=declarations)]


@dataclass
class LLMClient:
    """Thin wrapper around the Gemini generate-content API."""

    model: str = field(default_factory=lambda: settings.llm_model)
    usage: Usage = field(default_factory=Usage)

    def _generate(
        self,
        messages: list[dict],
        tools: list[dict] | None = None,
        max_tokens: int | None = None,
        temperature: float | None = None,
        response_schema: type | None = None,
    ) -> dict:
        if self.usage.cost_usd >= settings.spend_cap_usd:
            raise RuntimeError(
                f"LLM spend cap of ${settings.spend_cap_usd:.2f} has already been reached."
            )

        contents, system_instruction = _gemini_contents(messages)
        config: dict = {
            "system_instruction": system_instruction,
            "max_output_tokens": (
                max_tokens if max_tokens is not None else settings.llm_max_tokens
            ),
            "temperature": (
                settings.llm_temperature if temperature is None else temperature
            ),
        }
        configured_tools = _gemini_tools(tools)
        if configured_tools:
            config["tools"] = configured_tools
        if response_schema is not None:
            config["response_mime_type"] = "application/json"
            config["response_schema"] = response_schema

        response = _client().models.generate_content(
            model=self.model,
            contents=contents,
            config=types.GenerateContentConfig(**config),
        )

        metadata = response.usage_metadata
        input_tokens = (metadata.prompt_token_count or 0) if metadata else 0
        output_tokens = (
            (metadata.candidates_token_count or 0) + (metadata.thoughts_token_count or 0)
            if metadata
            else 0
        )
        self.usage.add(input_tokens, output_tokens)
        log.info(
            "llm call: %s in / %s out, run cost=$%.4f",
            input_tokens,
            output_tokens,
            self.usage.cost_usd,
        )
        if self.usage.cost_usd > settings.spend_cap_usd:
            raise RuntimeError(
                f"LLM spend cap of ${settings.spend_cap_usd:.2f} was exceeded "
                f"(estimated cost: ${self.usage.cost_usd:.4f})."
            )

        tool_calls = []
        text_parts = []
        for candidate in response.candidates or []:
            if not candidate.content:
                continue
            for part in candidate.content.parts or []:
                if part.text:
                    text_parts.append(part.text)
                if part.function_call:
                    call = part.function_call
                    tool_calls.append(
                        {
                            "id": call.id,
                            "name": call.name,
                            "arguments": dict(call.args or {}),
                        }
                    )

        return {
            "text": "".join(text_parts) or None,
            "tool_calls": tool_calls,
            "usage": {
                "input_tokens": input_tokens,
                "output_tokens": output_tokens,
            },
        }

    def complete(
        self,
        messages: list[dict],
        tools: list[dict] | None = None,
        max_tokens: int | None = None,
        temperature: float | None = None,
    ) -> dict:
        """Return text, normalized function calls, and token usage."""
        return self._generate(messages, tools, max_tokens, temperature)

    def complete_structured(self, messages: list[dict], schema: type) -> object:
        """Generate and validate structured JSON, retrying once if validation fails."""
        request_messages = list(messages)
        last_error: ValidationError | json.JSONDecodeError | None = None

        for attempt in range(2):
            response = self._generate(request_messages, response_schema=schema)
            text = response["text"] or ""
            if text.startswith("```"):
                lines = text.splitlines()
                if lines and lines[0].startswith("```"):
                    lines = lines[1:]
                if lines and lines[-1].strip() == "```":
                    lines = lines[:-1]
                text = "\n".join(lines).strip()

            try:
                data = json.loads(text)
                if isinstance(data, dict):
                    fields = set(schema.model_fields)
                    if not fields.intersection(data):
                        for value in data.values():
                            if isinstance(value, dict) and fields.intersection(value):
                                data = value
                                break

                    for old, new in (
                        ("file_path", "file"),
                        ("line_number", "line"),
                        ("description", "message"),
                    ):
                        if new in fields and old in data and new not in data:
                            data[new] = data.pop(old)

                return schema.model_validate_json(json.dumps(data, ensure_ascii=False))
            except (ValidationError, json.JSONDecodeError) as exc:
                last_error = exc
                if attempt == 0:
                    request_messages.append(
                        {
                            "role": "user",
                            "content": (
                                "The previous JSON did not validate against the required schema. "
                                f"Validation error: {exc}. Return corrected JSON only."
                            ),
                        }
                    )

        raise ValueError(
            f"Gemini failed to return valid {schema.__name__} JSON after two attempts: "
            f"{last_error}"
        ) from last_error


@lru_cache(maxsize=1)
def _local_embedding_model():
    try:
        from sentence_transformers import SentenceTransformer
    except ImportError as exc:
        raise RuntimeError(
            "Set llm_embed_model or install the optional sentence-transformers package "
            "to generate local embeddings."
        ) from exc
    return SentenceTransformer("all-MiniLM-L6-v2")


def embed(texts: list[str]) -> list[list[float]]:
    """Return one embedding vector per input text."""
    if not texts:
        return []

    if not settings.llm_embed_model:
        return [
            [float(value) for value in vector]
            for vector in _local_embedding_model().encode(texts)
        ]

    model_name = settings.llm_embed_model
    client = _client()

    # This model aggregates multiple inputs into one vector, so request each separately.
    if model_name.endswith("embedding-2"):
        results = [
            client.models.embed_content(model=model_name, contents=text)
            for text in texts
        ]
        if any(not result.embeddings for result in results):
            raise RuntimeError(f"Gemini returned no embedding for model {model_name!r}.")
        return [
            [float(value) for value in result.embeddings[0].values]
            for result in results
        ]

    result = client.models.embed_content(model=model_name, contents=texts)
    if not result.embeddings or len(result.embeddings) != len(texts):
        raise RuntimeError(
            f"Gemini returned {len(result.embeddings or [])} embeddings for {len(texts)} texts."
        )
    return [
        [float(value) for value in embedding.values]
        for embedding in result.embeddings
    ]