# MR Reviewer — starter repository

Starter code for the week-long project: an **automated GitLab Merge Request Reviewer**. You build
it up over 4.5 days, in pairs, following the checkpoints. The course material (the book, the week
plan, the rubric) lives in the **course site** repository.

This repo gives you the plumbing so you can spend the week on AI engineering, not setup:

- a Python project skeleton (`src/mr_reviewer/`) with clearly marked `TODO(checkpoint-N)` stubs,
- an LLM wrapper that already logs **tokens and cost**,
- Pydantic schemas for a structured `Review`,
- a `docker-compose.yml` for **Postgres + pgvector** and **Langfuse**,
- a sample **rule base** (`rules/`) and a **labelled eval set** (`evals/cases/`) including a
  prompt-injection case,
- a `.gitlab-ci.yml` that runs the eval suite and can gate merges,
- a `docs/CHECKPOINTS.md` that maps each TODO to the day's deliverable.

> **You are meant to fill in the stubs.** Search the codebase for `TODO(checkpoint-` to find the
> work for each day. Nothing here is a complete solution.

## Prerequisites

- Python 3.11+ and [`uv`](https://docs.astral.sh/uv/) (or `pip`/`venv`).
- Docker + Docker Compose (for Postgres/pgvector and Langfuse).
- An LLM API key (see *Choosing an LLM provider* below), and a **sandbox** GitLab project +
  access token to review (never a real repo).

## Choosing an LLM provider

The project is provider-agnostic (`LLM_PROVIDER` in `.env`). You need a **chat** model and an
**embeddings** source (embeddings are used by RAG, Checkpoint 2). Use whichever key you're given:

- **Mistral** — *recommended default*: a real free tier (no credit card, EU-hosted) and a native
  embeddings model (`mistral-embed`). Register at `console.mistral.ai`.
- **Anthropic Claude** — strong answer quality; apply for student/educator credits early as there is
  no ongoing free tier. Use e.g. `claude-haiku-5-5` and **send no `temperature`** (current Claude
  models reject non-default values). **No native embeddings**, so leave `LLM_EMBED_MODEL` blank and
  use the local fallback (below).
- **OpenAI** — e.g. `gpt-6-luna` + `text-embedding-3-small` (`gpt-4o-mini` shuts down in January
  2027).

`.env.example` has a ready-to-use block for each — uncomment the one you need. Pin a dated model
version for reproducibility (Book Ch. 9).

**Embeddings fallback.** If your chat provider has no embeddings endpoint (Claude), leave
`LLM_EMBED_MODEL` empty and install the local model — `pip install sentence-transformers` — and the
`embed()` wrapper uses it locally. The whole week's usage per pair is small (a few million tokens),
so free tiers and cheap models are plenty; **access to a key, not cost, is the real constraint.**

## Setup

```bash
# 1. Install dependencies (the dev extra brings pytest and ruff)
uv sync --extra dev   # or: python -m venv .venv && . .venv/bin/activate && pip install -e ".[dev]"

# 2. Bring up local services (Postgres+pgvector, Langfuse)
docker compose up -d

# 3. Configure secrets
cp .env.example .env
# edit .env: LLM_API_KEY, GITLAB_URL, GITLAB_TOKEN, GITLAB_PROJECT_ID, LANGFUSE_* ...

# 4. Smoke test (Checkpoint 1 target)
uv run mr-reviewer review --diff examples/sample.diff
```

## Your agent's harness (Day 0)

You will use a coding agent (Claude Code, Codex, Cursor…) all week. Fence it in *before* it
touches the repository; it is the Day-0 item of `docs/CHECKPOINTS.md`:

- **`AGENTS.md`** — context and hard rules for any agent (`CLAUDE.md` points Claude Code to it).
  Fill in the blanks.
- **`hooks/protect_evals.py`** — the tool-independent control that blocks writes under `evals/`
  and `tests/` and any access to `.env`; `tests/test_protect_evals.py` proves it in both
  directions.
- **`.claude/settings.json`** — an *example* wiring for Claude Code (deny rules + the hook).
  Other tools: `docs/HARNESS.md`.

Why: a rule in prose is a request the model may ignore; a hook is a control (Book Ch. 12 §12.8).
The MR Reviewer you build is a harness too, built with the same discipline.

## Recommended order of work

Work in the same order as the checkpoints. Do not start with MCP, Langfuse, or the agent loop.

1. **Checkpoint 1: local diff review**

Main files: `src/mr_reviewer/llm.py`, `src/mr_reviewer/cli.py`, `evals/test_evals.py`

Goal: `mr-reviewer review --diff examples/sample.diff` returns a structured review, and the eval
harness (`_review_case` + `compute_metrics`) reports precision / recall / FP-rate

First checks:

```bash
uv run mr-reviewer review --diff examples/sample.diff
uv run pytest tests/
uv run pytest evals/ -v -s     # prints recall / precision / fp_rate
```

1. **Checkpoint 2: RAG over the rule base**

Main files: `src/mr_reviewer/llm.py`, `src/mr_reviewer/rag/index.py`, `src/mr_reviewer/rag/retrieve.py`

Goal: findings cite retrieved project rules with real `rule_id` values

First checks:

```bash
docker compose up -d postgres
uv run python -m mr_reviewer.rag.index
uv run mr-reviewer review --diff examples/sample.diff
uv run pytest evals/ -v
```

1. **Checkpoint 3: agent + MCP**

Main files: `src/mr_reviewer/agent/`, `src/mr_reviewer/mcp_server/`,
`src/mr_reviewer/mcp_client.py`, `src/mr_reviewer/cli.py`

Goal: review a real sandbox MR, then optionally post comments

1. **Checkpoint 4: evals, observability, security**

Main files: CI thresholds (the eval harness is already written on Day 1), Langfuse wiring,
`SECURITY.md`

Goal: stable metrics, traces, and a pipeline you can defend

## What is normal to skip at first

Some things are supposed to be incomplete early in the week.

- `uv run pytest evals/ -v` may skip until your review pipeline is wired end to end.
- RAG-dependent commands are expected to fail until Postgres is running and the rule index has been built.
- Langfuse is not required for Checkpoints 1 and 2.
- The `--mr` path is expected to stay stubbed until Checkpoint 3.

If a command skips, distinguish between:

- a **planned skip** because the checkpoint is not implemented yet
- a **real setup problem** such as missing Docker services, a missing API key, or running outside `uv run`

## Common failure modes

- **`422` from Mistral embeddings**: check that your embedding request shape matches the current Mistral API, and that `LLM_EMBED_MODEL` is set.
- **`422` from the chat API on the agent path**: your tool schemas are in the wrong shape for the provider. OpenAI/Mistral want `{"type":"function","function":{...,"parameters":...}}`; Anthropic wants `name`/`description`/`input_schema`. Convert where you build the request, not in the tool registry.
- **`429 Too Many Requests`**: your evals may be calling the model too often. Cache shared work where possible and avoid rerunning the whole pipeline unnecessarily.
- **`review --diff` works but `pytest` fails differently**: make sure you run tests with `uv run pytest ...`, not a different global Python.
- **Postgres is up but retrieval still fails**: build the index explicitly with `uv run python -m mr_reviewer.rag.index`.
- **Structured output is close but not valid**: normalize common field aliases (`file_path`, `line_number`, `description`) before giving up on the model.
- **False positives on clean/trap cases**: do not immediately add heuristics everywhere. First inspect the prompt, the retrieved rules, and whether the model is citing the wrong rule family.
- **A larger model seems tempting**: test it as a controlled comparison. Do not change model, prompt, retrieval, and schema handling at the same time or you will not know what helped.

## Checkpoint 3 — known issues & gotchas

These are the traps a pair will most likely hit on the agent + MCP path. They are hints, not
fixes — the point is to make you read your code and the provider's API.

- **`422 Unprocessable Entity` from the chat API on `review --mr` (not embeddings).** The schema
  you *advertise* to the model is not necessarily the shape the provider's chat API wants in the
  request body. OpenAI/Mistral expect `{"type":"function","function":{...,"parameters":...}}`;
  Anthropic expects `name`/`description`/`input_schema`. If the error mentions `extra_forbidden` /
  `WebSearchTool`, your tool objects are in the wrong shape — convert them where you build the
  request, not in the tool registry.
- **`TypeError: 'NoneType' object is not iterable` in the agent loop.** Providers return
  `tool_calls: null` (not an empty list) when the model makes no tool call. A
  `response.get("tool_calls", [])` does NOT protect you when the key exists with value `null`.
  Treat "no tool calls" as your explicit termination signal and coerce `null → []`.
- **Agent finalizes but `ValidationError: summary Field required`.** The model sometimes wraps the
  result in an envelope, e.g. `{"review": {...}, "approval": false}`, or uses field aliases. Unwrap
  / normalize before validating against the `Review` schema.
- **Agent runs, exits 0, but `Findings: none` and the verdict is wrong.** The agent's final prompt
  is yours to write. If it doesn't explicitly ask for a *findings array* with
  severity/file/line/message, the model may only write a prose summary. Compare with how the
  `--diff` path prompts the model, and make sure the agent actually grounds its review.
- **`search_rules` times out / agent `rule_id`s look made up.** RAG retrieval needs Postgres + a
  built index (Checkpoint 2). On the `--mr` path the agent calls `search_rules` itself; if pgvector
  is down or unindexed the call times out and the model *recalls* plausible rule ids from memory
  instead of retrieving real ones. Bring up `postgres` and run the indexer first.
- **The MCP *client* is provided** (`mcp_client.py`: stdio, SDK 2.x, errors as data), because
  `mcp_server/` is only half the boundary and the plumbing teaches nothing. Your `tools.dispatch`
  calls `MCPClient().call_tool(name, arguments)`; the CLI calls it after the loop to post. Read
  it: it is the Book's Ch. 7 client in 80 lines.
- **Windows: the server is spawned as a subprocess from inside the agent.** The client starts the
  MCP server over stdio, and the agent calls it from a worker thread (timeout handling). Smoke-test
  the round-trip against *your* server on its own (`uv run python -m mr_reviewer.mcp_client`
  lists its tools; `tests/test_mcp_client.py` is the model) *before* wiring it into the loop, so
  transport bugs don't hide behind loop bugs.
- **The trajectory record is required.** `AgentResult` carries `tools_used`, `redundant_calls`,
  tokens, cost, `terminated_by`; print it on stderr after a `--mr` run (Book Ch. 6 §6.6).
- **MCP SDK 2.x, not 1.x.** The starter pins `mcp>=2.3,<3` (spec revision 2026-07-28): the server
  class is `MCPServer` (`from mcp.server.mcpserver import MCPServer`), the client is
  `mcp.Client`, and there is no `initialize` handshake. Snippets importing `mcp.server.fastmcp` were
  written for 1.x and fail with `ModuleNotFoundError`. To send the model a readable tool error,
  return it as data or raise `ToolError` (Book Ch. 7 §7.6).
- **Inline comments: `400`/`position is invalid`, or the comment lands as a plain note.** An inline
  comment is a *discussion* with a `position` object: `position_type: "text"`, the MR's
  `diff_refs` (`base_sha`, `start_sha`, `head_sha` — read them from the MR, don't guess), `new_path`
  and `new_line`. The line must be one that appears **in the diff** (an added or context line of the
  new version); a line outside every hunk is rejected. Test with one hard-coded comment before
  letting the agent choose lines. If it still resists, post one **summary note** with all findings —
  an accepted Checkpoint-3 fallback, to be mentioned in your design note.
- **Latency: one server process per tool call.** If your client opens a fresh stdio session per
  call, a multi-step review spawns several Python processes. Correct but slow — reusing a persistent
  session across one review is a reasonable stretch goal.

## Checkpoint 4 — known issues & gotchas

- **Grounding still matters, but equivalent ids are accepted (slot-match).** Scoring uses
  `acceptable_rule_ids` slots (see CHECKPOINTS + `docs/rule-equivalences.md`): a bare-except cited as
  `REL-001`, `REL-002` *or* `PY-ERRORS-002` all count — they are in the same slot. What still hurts is
  citing an id from the **wrong** family (e.g. `SEC-001` for a bare-except) or an **invented** id:
  that is a false positive. If precision looks bad, inspect the raised ids per case and check they
  belong to the case's slots before touching the prompt.
- **The eval gate can go green without measuring anything.** On a free tier the full suite may hit
  `429 Too Many Requests`. The default harness *fails* on a provider error, but if you wrap
  `_review_case` in a broad `try/except` that `pytest.skip`s, the whole gate skips and CI passes.
  Space out calls / cache shared work, and decide whether repeated provider errors should FAIL rather
  than skip — a merge gate that silently skips is worse than no gate.
- **`fp_rate` only sees rule-id false positives, not verdict ones.** A trap case can get a BLOCK
  verdict while raising no `rule_id`; the rule-id-based `fp_rate` stays 0 and misses it. If you care
  about verdict-level false positives on `clean`/`trap` cases, measure the verdict too.
- **RAG-mode evals need Postgres + a built index.** The default `EVAL_REVIEW_MODE=baseline` stuffs
  all rules in the prompt (no DB) so CI is reproducible; switch to `rag` only once pgvector is up and
  indexed, or retrieval times out and rule ids get invented.
- **Trace the LLM calls, not just "the agent".** Evals run on the `--diff` path, not the `--mr`
  agent path. If you wire Langfuse only around the agent, you'll see nothing during evals — wrap the
  `LLMClient` calls so both paths are traced.

## Checkpoint done checklists

Use these as operational checks before moving on.

### Checkpoint 1

- `uv run mr-reviewer review --diff examples/sample.diff` prints a structured review
- `uv run mr-reviewer review --diff examples/sample.diff --format json` prints ONE valid `Review`
  JSON object on stdout (logs go to stderr) — the final grader's contract
- `uv run pytest tests/` is green
- the review output includes a summary, findings, and run cost
- `Review` parsing is robust enough that malformed model JSON is the exception, not the norm

### Checkpoint 2

- `docker compose up -d postgres` succeeds
- `uv run python -m mr_reviewer.rag.index` indexes the rule corpus
- review findings start carrying real `rule_id` values
- `uv run pytest evals/ -v` runs without placeholder skips caused by an unwired pipeline
- you can explain why the retrieved rules are better than stuffing the whole corpus into one prompt

### Checkpoint 3

- the `--mr` path reviews a real sandbox MR
- posting comments is optional and explicit (`--post`), not automatic
- the bot has only the minimum GitLab permissions needed

### Checkpoint 4

- eval thresholds are meaningful and reproducible
- Langfuse traces show useful prompt, retrieval, and cost information
- you can explain your remaining false positives and false negatives

## Example outputs

These are not exact golden files. They show the shape of the result you should be aiming for.

### Checkpoint 1 example

```text
Summary: Critical security and functional issues detected in payment processing logic.
Findings:
- [blocker] app/payments.py:5 Hardcoded API key exposed in source code
- [major] app/payments.py:8 Mutable default argument `amount=[]` can cause unexpected behavior
- [blocker] app/payments.py:11 SQL query vulnerable to SQL injection via user input
Verdict: blocking issues detected
Usage: 1500 in, 503 out, 2 call(s), cost=$0.0006
```

### Checkpoint 2 example

```text
Summary: Found 4 issues: hard-coded secret, bare except block, silent error swallowing, and use of print() instead of logging.
Findings:
- [blocker] app/payments.py:4 (SEC-001) Hard-coded API key detected. Secrets should be loaded from environment variables or a secret manager.
- [blocker] app/payments.py:10 (PY-ERRORS-002) Bare `except:` block found. Catch the narrowest exception type or re-raise.
- [blocker] app/payments.py:10 (REL-002) Except block silently swallows errors with `pass`.
- [major] app/payments.py:8 (PY-LOGGING-004) Use of `print()` for diagnostics detected.
Verdict: blocking issues detected
Usage: 1944 in, 568 out, 2 call(s), cost=$0.0007
```

## How to compare models or prompts fairly

Students will naturally want to try a larger model or a different prompt. Do it as a controlled experiment.

- Keep the same eval cases.
- Keep the same indexed rule corpus.
- Change one variable at a time: model **or** prompt **or** retrieval settings.
- Record at least: precision, recall, false-positive rate, tokens, and cost.
- Keep one short note explaining *why* you think the change helped.

That discipline matters more than whether your first instinct is `mistral-small-2603`, a larger Mistral model, or a different provider.

## Setting up the GitLab sandbox project

The reviewer reads diffs and posts comments — and you feed it hostile input on purpose (the
prompt-injection case) — so point it at a **dedicated sandbox project, never a real repo.**

> **In the TELECOM Nancy course** the instructor creates your pair's sandbox, already seeded with
> MRs and with `main` protected, and makes you Maintainer on it: do only steps 2 and 3 below
> (the bot's token and `.env`). Steps 1 and 4 are for running the reviewer outside the course.

1. **Create a project** on your GitLab (e.g. `mr-reviewer-sandbox`).
2. **Settings → Access Tokens → Project Access Token:** scope **`api`**, role **Developer** — enough
   to read diffs and post inline comments. **Not** Maintainer/Owner: the bot must not be able to
   merge (least privilege; Book Ch. 10, excessive agency).
3. Copy the **Project ID** (shown under the project title, or ⋮ → *Copy project ID*) into
   `GITLAB_PROJECT_ID`, and the token into `GITLAB_TOKEN` in your `.env`.
4. **Give it MRs to review.** Turn the diffs in `evals/cases/` into real branches + merge requests so
   you have repeatable targets (including the injection case). Sketch with `python-gitlab` (eval diffs
   are illustrative — for a real MR you commit the changed file content):

    ```python
    import gitlab
    gl = gitlab.Gitlab(GITLAB_URL, private_token=GITLAB_TOKEN)
    proj = gl.projects.get(GITLAB_PROJECT_ID)
    for case in cases:                       # from evals/cases/manifest.json
        branch = f"case/{case['id']}"
        proj.branches.create({"branch": branch, "ref": "main"})
        proj.files.create({"file_path": case["path"], "branch": branch,
                           "content": case["changed_code"], "commit_message": case["id"]})
        proj.mergerequests.create({"source_branch": branch, "target_branch": "main",
                                  "title": case["id"]})
    ```

   For a class: a shared sandbox with a branch/MR per pair, or one project per pair (no comment
   collisions). Then `mr-reviewer review --mr <iid> --post` reviews a real MR end-to-end.

## Observability with Langfuse (local)

`docker compose up -d` starts a **local** Langfuse at <http://localhost:3000> (pinned to v2 — a
lightweight single-container self-host; v3 additionally needs ClickHouse, Redis and MinIO). You wire
tracing into the reviewer on Day 4 (Book Ch. 9).

**You don't need to create keys by hand.** The compose file auto-initialises an organisation, a
project ("MR Reviewer"), API keys, and a login user on first boot via the `LANGFUSE_INIT_*`
variables, so the keys already in `.env.example` work immediately:

```bash
LANGFUSE_HOST=http://localhost:3000
LANGFUSE_PUBLIC_KEY=pk-lf-local
LANGFUSE_SECRET_KEY=sk-lf-local
```

To open the dashboard, log in at <http://localhost:3000> with the auto-created user:

- email: `dev@local.test`
- password: `langfuse-local`

**To create your own keys instead** (or if you removed the `LANGFUSE_INIT_*` block):

1. Open <http://localhost:3000> and **sign up** (self-hosted accounts are created locally — no email
   needed) or log in.
2. Create (or open) an **Organization**, then a **Project**.
3. Go to **Project → Settings → API Keys → Create new API key**.
4. Copy the **Public key** (`pk-lf-...`) and **Secret key** (`sk-lf-...`) — the secret is shown
   **once** — into `LANGFUSE_PUBLIC_KEY` / `LANGFUSE_SECRET_KEY` in your `.env`, and set
   `LANGFUSE_HOST=http://localhost:3000`.

> These init values and the `NEXTAUTH_SECRET` / `SALT` in `docker-compose.yml` are **local-dev only**
> — change them (and use real secret keys) for anything beyond your laptop.

## The output contract (`--format json`)

The Day-4.5 grader, and any script of yours, calls the reviewer like this:

```bash
mr-reviewer review --diff <file.diff> --format json
```

and reads **one** JSON object on stdout, shaped like the `Review` schema:

```json
{
  "summary": "…",
  "findings": [
    {"file": "app/x.py", "line": 12, "severity": "blocker", "message": "…", "rule_id": "SEC-001"}
  ],
  "usage": {"input_tokens": 1200, "output_tokens": 340, "cost_usd": 0.004}
}
```

`usage` is **required for the final challenge**: every review must go through an LLM call, and the
grader (run with `--require-llm`) scores a review whose `usage.input_tokens` is missing or 0 as an
empty review. Deterministic checks are welcome as a complement. There is **no** `approved` field:
the verdict is derived from the severities
(any `major`/`blocker` ⇒ not approved), exactly like `Review.has_blocking_issues`. Anything else
printed on stdout (logs, progress) risks breaking the parse — log to stderr.

## Running the evals

```bash
uv run pytest evals/ -v          # precision / recall / false-positive on the labelled set
```

The same command runs in CI (`.gitlab-ci.yml`) and is meant to **gate merges** once you set a
threshold (Day 4).

## Layout

```text
src/mr_reviewer/
  config.py        # settings from env
  llm.py           # LLM client wrapper — cost/usage done; provider call is your CP1 stub
  schemas.py       # Pydantic Review / Finding models (done)
  cli.py           # entrypoint: `mr-reviewer review ...`
  rag/             # Checkpoint 2: index + retrieve the rule base
  agent/           # Checkpoint 3: the agent loop + tools (AgentResult = trajectory record)
  mcp_server/      # Checkpoint 3: GitLab MCP server
  mcp_client.py    # provided: stdio MCP client, errors as data
rules/             # the rule base (RAG corpus) — multi-file, ~75+ rules across categories
evals/             # labelled diffs + pytest harness (sample provided) — read-only for agents
hooks/             # protect_evals.py: the pre-tool hook that enforces AGENTS.md
AGENTS.md          # context + hard rules for your coding agent (CLAUDE.md points here)
.claude/settings.json  # example Claude Code wiring (deny rules + hook)
docs/CHECKPOINTS.md# what to build each day · docs/HARNESS.md: your agent's harness
```

See `docs/CHECKPOINTS.md` to begin.
