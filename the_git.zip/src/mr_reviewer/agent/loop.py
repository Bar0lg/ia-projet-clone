"""A hand-built agent loop: plan -> act -> observe (Book Ch. 6).

You implement this yourself rather than importing a framework — the loop is where the
engineering lives (budgets, timeouts, termination, observability).
"""
from __future__ import annotations

from dataclasses import dataclass, field

from ..config import settings
from ..llm import LLMClient
from ..schemas import Review


@dataclass
class AgentResult:
    """What one agent run produced AND how it got there (Book Ch. 6 sec. 6.6).

    `review` is the outcome. Everything else is the per-run *trajectory record*: outcome metrics
    say whether the review was right, trajectory metrics say what it cost to be right. A
    reviewer that is correct but re-fetches the same diff three times fails in production for
    reasons no outcome metric shows -- so Checkpoint 3 must fill every field, the CLI prints the
    record on stderr after a `--mr` run, and `--mr --format json` adds it under a `trajectory`
    key (the `--diff` contract is unchanged: `summary`, `findings`, `usage`).
    """

    review: Review
    steps_taken: int
    tools_used: list[str] = field(default_factory=list)   # tool names in call order
    redundant_calls: int = 0        # same tool + same arguments called twice: pure waste
    input_tokens: int = 0
    output_tokens: int = 0
    cost_usd: float = 0.0           # from LLMClient.usage, after the run
    terminated_by: str = "final"    # "final" | "step_budget" | "error"
    wall_clock_s: float = 0.0       # including tool timeouts

    def as_dict(self) -> dict:
        return {
            "steps_taken": self.steps_taken,
            "tools_used": self.tools_used,
            "redundant_calls": self.redundant_calls,
            "input_tokens": self.input_tokens,
            "output_tokens": self.output_tokens,
            "cost_usd": round(self.cost_usd, 6),
            "terminated_by": self.terminated_by,
            "wall_clock_s": round(self.wall_clock_s, 2),
        }


def run_agent(
    goal: str,
    client: LLMClient | None = None,
    max_steps: int = settings.agent_max_steps,
    timeout_seconds: int = settings.agent_timeout_seconds,
) -> AgentResult:
    """Run the review agent to completion or until the step budget is exhausted.

    The budget and per-tool timeout default to the values in `settings` (configurable via
    the environment / .env) so a runaway loop can't burn the API budget.

    Skeleton of the loop you must implement:

        client = client or LLMClient()
        messages = [system_prompt(), {"role": "user", "content": goal}]
        for step in range(max_steps):
            resp = client.complete(messages, tools=TOOL_SCHEMAS)
            if resp has a final structured Review:   # explicit termination
                return AgentResult(review, step + 1)
            if not resp.tool_calls:                  # prose, or tool_calls: null
                append a corrective "respond with a tool call or the final review" message
                continue                             # the step still counts
            for tool_call in resp.tool_calls:
                obs = dispatch(tool_call.name, tool_call.arguments)  # with timeout_seconds
                append tool_call + obs to messages
        # budget exhausted -> raise (fail loudly). The CLI catches it, prints the partial
        # findings on stderr and exits non-zero: never report it as a clean review, since zero
        # findings would read as an approval.

    TODO(checkpoint-3): implement the loop with:
      - a step budget (max_steps),
      - per-tool timeouts (timeout_seconds) and error-as-data handling,
      - explicit termination via a final structured Review,
      - the trajectory record filled in (AgentResult: tools_used in order, redundant_calls,
        tokens and cost from client.usage, terminated_by, wall_clock_s) -- the CLI prints it on
        stderr and includes it as `trajectory` in `--mr --format json`; on StepBudgetExceeded,
        carry the partial findings AND the record (terminated_by="step_budget") in the exception,
      - a trace span per step (Checkpoint 4 / Book Ch. 9).
      - a final-answer prompt that explicitly asks for a *findings array* (severity, file,
        line, message, rule_id) — a terse "produce the review" prompt tends to yield a prose
        summary with zero findings, so the verdict comes out wrong.
    """
    raise NotImplementedError("Implement the agent loop in Checkpoint 3 (Book Ch. 6).")
