"""The agent loop and its tools (Checkpoint 3, Book Ch. 6)."""
