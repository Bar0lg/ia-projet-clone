"""MR Reviewer — an automated GitLab merge request reviewer (course starter).

Fill in the `TODO(checkpoint-N)` stubs as you progress through the week.
See docs/CHECKPOINTS.md.
"""

__version__ = "0.1.0"
