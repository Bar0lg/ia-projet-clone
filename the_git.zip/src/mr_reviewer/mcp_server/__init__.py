"""A GitLab MCP server exposing the reviewer's actions (Checkpoint 3, Book Ch. 7)."""
