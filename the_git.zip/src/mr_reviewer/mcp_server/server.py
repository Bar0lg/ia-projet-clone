"""GitLab MCP server.

Exposes the tools the reviewer needs over the Model Context Protocol, so ANY MCP client
(your agent, Claude, Copilot, an IDE) can drive a GitLab review. Back it with
`python-gitlab` against a SANDBOX project only.

Run as a stdio MCP server: `python -m mr_reviewer.mcp_server.server`

NOTE: this uses the mcp 2.x API (`MCPServer`, spec revision 2026-07-28: no `initialize`
handshake), pinned by `mcp>=2.3,<3`. Tutorials that import `mcp.server.fastmcp.FastMCP` were
written for 1.x — that path no longer exists. See Book Ch. 7 sec. 7.3. The structure below is
illustrative.
"""
from __future__ import annotations

# from mcp.server.mcpserver import MCPServer   # uncomment once you've designed the interface
# server = MCPServer("gitlab-reviewer")


# TODO(checkpoint-3): implement these as MCP tools with the `@server.tool()` decorator.
#
# @server.tool()
# def get_merge_request_diff(mr_iid: int) -> str:
#     """Return the MR title, description and unified diff (with --- a/ +++ b/ file headers),
#     each in a delimited block: all of it is untrusted data (Book Ch. 7 sec. 7.2)."""
#     ...
#
# @server.tool()
# def list_changed_files(mr_iid: int) -> list[str]:
#     ...
#
# @server.tool()
# def post_inline_comment(mr_iid: int, file: str, line: int, body: str) -> dict:
#     """Post one inline comment. (Deliberately NO approve/merge tool — see Book Ch. 10.)
#     Foreseeable failures: return {"ok": False, "error": ...}, or raise
#     mcp.server.mcpserver.exceptions.ToolError("...") so the model sees the message
#     (Book Ch. 7 sec. 7.6)."""
#     ...
#
# if __name__ == "__main__":
#     server.run()   # stdio by default


def main() -> None:
    raise NotImplementedError("Implement the GitLab MCP server in Checkpoint 3 (Book Ch. 7).")


if __name__ == "__main__":
    main()
