"""Command-line entrypoint: `mr-reviewer review --diff <file>` or `--mr <iid>`.

Checkpoint 1: implement the local-diff path.
Checkpoint 3: implement the --mr path (fetch via the GitLab MCP server, post comments).
"""
from __future__ import annotations

import pathlib

import typer

app = typer.Typer(add_completion=False, help="Automated GitLab MR reviewer.")


@app.callback()
def main() -> None:
    """Automated GitLab MR reviewer.

    A callback is defined so Typer keeps `review` as an explicit subcommand
    (without it, a single-command app is invoked as `mr-reviewer --diff ...`).
    """


@app.command()
def review(
    diff: pathlib.Path | None = typer.Option(None, help="Path to a unified diff file."),
    mr: int | None = typer.Option(None, help="GitLab merge request IID to review."),
    post: bool = typer.Option(False, help="Post inline comments back to the MR (Checkpoint 3)."),
    output_format: str = typer.Option(
        "text", "--format", help="Output format: 'text' (human) or 'json' (machine contract)."
    ),
) -> None:
    """Review a diff (local file) or a GitLab merge request."""
    if output_format not in ("text", "json"):
        typer.echo("--format must be 'text' or 'json'.", err=True)
        raise typer.Exit(code=2)

    if diff is not None:
        diff_text = diff.read_text(encoding="utf-8")
        # TODO(checkpoint-1): build messages, call the LLM, get a validated Review,
        # print findings, and print the run's token usage + cost.
        # TODO(checkpoint-1): honour --format json — the CONTRACT used by the final grader
        # (Day 4.5) and handy for your own scripts. Print exactly ONE JSON object on stdout:
        #     {"summary": ..., "findings": [{file, line, severity, message, rule_id}, ...],
        #      "usage": {"input_tokens": ..., "output_tokens": ..., "cost_usd": ...}}
        # `usage` is REQUIRED by the final grader: it proves the review went through an LLM call.
        # e.g. `review.model_dump(mode="json")` plus the client's usage. Nothing else may go to
        # stdout in json mode: send logs to stderr. The verdict is NOT part of the contract —
        # the grader derives it from severities, exactly like Review.has_blocking_issues.
        # TODO(checkpoint-2): retrieve relevant rules and include them; cite rule_id in findings.
        typer.echo(f"[stub] would review {len(diff_text)} chars of diff. "
                   "Implement in Checkpoint 1.")
        raise typer.Exit(code=0)

    if mr is not None:
        # TODO(checkpoint-3): run the agent loop (READ tools only) against the MR via the GitLab
        # MCP server; then, if --post, validate and redact the findings and post them YOURSELF via
        # MCPClient.call_tool("post_inline_comment", ...). The agent never posts (Book Ch. 7, 10).
        typer.echo(f"[stub] would review MR !{mr} via the agent + MCP. Implement in Checkpoint 3.")
        raise typer.Exit(code=0)

    typer.echo("Provide --diff <file> or --mr <iid>.")
    raise typer.Exit(code=2)


if __name__ == "__main__":
    app()
