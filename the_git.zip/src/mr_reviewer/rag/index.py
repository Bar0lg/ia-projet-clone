"""Build the vector index over the rule base.

TODO(checkpoint-2):
  1. Load and chunk the rule files returned by `corpus_files()` (one chunk per rule is a good
     starting point).
  2. Embed each chunk (see mr_reviewer.llm.embed).
  3. Store id, text, rule_id, and vector in pgvector (settings.database_url).

The "stuff everything" baseline must read the SAME files (`corpus_files()`), or the
baseline-vs-RAG comparison compares two different corpora. Day 2, phase 2 grows the corpus with
RULES_TIER (see settings.rules_tier): rebuild the index from scratch after every change, or the
table still holds the vectors of the previous tier.

Run as: `python -m mr_reviewer.rag.index`
"""
from __future__ import annotations

import pathlib

ROOT = pathlib.Path(__file__).resolve().parents[3]
RULES_DIR = ROOT / "rules"
RULES_EXTRA_DIR = ROOT / "rules-extra"
MAX_TIER = 3


def corpus_files(tier: int | None = None) -> list[pathlib.Path]:
    """Return the rule files of the corpus at `tier` (default: settings.rules_tier).

    Tier 0 is `rules/` alone; tier n adds `rules-extra/tier1` ... `rules-extra/tier<n>`.
    """
    if tier is None:
        from mr_reviewer.config import settings

        tier = settings.rules_tier
    if not 0 <= tier <= MAX_TIER:
        raise ValueError(f"rules tier must be between 0 and {MAX_TIER}, got {tier}")
    dirs = [RULES_DIR] + [RULES_EXTRA_DIR / f"tier{n}" for n in range(1, tier + 1)]
    return [path for directory in dirs for path in sorted(directory.glob("*.md"))]


def build_index() -> int:
    """Index the rule base; return the number of chunks indexed.

    TODO(checkpoint-2): implement chunking + embedding + upsert into pgvector.
    """
    raise NotImplementedError("Implement the rule-base index in Checkpoint 2 (Book Ch. 5).")


if __name__ == "__main__":
    n = build_index()
    print(f"Indexed {n} rule chunks.")
