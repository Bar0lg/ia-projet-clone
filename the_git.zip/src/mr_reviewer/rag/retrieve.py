"""Retrieve the rules relevant to a diff.

TODO(checkpoint-2):
  1. Build a query from the diff content (not just the filename).
  2. Embed it, run top-k similarity search in pgvector.
  3. (optional) rerank, then return the rules to inject into the review prompt.

Measure recall@k against evals/cases before trusting it (Book Ch. 5 & 8). The rule corpus in
`rules/` is intentionally large and multi-file, so retrieval (not "stuff everything in the prompt")
is what keeps reviews cheap and focused — show that in the Day-2 baseline-vs-RAG comparison.
"""
from __future__ import annotations

from dataclasses import dataclass


@dataclass
class RetrievedRule:
    rule_id: str
    text: str
    score: float


def retrieve_rules(diff_text: str, k: int = 5) -> list[RetrievedRule]:
    """Return the top-k rules relevant to `diff_text`.

    TODO(checkpoint-2): implement query construction + vector search.
    """
    raise NotImplementedError("Implement rule retrieval in Checkpoint 2 (Book Ch. 5).")


def rerank(query: str, candidates: list[RetrievedRule], top: int = 5) -> list[RetrievedRule]:
    """Optionally re-score (query, rule) pairs and keep the best `top`.

    TODO(stretch, Day 2 challenge): hybrid BM25 + vector retrieval and/or a cross-encoder rerank.
    Measure the precision/recall lift versus plain vector search before keeping it.
    """
    raise NotImplementedError("Optional stretch goal — see Day 2 challenges.")
