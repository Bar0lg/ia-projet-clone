"""Retrieval over the project's rule base (Checkpoint 2, Book Ch. 5)."""
