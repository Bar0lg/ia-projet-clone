"""Configuration, loaded from environment / .env (see .env.example)."""
from __future__ import annotations

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    # LLM — default to Mistral (free tier, EU-hosted, native embeddings). Override in .env;
    # see the provider blocks in .env.example. Pin a dated model version for reproducibility.
    llm_provider: str = "mistral"
    llm_api_key: str = "changeme"
    llm_model: str = "mistral-small-2603"  # Mistral Small 4; a dated version, not -latest"
    llm_embed_model: str = "mistral-embed"
    llm_max_tokens: int = 2048
    llm_temperature: float = 0.0

    # Vector store
    database_url: str = "postgresql://reviewer:reviewer@localhost:5432/reviewer"
    # Rule corpus size (Day 2, phase 2): 0 = rules/ only (75 rules); 1, 2, 3 add the cumulative
    # tiers of rules-extra/ (150, 300, ~500 rules). Re-index after every change.
    rules_tier: int = 0

    # GitLab (sandbox only!)
    gitlab_url: str = ""
    gitlab_token: str = ""
    gitlab_project_id: int = 0

    # Langfuse
    langfuse_host: str = "http://localhost:3000"
    langfuse_public_key: str = ""
    langfuse_secret_key: str = ""

    # Agent guardrails
    agent_max_steps: int = 12
    agent_timeout_seconds: int = 120
    spend_cap_usd: float = 5.0


settings = Settings()
