"""Structured output contracts for the reviewer.

A review is NOT prose — it is a list of findings your code can act on. This is the
"structured output" idea from Book Ch. 2: define the contract, validate against it.
These models are provided complete; you will extend them as needed.
"""
from __future__ import annotations

from enum import Enum

from pydantic import BaseModel, Field


class Severity(str, Enum):
    info = "info"
    minor = "minor"
    major = "major"
    blocker = "blocker"


class Finding(BaseModel):
    """A single issue the reviewer raises about a specific location in the diff."""

    file: str = Field(description="Path of the file the finding refers to.")
    line: int | None = Field(
        default=None, description="1-based line number in the new version, if applicable."
    )
    severity: Severity
    message: str = Field(description="What is wrong and what to do about it.")
    rule_id: str | None = Field(
        default=None,
        description="Id of the project rule this finding enforces (from the rule base). "
        "Required once RAG is wired in (Checkpoint 2).",
    )


class Review(BaseModel):
    """The full result of reviewing one merge request / diff."""

    summary: str = Field(description="One-paragraph summary of the change and its quality.")
    findings: list[Finding] = Field(default_factory=list)

    # The verdict is derived IN CODE from findings — never an 'approve' verb the model
    # can be talked into (see Book Ch. 10, prompt injection / excessive agency).
    @property
    def has_blocking_issues(self) -> bool:
        return any(f.severity in (Severity.major, Severity.blocker) for f in self.findings)
