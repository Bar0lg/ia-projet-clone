"""A minimal stdio MCP *client* (Book Ch. 7) -- PROVIDED, so Day 3 goes to the server and the loop.

The MCP *server* (`mr_reviewer.mcp_server`) is only half the boundary: something must consume it.
This client launches your server as a stdio subprocess, discovers it, lists its tools, and calls
them. `agent/tools.dispatch` routes the GitLab tools through it (Checkpoint 3), and the CLI uses
it after the loop to post the validated, redacted findings (`post_inline_comment`).

It is written against the official Python SDK 2.x (`mcp>=2.3,<3`, spec revision 2026-07-28):
`Client(StdioServerParameters(...))` starts the server and sends `server/discover`; there is no
`initialize()` handshake (that was SDK 1.x: `stdio_client` + `ClientSession`). Results expose
`is_error`, `content` (a list of content blocks, `.text` on text blocks) and
`structured_content` (Book Ch. 7 sec. 7.3 and 7.6).

Design choices worth reading:
  * **Errors are data.** A tool that fails (`is_error` true, a `ToolError`, a crashed server, a
    timeout) comes back as `{"error": "..."}`, never as an exception: the agent loop observes it
    and can recover (Book Ch. 6 sec. 6.5).
  * **The loop is synchronous**, the SDK is async: each call runs its own event loop with
    `asyncio.run`, from whatever thread the loop uses for its per-tool timeout.
  * **One stdio session per call.** Correct and simple, but every call spawns a Python process.
    Keeping one session open for a whole review (`async with Client(...)` around the loop) is a
    reasonable stretch goal once everything works.

Smoke-test the round-trip on its own before wiring it into the loop (`python -m
mr_reviewer.mcp_client` lists your server's tools), so transport bugs do not hide behind loop
bugs. `tests/test_mcp_client.py` does the same against a tiny echo server.
"""
from __future__ import annotations

import asyncio
import json
import sys
from dataclasses import dataclass, field


def _default_server_args() -> list[str]:
    return ["-m", "mr_reviewer.mcp_server.server"]


@dataclass
class MCPClient:
    """Talks to an MCP server over stdio. Defaults to *your* GitLab server."""

    command: str = sys.executable
    args: list[str] = field(default_factory=_default_server_args)
    timeout_seconds: float | None = None   # per-call read timeout; None = SDK default

    # -- public, synchronous API ------------------------------------------------------------

    def list_tools(self) -> list[str]:
        """Names of the tools the server advertises (`tools/list`). Errors as data: []."""
        try:
            return asyncio.run(self._list_tools())
        except Exception as e:   # noqa: BLE001 - the whole point is to observe, not crash
            return [f"error: {e}"]

    def call_tool(self, name: str, arguments: dict) -> dict:
        """Call `name` with `arguments`; always returns a dict the model can read.

        Success: {"ok": True, "text": "<first text block>", "content": [...all blocks...],
                  "structured": <structured_content or None>}
        Failure: {"ok": False, "error": "<reason>"}  (is_error result, ToolError, exception,
                  server not starting, timeout...)
        """
        try:
            return asyncio.run(self._call_tool(name, arguments))
        except Exception as e:   # noqa: BLE001
            return {"ok": False, "error": f"{type(e).__name__}: {e}"}

    # -- async internals -----------------------------------------------------------------

    def _params(self):
        from mcp import StdioServerParameters
        return StdioServerParameters(command=self.command, args=list(self.args))

    async def _list_tools(self) -> list[str]:
        from mcp import Client
        async with Client(self._params(), read_timeout_seconds=self.timeout_seconds) as client:
            result = await client.list_tools()
            return [tool.name for tool in result.tools]

    async def _call_tool(self, name: str, arguments: dict) -> dict:
        from mcp import Client
        async with Client(self._params(), read_timeout_seconds=self.timeout_seconds) as client:
            result = await client.call_tool(name, arguments)
        blocks = [_block_to_json(b) for b in (result.content or [])]
        text = next((b["text"] for b in blocks if "text" in b), "")
        if result.is_error:
            return {"ok": False, "error": text or "tool reported an error without a message"}
        return {"ok": True, "text": text, "content": blocks,
                "structured": result.structured_content}


def _block_to_json(block) -> dict:
    """Content blocks are Pydantic models; keep them JSON-friendly for the message history."""
    if hasattr(block, "model_dump"):
        d = block.model_dump(mode="json", exclude_none=True)
        return d if isinstance(d, dict) else {"value": d}
    return {"value": str(block)}


def main() -> None:
    """`python -m mr_reviewer.mcp_client [tool] [json-arguments]` -- a hand smoke test."""
    client = MCPClient()
    if len(sys.argv) == 1:
        print(json.dumps({"tools": client.list_tools()}, indent=2))
        return
    name = sys.argv[1]
    arguments = json.loads(sys.argv[2]) if len(sys.argv) > 2 else {}
    print(json.dumps(client.call_tool(name, arguments), indent=2, default=str))


if __name__ == "__main__":
    main()
