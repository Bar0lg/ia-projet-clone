"""LLM client wrapper with token + cost logging.

The cost/usage accounting is provided so you instrument calls from day one (Book Ch. 9).
The actual provider call is a stub: wire it to your provider's SDK in Checkpoint 1.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field

from .config import settings
import os

log = logging.getLogger("mr_reviewer.llm")

from google import genai
client:genai.Client = genai.Client(api_key=os.environ.get("LLM_API_KEY"))


# Approximate USD per 1K tokens. UPDATE for your model/provider. Defaults: mistral-small-2603
# (Mistral Small 4, ~$0.15 / $0.60 per million tokens, Oct 2026). Reasoning tokens bill as output.
PRICE_PER_1K = {
    "input": 0.00015,
    "output": 0.0006,
}


@dataclass
class Usage:
    input_tokens: int = 0
    output_tokens: int = 0
    calls: int = 0

    @property
    def cost_usd(self) -> float:
        return (
            self.input_tokens / 1000 * PRICE_PER_1K["input"]
            + self.output_tokens / 1000 * PRICE_PER_1K["output"]
        )

    def add(self, input_tokens: int, output_tokens: int) -> None:
        self.input_tokens += input_tokens
        self.output_tokens += output_tokens
        self.calls += 1


@dataclass
class LLMClient:
    """Thin wrapper around a chat-completions / messages API."""

    model: str = field(default_factory=lambda: settings.llm_model)
    usage: Usage = field(default_factory=Usage)

    def complete(
        self,
        messages: list[dict],
        tools: list[dict] | None = None,
        max_tokens: int | None = None,
        temperature: float | None = None,
    ) -> dict:
        """Return a normalized response dict, e.g.:
            {"text": str | None, "tool_calls": [...], "usage": {...}}

        TODO(checkpoint-1): call your provider's SDK here (anthropic / openai / ...),
        pass through `tools` for function calling, then record usage:

            self.usage.add(resp_input_tokens, resp_output_tokens)
            log.info("llm call: %s in / %s out, run cost=$%.4f",
                     resp_input_tokens, resp_output_tokens, self.usage.cost_usd)

        and enforce settings.spend_cap_usd (abort if exceeded).

        NOTE: convert `tools` to your provider's function-calling schema before sending
        (see the shape note in agent/tools.py) — the wrong shape returns a 422.
        NOTE: providers may return `tool_calls: null` when there is no call; a
        dict.get("tool_calls", []) will NOT save you (the key exists with value null).
        Normalize null -> [] so your agent loop can iterate safely.
        """

        response = client
        raise NotImplementedError("Wire up your LLM provider in Checkpoint 1 (see Book Ch. 2).")

    def complete_structured(self, messages: list[dict], schema: type) -> object:
        """Return an instance of `schema` (a Pydantic model), validating the model's JSON.

        TODO(checkpoint-1): request structured/JSON output, parse with
        `schema.model_validate_json(...)`, and on validation failure retry ONCE with the
        error appended to the prompt before giving up.

        NOTE: models sometimes wrap the result in an envelope, e.g. {"review": {...}}, or
        rename fields (file_path/line_number/description). Unwrap/normalize before validating
        rather than failing outright.
        """
        raise NotImplementedError("Implement structured output in Checkpoint 1 (Book Ch. 2).")


def embed(texts: list[str]) -> list[list[float]]:
    """Return an embedding vector per input text.

    TODO(checkpoint-2): use settings.llm_embed_model via your provider, OR fall back to a
    local sentence-transformers model if llm_embed_model is empty.
    """
    raise NotImplementedError("Implement embeddings in Checkpoint 2 (Book Ch. 4).")
