# Reliability rules — errors, exceptions, concurrency, resources

Conventions for robust, fault-tolerant code. One rule per `##` section.

---

## REL-001 — No bare or overly broad excepts
Never write `except:` or `except Exception:` without either handling specifically or re-raising.
Catch the narrowest exception that applies. Silently swallowing exceptions is a **blocker** because
it hides failures.

## REL-002 — Don't swallow errors silently
An `except` block that only `pass`es, or logs at debug and continues as if nothing happened, hides
real failures. Either handle meaningfully, re-raise, or fail loudly.

## REL-003 — Preserve exception context
When re-raising, preserve the cause (`raise NewError(...) from err`); do not discard the original
traceback. Losing the cause makes incidents hard to diagnose.

## REL-004 — Close resources with context managers
Files, sockets, locks, and DB connections/cursors must be released deterministically — use `with`
(or try/finally). A resource acquired without a guaranteed release is a **major** issue (leak).

## REL-005 — No mutable default arguments
Never use a mutable default argument (`def f(x=[])` / `={}`); the default is shared across calls.
Use `None` and create inside. This is a classic latent bug.

## REL-006 — Time out every external call
Network, DB, and subprocess calls must have explicit timeouts. An un-timed call can hang the whole
service. Missing timeouts on I/O are a finding.

## REL-007 — Retries with backoff and a cap, only for idempotent ops
Transient failures may be retried with exponential backoff and a maximum attempt count. Never retry
a non-idempotent operation without a safeguard (idempotency key), and never retry without a cap.

## REL-008 — Fail fast on invalid state
Validate invariants/preconditions early and raise a clear error, rather than continuing in a
corrupt state that fails confusingly later.

## REL-009 — No shared mutable state without synchronization
State shared across threads/tasks must be synchronized (lock, queue) or made immutable. Unsynchronised
shared mutation is a data-race **blocker**. Prefer message passing or immutable data over shared locks
where possible; document the locking discipline when locks are unavoidable, and never hold a lock
across an `await` or a blocking I/O call.

## REL-010 — Don't block the event loop
In async code, never call blocking I/O or CPU-heavy work directly inside a coroutine; offload to an
executor or use async equivalents. Blocking the event loop is a **major** issue.

## REL-011 — Cancellation and cleanup in async
Async tasks must handle cancellation and clean up resources (use `finally`/`async with`). Fire-and-
forget tasks whose exceptions are never awaited or logged are a finding.

## REL-012 — Avoid race conditions in check-then-act
Do not "check then act" on shared external state (file exists → create; row absent → insert) without
atomicity (a transaction, unique constraint, or lock). Such TOCTOU patterns corrupt data under
concurrency.

## REL-013 — Bound queues and buffers
Unbounded queues, caches, or buffers are a memory-exhaustion risk. Set explicit limits and a policy
for what happens when full (block, drop, error).

## REL-014 — Make operations idempotent where retried
Handlers that may be delivered more than once (webhooks, queue consumers) must be idempotent or
deduplicate, so a retry doesn't double-charge / double-process.

## REL-015 — No silent data loss on partial failure
When processing a batch, a single item's failure must not silently drop the rest or the failed item;
define and implement the partial-failure policy explicitly.
