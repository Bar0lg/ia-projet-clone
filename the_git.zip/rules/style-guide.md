# Project coding rules (sample rule base)

This is the RAG corpus the reviewer retrieves from. Each rule has a stable `id` the reviewer
cites in its findings. **Instructors: replace/extend with your real conventions.** Keep one
clearly-scoped rule per section so per-rule chunking works well.

---

## PY-NAMING-001 — Names
Use `snake_case` for functions and variables, `PascalCase` for classes, and `UPPER_SNAKE_CASE`
for module-level constants. Names must be descriptive; single-letter names are only acceptable as
loop indices.

## PY-ERRORS-002 — No bare or broad excepts
Never write `except:` or `except Exception:` without re-raising or handling specifically. Catch the
narrowest exception type that applies. Swallowing exceptions silently is a blocker.

## PY-SECRETS-003 — No secrets in code
Never hard-code credentials, API keys, tokens, or passwords in source. Load them from environment
or a secret manager. A literal that looks like a key/token is a blocker.

## PY-LOGGING-004 — Use the logging module
Do not use `print()` for diagnostics in library/application code; use the `logging` module. Never
log secrets or full request/response bodies that may contain personal data.

## PY-SQL-005 — Parameterized queries only
Build SQL with parameter placeholders, never by string concatenation or f-strings with user input
(SQL injection). This is a blocker.

## PY-RESOURCES-006 — Close resources
Use context managers (`with`) for files, sockets, and DB connections. A resource opened without a
guaranteed close is a major issue.

## PY-TYPING-007 — Public functions are typed
Public functions and methods must have type hints on parameters and return values.

## PY-TESTS-008 — Behaviour changes need tests
A change to behaviour (not pure refactor) must come with or update tests. Untested behaviour change
is a major issue.

## PY-MUTABLE-009 — No mutable default arguments
Never use a mutable default argument (`def f(x=[])`); use `None` and create inside. This is a
classic latent bug.

## PY-CONCURRENCY-010 — No shared mutable state without synchronization
Shared mutable state accessed from multiple threads/tasks must be synchronized or made immutable.
