# Performance and API-design rules

Conventions for efficient code and well-designed interfaces. One rule per `##` section.

---

## PERF-001 — No N+1 queries
Do not issue a query per item inside a loop; batch with a join, an `IN (...)`, or a bulk fetch.
N+1 query patterns are a common, severe performance defect.

## PERF-002 — Don't load unbounded result sets into memory
Paginate or stream large queries and file reads; never `fetchall()` / read an entire large file when
the size is unbounded. Unbounded in-memory loads are a finding.

## PERF-003 — Avoid repeated work in hot paths
Hoist invariant computation out of loops; cache expensive pure results; don't recompile a regex or
re-open a connection on every call in a hot path.

## PERF-004 — Choose appropriate data structures
Use a set/dict for membership and lookup (O(1)) instead of scanning a list (O(n)) in hot paths.
Quadratic loops over large inputs are a finding.

## PERF-005 — Stream large payloads
Stream large HTTP responses and file transfers rather than buffering them fully in memory.

## PERF-006 — Measure before optimising
Performance changes must be justified by a measurement (benchmark/profile), not a hunch. "Optimised"
code that is unmeasured and less readable is a finding.

## PERF-007 — Release the GIL / offload CPU work
CPU-bound work in a request path should be offloaded (worker, process pool) rather than blocking the
request/event loop.

## API-001 — Stable, explicit interfaces
Public functions/endpoints have explicit, typed parameters and return values. Avoid returning loosely
typed dicts from public APIs where a typed model is clearer.

## API-002 — Validate inputs at the boundary
API handlers validate and coerce inputs with a schema at the edge, so the core works with trusted,
typed data.

## API-003 — Consistent, meaningful status codes and errors
Return correct HTTP status codes and a consistent, documented error shape. Do not return 200 with an
error body; do not leak stack traces or internal details to clients.

## API-004 — Backward compatibility / versioning
Changing a public contract (removing a field, changing a type, tightening validation) requires a
deprecation path or a version bump. Silent breaking changes to a public API are a **major** issue.

## API-005 — Idempotent and safe HTTP semantics
GET must be safe (no side effects); PUT/DELETE idempotent. Mutating state in a GET is a finding.

## API-006 — Pagination and limits on collection endpoints
Endpoints returning collections must paginate and cap page size; never return an unbounded list.

## API-007 — Avoid leaking internal identifiers and structure
Don't expose internal sequential IDs, stack traces, or implementation details in API responses where
it aids enumeration or attacks.

## API-008 — Document non-obvious behaviour
Public functions/endpoints with non-obvious semantics (units, side effects, error conditions) carry a
docstring/contract. Undocumented surprising behaviour is a finding.

## PERF-008 — Connection pooling and reuse
Reuse pooled connections/clients instead of constructing a new connection (DB, HTTP) per call; per-
call connection setup in a hot path is a finding.
