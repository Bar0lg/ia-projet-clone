# Testing, logging/observability, and typing/style rules

One rule per `##` section.

---

## TEST-001 — Behaviour changes need tests
A change to behaviour (not a pure refactor) must add or update tests. Untested behaviour change is a
**major** issue.

## TEST-002 — Tests are deterministic
No reliance on real time, network, randomness, or test ordering. Inject clocks, mock I/O, and seed
randomness. Flaky/non-deterministic tests are a finding.

## TEST-003 — Test behaviour, not implementation
Assert observable behaviour and contracts, not private internals, so refactors don't break tests
needlessly.

## TEST-004 — Cover error paths and edge cases
Tests must cover failure modes and boundaries (empty, max, invalid input), not only the happy path.

## TEST-005 — No logic only exercised in production
Don't ship branches that no test or local run ever exercises; at minimum, smoke-test new paths.

## LOG-001 — Use the logging framework, not print
Use the `logging` module (or the project's logger) for diagnostics, never `print()` in
library/application code. Choose appropriate levels.

## LOG-002 — Structured, contextual logs
Logs carry enough context (ids, operation) to be useful, ideally structured (key/value), without
dumping entire payloads (see SEC-008).

## LOG-003 — Right level, no noise
Use levels meaningfully (error for failures, info for milestones, debug for detail). Logging at error
for non-errors, or logging in tight loops, is a finding.

## LOG-004 — Make failures observable
Caught-and-handled failures that matter operationally must still be visible (a counter, a warning),
not invisible. Pair with REL-002.

## LOG-005 — Don't log and rethrow the same error repeatedly
Log an error once at the boundary that handles it; logging the same exception at every layer creates
noise.

## TYPE-001 — Public functions are typed
Public functions and methods have type hints on parameters and return values. Untyped public APIs are
a finding.

## TYPE-002 — Avoid `Any` and untyped escapes
Don't use `Any` (or untyped casts) to silence the type checker; model the real type. Overuse of `Any`
defeats typing.

## TYPE-003 — Prefer immutable and explicit data
Prefer typed, explicit data carriers (dataclasses/models) over loosely passed dicts/tuples for
structured data crossing function boundaries.

## NAME-001 — Descriptive, conventional names
`snake_case` functions/variables, `PascalCase` classes, `UPPER_SNAKE_CASE` constants. Names are
descriptive; single letters only as loop indices. Misleading names are a finding.

## STYLE-001 — Small, single-purpose functions
A function does one thing; very long functions or deeply nested control flow should be decomposed.
Excessive complexity in one unit is a finding.

## STYLE-002 — No dead or commented-out code
Remove dead code, unreachable branches, and large commented-out blocks; version control is the
history.

## STYLE-003 — No magic numbers
Replace unexplained literals with named constants that convey intent and units.

## DOC-001 — Comment the why, not the what
Comments explain rationale and non-obvious decisions, not restate the code. Stale or redundant
comments are a finding.
