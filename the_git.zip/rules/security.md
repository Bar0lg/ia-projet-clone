# Security rules

Security conventions the reviewer must enforce. **Instructors:** edit to match your real policy.
One rule per `##` section so retrieval and citation stay precise. Each rule is one short paragraph,
so one chunk per rule is the natural default.

---

## SEC-001 — No secrets in source
Never hard-code credentials, API keys, tokens, private keys, or passwords in source or config
committed to the repo. Load them from environment variables or a secret manager. A literal that
looks like a key/token (long random string, `sk-...`, `ghp_...`, PEM blocks) is a **blocker**.

## SEC-002 — Parameterized queries only
Build SQL (and any query language) with parameter placeholders bound by the driver, never by string
concatenation or f-strings containing user input. String-built queries are a SQL-injection
**blocker**. This applies equally to NoSQL query builders and to shell command construction.

## SEC-003 — No shell=True with untrusted input
Do not pass user-influenced strings to a shell (`subprocess` with `shell=True`, `os.system`,
backticks). Use argument lists and avoid the shell. Command injection is a **blocker**.

## SEC-004 — Validate and bound all external input
Every value crossing a trust boundary (HTTP body, query string, header, file, message) must be
validated for type, range, and size before use. Reject early; never assume well-formed input.

## SEC-005 — Output encoding / no injection sinks
Escape or encode data for its sink: HTML-escape before rendering, never build HTML/JS by string
concatenation, set correct content types. Untrusted data reaching an interpreter unescaped is a
blocker.

## SEC-006 — Safe deserialization
Never deserialize untrusted data with executable-capable formats (`pickle`, `yaml.load` without
`SafeLoader`, Java native serialization). Use data-only formats (JSON) and validate the result.

## SEC-007 — Least privilege for credentials and tokens
Tokens, service accounts, and DB users must have the minimum scope needed. A read task uses a
read-only credential. Broad/admin scopes for narrow tasks are a finding.

## SEC-008 — No sensitive data in logs
Never log secrets, full auth tokens, passwords, full card/PII payloads, or entire request/response
bodies that may contain them. Redact before logging.

## SEC-009 — Use vetted crypto, never roll your own
Use the platform's standard, current cryptographic libraries and algorithms. Do not implement
ciphers, hashing, or token signing by hand. Passwords are stored with a slow salted hash
(bcrypt/scrypt/argon2), never plain or fast-hashed.

## SEC-010 — Constant-time comparison for secrets
Compare secrets, tokens, and signatures with a constant-time function, not `==`, to avoid timing
side channels.

## SEC-011 — Verify TLS and certificates
Never disable certificate verification (`verify=False`, `InsecureSkipVerify`) outside a clearly
isolated test. Disabled TLS verification in application code is a blocker.

## SEC-012 — Authorisation checked server-side
Authorisation must be enforced on the server for every protected action, not assumed from the UI or
a client-supplied role. Check ownership/permission on the specific resource, not just authentication.

## SEC-013 — Safe file paths
Resolve and contain user-influenced file paths; reject `..` traversal and absolute paths that escape
the intended directory. Path traversal is a blocker.

## SEC-014 — Pin and review dependencies
Dependencies are pinned to explicit versions and reviewed before addition. Be alert to typo/
hallucinated package names ("slopsquatting"). New dependencies need justification in the MR.

## SEC-015 — No disabled security controls "temporarily"
Do not merge code that disables auth, CSRF protection, rate limiting, or validation "for now."
Commented-out or feature-flagged-off security controls are a finding unless justified and tracked.
