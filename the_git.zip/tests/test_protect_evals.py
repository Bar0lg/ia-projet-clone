"""The hook that keeps the coding agent out of evals/, tests/ and .env must fire in BOTH
directions: block what it should, stay silent on normal work (Book Ch. 12 sec. 12.8).
Runs in the CI `unit` job: no API key, no network."""
from __future__ import annotations

import json
import pathlib
import subprocess
import sys

HOOK = pathlib.Path(__file__).resolve().parents[1] / "hooks" / "protect_evals.py"


def _run_event(tool_name: str, tool_input: dict) -> subprocess.CompletedProcess:
    event = {"hook_event_name": "PreToolUse", "tool_name": tool_name, "tool_input": tool_input}
    return subprocess.run([sys.executable, str(HOOK)], input=json.dumps(event),
                          capture_output=True, text=True)


def test_edit_under_evals_is_blocked():
    r = _run_event("Edit", {"file_path": "evals/cases/manifest.json", "old_string": "a",
                            "new_string": "b"})
    assert r.returncode == 2
    assert "read-only" in r.stderr


def test_write_under_tests_is_blocked():
    r = _run_event("Write", {"file_path": "./tests/test_evals_tmp.py", "content": "x"})
    assert r.returncode == 2


def test_reading_env_is_blocked_but_env_example_is_not():
    assert _run_event("Read", {"file_path": ".env"}).returncode == 2
    assert _run_event("Read", {"file_path": ".env.example"}).returncode == 0


def test_edit_under_src_is_allowed():
    r = _run_event("Edit", {"file_path": "src/mr_reviewer/cli.py", "old_string": "a",
                            "new_string": "b"})
    assert r.returncode == 0 and r.stderr == ""


def test_running_pytest_is_allowed_but_rewriting_a_case_is_not():
    assert _run_event("Bash", {"command": "uv run pytest evals/ -v -s"}).returncode == 0
    assert _run_event("Bash", {"command": "cat evals/cases/manifest.json"}).returncode == 0
    assert _run_event("Bash", {"command": "echo '{}' > evals/cases/manifest.json"}).returncode == 2
    assert _run_event("Bash", {"command": "rm tests/test_schemas.py"}).returncode == 2
    assert _run_event("Bash", {"command": "cat .env"}).returncode == 2


def test_manual_invocation_with_paths():
    blocked = subprocess.run([sys.executable, str(HOOK), "evals/cases/case01.diff"],
                             capture_output=True, text=True)
    allowed = subprocess.run([sys.executable, str(HOOK), "README.md"],
                             capture_output=True, text=True)
    assert blocked.returncode == 2 and allowed.returncode == 0


def test_garbage_input_never_blocks():
    r = subprocess.run([sys.executable, str(HOOK)], input="not json", capture_output=True,
                       text=True)
    assert r.returncode == 0
