"""Round-trip of the provided stdio MCP client against a tiny echo server (Book Ch. 7).
No API key, no network, no GitLab: it only proves the transport and the error-as-data contract.
Skips if the `mcp` SDK is not installed."""
from __future__ import annotations

import pathlib
import sys

import pytest

pytest.importorskip("mcp")

from mr_reviewer.mcp_client import MCPClient  # noqa: E402

ECHO_SERVER = pathlib.Path(__file__).with_name("_echo_mcp_server.py")


@pytest.fixture(scope="module")
def client() -> MCPClient:
    return MCPClient(command=sys.executable, args=[str(ECHO_SERVER)], timeout_seconds=30)


def test_list_tools_discovers_the_server(client):
    assert set(client.list_tools()) == {"echo", "fail"}


def test_call_tool_round_trip(client):
    result = client.call_tool("echo", {"text": "hello"})
    assert result["ok"] is True
    assert result["text"] == "echo: hello"


def test_tool_error_comes_back_as_data(client):
    result = client.call_tool("fail", {"reason": "demo"})
    assert result["ok"] is False
    assert "failed on purpose: demo" in result["error"]


def test_unknown_tool_and_dead_server_are_errors_not_exceptions(client):
    assert client.call_tool("no_such_tool", {})["ok"] is False
    dead = MCPClient(command=sys.executable, args=["-c", "import sys; sys.exit(1)"],
                     timeout_seconds=5)
    assert dead.call_tool("echo", {"text": "x"})["ok"] is False
