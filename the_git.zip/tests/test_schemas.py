"""A couple of sanity tests so the repo has a green test from day one."""
from mr_reviewer.schemas import Finding, Review, Severity


def test_verdict_is_derived_from_findings():
    clean = Review(summary="ok", findings=[])
    assert clean.has_blocking_issues is False

    blocking = Review(
        summary="problem",
        findings=[Finding(file="a.py", line=3, severity=Severity.blocker, message="secret")],
    )
    assert blocking.has_blocking_issues is True


def test_finding_round_trips_json():
    f = Finding(file="a.py", line=1, severity=Severity.minor, message="m", rule_id="PY-NAMING-001")
    assert Finding.model_validate_json(f.model_dump_json()) == f
