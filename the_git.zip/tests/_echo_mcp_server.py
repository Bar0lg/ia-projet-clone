"""A tiny MCP server used only by tests/test_mcp_client.py (SDK 2.x API, stdio)."""
from __future__ import annotations

from mcp.server.mcpserver import MCPServer
from mcp.server.mcpserver.exceptions import ToolError

server = MCPServer("echo-test")


@server.tool()
def echo(text: str) -> str:
    """Return the text unchanged."""
    return f"echo: {text}"


@server.tool()
def fail(reason: str) -> str:
    """Always fails with a message the model can read."""
    raise ToolError(f"failed on purpose: {reason}")


if __name__ == "__main__":
    server.run()
