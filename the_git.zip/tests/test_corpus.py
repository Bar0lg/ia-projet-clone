"""The rule corpus: cumulative tiers, unique ids, and eval labels that point at real rules."""
import json
import pathlib
import re

import pytest

from mr_reviewer.rag.index import corpus_files

RULE_HEADING = re.compile(r"^## (\S+) — ", re.MULTILINE)
EVALS = pathlib.Path(__file__).resolve().parents[1] / "evals"
EXPECTED_SIZES = {0: 74, 1: 149, 2: 299, 3: 499}  # "~75 / 150 / 300 / 500" in the docs


def rule_ids(tier: int) -> list[str]:
    return [rid for path in corpus_files(tier)
            for rid in RULE_HEADING.findall(path.read_text(encoding="utf-8"))]


@pytest.mark.parametrize("tier", sorted(EXPECTED_SIZES))
def test_tier_size_and_unique_ids(tier):
    ids = rule_ids(tier)
    assert len(ids) == EXPECTED_SIZES[tier]
    assert len(set(ids)) == len(ids), "duplicate rule id in the corpus"


def test_tiers_are_cumulative():
    for tier in range(1, 4):
        assert set(rule_ids(tier - 1)) < set(rule_ids(tier))


@pytest.mark.parametrize("cases_dir, tier", [("cases", 0), ("cases-extra", 1)])
def test_eval_labels_exist(cases_dir, tier):
    """Every id in a slot exists in the full corpus; each slot has an id in its own tier."""
    full, own = set(rule_ids(3)), set(rule_ids(tier))
    manifest = json.loads((EVALS / cases_dir / "manifest.json").read_text(encoding="utf-8"))
    for case in manifest["cases"]:
        for slot in case["acceptable_rule_ids"]:
            assert set(slot) <= full, f"{case['id']}: unknown id in {slot}"
            assert set(slot) & own, f"{case['id']}: no id of {slot} exists at tier {tier}"
