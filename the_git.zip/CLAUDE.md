Read `AGENTS.md` first: it holds the project context, the commands and the hard rules for any
coding agent working here. (Claude Code reads this file at startup; the rules are enforced by
`.claude/settings.json` and `hooks/protect_evals.py`, see `docs/HARNESS.md`.)
